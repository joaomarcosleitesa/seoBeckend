import { Injectable, NotFoundException, ConflictException, UnauthorizedException } from '@nestjs/common';
import { Model } from 'mongoose'; // Certifique-se de importar o Model do Mongoose
import { InjectModel } from '@nestjs/mongoose'; // Importe o InjectModel para injetar o modelo
import * as bcrypt from 'bcrypt'; // Certifique-se de importar o módulo bcrypt
import { User} from './user.model';

import { AuthService } from '../auth/auth.service'; // Importe o AuthService


@Injectable()
export class UserService {

  
  constructor(@InjectModel('User') private readonly userModel: Model<User>, 
    private readonly authService: AuthService) {}


  // Cria novo usário com Senha Cryptografada
  async createUser(token:string, user: User): Promise<User | any> {


    //return {"mensagem": token}



    // Verifique se o login já existe na coleção 'dados_empresa'
    const existingUser = await this.userModel.findOne({ login: user.login});
    if (existingUser) {

      return 'Login em uso!'
      //throw new ConflictException('O login já está em uso.');
  
    }

    // Verifique se o hostname já existe na coleção 'dados_empresa'
    /*const existingHostname = await this.userModel.findOne({ hostname: user.hostname });
    if (existingHostname) {
      return 'Hostname em uso!';

    }*/


    // Verifique se o hostname já existe na coleção 'dados_empresa'
    const existingUserDomain = await this.userModel.findOne({ user_dominio: user.user_dominio });
    if (existingUserDomain) {
      return('Perfil em uso!');
     
    }



    const newUser = new this.userModel(user);

    const salvar = await newUser.save();

    if(salvar){
      return ('Salvo com sucesso!')
    }
    
  }


  async verifiCreaUser(login: string, password: string): Promise<User | null> {
    // Busque um usuário com o login fornecido
    const user = await this.userModel.findOne({ login }).exec();

    // Se o usuário não for encontrado, retorne null
    if (!user) {
      return null;
    }

    // Verifique se a senha fornecida corresponde à senha armazenada no banco de dados
    const keyword = 'ArcaWebAgencia2024';
    const senhaComKeyword = password + keyword;
    const isPasswordValid = bcrypt.compareSync(senhaComKeyword, user.password);

    // Se a senha for válida, retorne o usuário, caso contrário, retorne null

    return isPasswordValid ? user : null;
  }




   // Cria novo usário com Senha Cryptografada
  async createUser_old(user: any): Promise<User> {


    const token = user.token;

    return token;
    // Verifique se o login já existe na coleção 'dados_empresa'
    const existingUser = await this.userModel.findOne({ login: user.login});
    if (existingUser) {

     
      //throw new ConflictException('O login já está em uso.');
      //return 
    }

    // Verifique se o hostname já existe na coleção 'dados_empresa'
    const existingHostname = await this.userModel.findOne({ hostname: user.hostname });
    if (existingHostname) {

      //throw new ConflictException('O hostname já está em uso.');
      
    }


    // Verifique se o hostname já existe na coleção 'dados_empresa'
    const existingUserDomain = await this.userModel.findOne({ hostname: user.user_dominio });
    if (existingUserDomain) {
      //throw new ConflictException('O Nome do Perfil já está em uso.');
      return
    }



    const newUser = new this.userModel(user);
    return await newUser.save();
  }



  // Busca Novo Usuário e verifica senha criptografada


  async findLoginSenha(login: string, password: string): Promise<User | null> {
    // Busque um usuário com o login fornecido
    const user = await this.userModel.findOne({ login }).exec();

    // Se o usuário não for encontrado, retorne null
    if (!user) {
      return null;
    }

    // Verifique se a senha fornecida corresponde à senha armazenada no banco de dados
    const keyword = 'ArcaWebAgencia2024';
    const senhaComKeyword = password + keyword;
    const isPasswordValid = bcrypt.compareSync(senhaComKeyword, user.password);

    // Se a senha for válida, retorne o usuário, caso contrário, retorne null

    return isPasswordValid ? user : null;
  }

  async findDominio(login: string): Promise<{ hostname: string; user_dominio: string; s3pasta: string, funcao:string } | null> {
        try {
          // Busque um usuário com o login fornecido
          const user = await this.userModel.findOne({ login }).exec();
          //console.log(user.s3pasta)

          if (!user) {
            return null; // Retorna nulo se o usuário não for encontrado
          }

          // Retorna as propriedades desejadas do usuário
          //console.log(user.s3pasta)
          return { hostname: user.hostname, user_dominio: user.user_dominio, s3pasta: user.s3pasta, funcao: user.funcao  };
        } catch (error) {
          // Lidar com erros de consulta, se necessário
          throw new Error(`Erro ao buscar usuário por login: ${error.message}`);
        }
  }


  async findLoginUserOnMaster(login: string, token:string): Promise<User | null |any> {
           try {


                  // Verifique o token usando o AuthService
                  const decodedToken = await this.authService.verifyToken(token);

                  // Busque um usuário com o login fornecido
                  const user = await this.userModel.findOne({ login }).exec();

                  // Se o usuário não for encontrado, retorne null
                  if (!user) {
                    return null;
                  }else{

                    return user
                  }

              } catch (error) {
          // Lidar com erros de consulta, se necessário
                return {"msg":error.message}
                throw new Error(`Erro ao buscar dados por login: ${error.message}`);
        }

  }



  async findDadosUserMaster( token:any): Promise<{ dados: any; } | null> {
        try {


          // Verifique o token usando o AuthService
          const decodedToken = await this.authService.verifyToken(token);

          const longiToken =decodedToken.login

          

          // Busque um usuário com o login fornecido
          const user = await this.userModel.findOne({login:longiToken}).exec();

          if (!user) {
            return null; // Retorna nulo se o usuário não for encontrado
          }

          if(user.funcao=='userAdminMaster'){


            const userComumUsers = await this.userModel.find({ funcao: 'userComum' }).exec();
            const dados = { userComumUsers}
            return {dados};

                  /*const dados = { 
                      hostname: user.hostname, 
                      user_dominio: user.user_dominio, 
                      s3pasta:user.s3pasta,
                      cp_email:user.cp_email,
                      cp_analytcs:user.cp_analytcs,
                      cp_endress: user.cp_endress,
                      cp_link_facebook: user.cp_link_facebook,
                      cp_link_instagram: user.cp_link_instagram,
                      cp_nome_empresa: user.cp_nome_empresa,
                      cp_number_whatsapp :  user.cp_number_whatsapp,
                      cp_seo: user.cp_seo,
                      cp_telefone: user.cp_telefone,
                      cp_text_api_zap: user.cp_text_api_zap,
                      cp_url_site_principal: user.cp_url_site_principal,
                      cp_descript:user.cp_descript,
                      palavras_chave_word:user.palavras_chave_word,
                      frases_seo:user.frases_seo,
                      tags_seo:user.tags_seo,
                      anuncio_loc:user.anuncio_loc,
                      word_text_frases:user.word_text_frases,
                      img_principais:user.img_principais,
                      funcao:user.funcao
                     }
                    */
                   // Retorna as propriedades desejadas do usuário
                return {dados};
             }

          
        } catch (error) {
          // Lidar com erros de consulta, se necessário
          throw new Error(`Erro ao buscar dados por login: ${error.message}`);
        }
  }


  async findParceiros(): Promise<{ dados: any; } | null> {
        try {
  // Filtra todos os usuários ativos com os campos desejados
  const users = await this.userModel
    .find({
      ativo: true,
      funcao: 'userComum'
      //funcao: 'userComum'
      // funcao: 'userComum' // Se desejar filtrar por 'funcao' também
    })
    .select({
              hostname: 1,
              user_dominio: 1,
              s3pasta: 1,
              cp_nome_empresa: 1,
              cp_number_whatsapp: 1,
              cp_text_api_zap: 1,
              palavras_chave_word: 1,
              tags_seo: 1,
              anuncio_loc: 1,
              img_principais: 1
                            //frases_seo: 1,
                            ///word_text_frases: 1,  
    })
    .exec();

  // Retorna a lista de usuários que atendem aos critérios
  return { dados: users };
} catch (error) {
  // Lidar com erros de consulta, se necessário
  throw new Error(`Erro ao buscar dados de usuários: ${error.message}`);
}
  }





  async findParceirosProducts(): Promise<{ dados: any; } | null> {
        try {
  // Filtra todos os usuários ativos com os campos desejados
  const users = await this.userModel
    .find({
      ativo: true,
      funcao: 'userComum'
      //funcao: 'userComum'
      // funcao: 'userComum' // Se desejar filtrar por 'funcao' também
    })
    .select({
              user_dominio: 1,
                            //frases_seo: 1,
                            ///word_text_frases: 1,  
    })
    .exec();

  // Retorna a lista de usuários que atendem aos critérios
  return { dados: users };
} catch (error) {
  // Lidar com erros de consulta, se necessário
  throw new Error(`Erro ao buscar dados de usuários: ${error.message}`);
}
  }




  async findParceirosTexts(): Promise<{ dados: any; } | null> {
        try {
  // Filtra todos os usuários ativos com os campos desejados
  const users = await this.userModel
    .find({
      ativo: true,
      funcao: 'userComum'
      // funcao: 'userComum' // Se desejar filtrar por 'funcao' também
    })
    .select({
              hostname: 1,
              user_dominio: 1,
              s3pasta: 1,
              cp_nome_empresa: 1,
              cp_number_whatsapp: 1,
              cp_text_api_zap: 1,
              palavras_chave_word: 1,
              tags_seo: 1,
              anuncio_loc: 1,
              img_principais: 1,
              frases_seo: 1,
              word_text_frases: 1
    })
    .exec();

  // Retorna a lista de usuários que atendem aos critérios
  return { dados: users };
} catch (error) {
  // Lidar com erros de consulta, se necessário
  throw new Error(`Erro ao buscar dados de usuários: ${error.message}`);
}
  }





  async findDadosUser( token:any): Promise<{ dados: any; } | null> {
        try {


          // Verifique o token usando o AuthService
          const decodedToken = await this.authService.verifyToken(token);

          const longiToken =decodedToken.login

          

          // Busque um usuário com o login fornecido
          const user = await this.userModel.findOne({login:longiToken}).exec();

          if (!user) {
            return null; // Retorna nulo se o usuário não for encontrado
          }

          const dados = { 
              hostname: user.hostname, 
              user_dominio: user.user_dominio, 
              s3pasta:user.s3pasta,
              cp_email:user.cp_email,
              cp_analytcs:user.cp_analytcs,
              cp_endress: user.cp_endress,
              cp_link_facebook: user.cp_link_facebook,
              cp_link_instagram: user.cp_link_instagram,
              cp_nome_empresa: user.cp_nome_empresa,
              cp_number_whatsapp :  user.cp_number_whatsapp,
              cp_seo: user.cp_seo,
              cp_telefone: user.cp_telefone,
              cp_text_api_zap: user.cp_text_api_zap,
              cp_url_site_principal: user.cp_url_site_principal,
              cp_descript:user.cp_descript,
              palavras_chave_word:user.palavras_chave_word,
              frases_seo:user.frases_seo,
              tags_seo:user.tags_seo,
              anuncio_loc:user.anuncio_loc,
              word_text_frases:user.word_text_frases,
              img_principais:user.img_principais



             }

          // Retorna as propriedades desejadas do usuário
          return {dados};
        } catch (error) {
          // Lidar com erros de consulta, se necessário
          throw new Error(`Erro ao buscar dados por login: ${error.message}`);
        }
  }






   async updateUserFields(updateDto:any) {

    try {


      const tokenVer = updateDto.token;


      // Verifique o token usando o AuthService
      const decodedToken = await this.authService.verifyToken(tokenVer);
      
    const login = decodedToken.login;

    const user = await this.userModel.findOneAndUpdate(
      { login: login },
      { 
        hostname:updateDto.hostname,
        cp_seo: updateDto.cp_seo,
        cp_descript: updateDto.cp_descript,
        cp_analytcs: updateDto.cp_analytcs,
        cp_telefone:updateDto.cp_telefone,
        cp_url_site_principal:updateDto.cp_url_site_principal,
        cp_nome_empresa:updateDto.cp_nome_empresa,
        cp_link_facebook:updateDto.cp_link_facebook,
        cp_link_instagram:updateDto.cp_link_instagram,
        cp_number_whatsapp:updateDto.cp_number_whatsapp,
        cp_text_api_zap:updateDto.cp_text_api_zap,
        cp_endress:updateDto.cp_endress,
        cp_email:updateDto.cp_email,
      },
      { new: true,
        select: 'hostname cp_seo cp_descript cp_analytics cp_telefone cp_url_site_principal cp_nome_empresa cp_link_facebook cp_link_instagram cp_number_whatsapp', 
      }, // Isso garante que o método retorne o usuário atualizado
    );

    if (!user) {
      throw new NotFoundException('Usuário não encontrado');
    }

    return user;





    }
     catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
      } else {
        throw new UnauthorizedException('Token inválido.');
      }
    }

    
  }


  //updatePalavraChave





  async updatePalavraChave(updateDto:any) {

    try {


      const tokenVer = updateDto.token;


      // Verifique o token usando o AuthService
      const decodedToken = await this.authService.verifyToken(tokenVer);
      
    const login = decodedToken.login;

    const user = await this.userModel.findOneAndUpdate(
      { login: login },
      { 
        palavras_chave_word:updateDto.palavras_chave_word,
      },
      { new: true,
        select: 'palavras_chave_word', 
      }, // Isso garante que o método retorne o usuário atualizado
    );

    if (!user) {
      throw new NotFoundException('Usuário não encontrado');
    }

    return user;





    }
     catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
      } else {
        throw new UnauthorizedException('Token inválido.');
      }
    }

  }




  async updateFrasesSeoService(updateDto:any) {

    try {


      const tokenVer = updateDto.token;


      // Verifique o token usando o AuthService
      const decodedToken = await this.authService.verifyToken(tokenVer);
      
    const login = decodedToken.login;

    const user = await this.userModel.findOneAndUpdate(
      { login: login },
      { 
        frases_seo:updateDto.frases_seo,
      },
      { new: true,
        select: 'frases_seo', 
      }, // Isso garante que o método retorne o usuário atualizado
    );

    if (!user) {
      throw new NotFoundException('Usuário não encontrado');
    }

    return user;





    }
     catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
      } else {
        throw new UnauthorizedException('Token inválido.');
      }
    }

  }





  async updateSeoTagsService(updateDto:any) {

    try {


      const tokenVer = updateDto.token;


      // Verifique o token usando o AuthService
      const decodedToken = await this.authService.verifyToken(tokenVer);
      
    const login = decodedToken.login;

    const user = await this.userModel.findOneAndUpdate(
      { login: login },
      { 
        tags_seo:updateDto.tags_seo,
      },
      { new: true,
        select: 'tags_seo', 
      }, // Isso garante que o método retorne o usuário atualizado
    );

    if (!user) {
      throw new NotFoundException('Usuário não encontrado');
    }

    return user;





    }
     catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
      } else {
        throw new UnauthorizedException('Token inválido.');
      }
    }

  }


  async updateUserAtivoService(updateDto:any) {

    try {


      const tokenVer = updateDto.token;


      // Verifique o token usando o AuthService
      const decodedToken = await this.authService.verifyToken(tokenVer);
      
    const login   = decodedToken.login;
    const funcao  = decodedToken.funcao;

      if(funcao=="userAdminMaster" && login =="marcosleite"){

            const user = await this.userModel.findOneAndUpdate(
              { login: updateDto.login },
              { 
                ativo:updateDto.ativo,
              },
              { new: true,
                select: 'ativo', 
              }, // Isso garante que o método retorne o usuário atualizado
            );

            if (!user) {
              throw new NotFoundException('Usuário não encontrado');
            }

            return user;
        }else{

          return {
            "message":"Você não tem autorização como administrador",
           "error": "Unauthorized",
            "statusCode": 401
          };
        }





    }
     catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
      } else {
        throw new UnauthorizedException('Token inválido.');
      }
    }

  }



  async updateAnuncioLoc(updateDto:any) {

    try {


            const tokenVer = updateDto.token;


            // Verifique o token usando o AuthService
            const decodedToken = await this.authService.verifyToken(tokenVer);
      
            const login   = decodedToken.login;
  

   

            const user = await this.userModel.findOneAndUpdate(
              { login: login },
              { 
                anuncio_loc:updateDto.anuncio_loc,
              },
              { new: true,
                select: 'anuncio_loc', 
              }, // Isso garante que o método retorne o usuário atualizado
            );

            if (!user) {
              throw new NotFoundException('Usuário não encontrado');
            }

            return user;
      

    }
     catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
      } else {
        throw new UnauthorizedException('Token inválido.');
      }
    }

  }


  async updateWordTextService(updateDto:any) {

    try {


      const tokenVer = updateDto.token;


      // Verifique o token usando o AuthService
      const decodedToken = await this.authService.verifyToken(tokenVer);
      
        const login   = decodedToken.login;


        const user = await this.userModel.findOne({ login });

        if (!user) {
          throw new Error('Usuário não encontrado');
        }


        // Acesse o campo "word_text_frases" do documento do usuário
        const wordTextFrases = user.word_text_frases;


         // Procure o campo "text" dentro do objeto "word_text_frases"
        const text = wordTextFrases.map((frase) => frase.text);

        if (!text) {
          throw new Error('Textos não encontrado');
        }

        return text;

    }
     catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
      } else {
        throw new UnauthorizedException('Token inválido.', error.message);


      }
    }

  }



  //getWordOnKeyWordTextService


  async getWordOnKeyWordTextService(updateDto:any) {

    try {


      const tokenVer = updateDto.token;


      // Verifique o token usando o AuthService
      const decodedToken = await this.authService.verifyToken(tokenVer);
      
    const login   = decodedToken.login;



            const user = await this.userModel.findOneAndUpdate(
              { login: login },
              { 
                word_text_frases:updateDto.word_text_frases,
              },
              { new: true,
                select: 'word_text_frases', 
              }, // Isso garante que o método retorne o usuário atualizado
            );

            if (!user) {
              throw new NotFoundException('Usuário não encontrado');
            }

            return user;
   
    }
     catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
      } else {
        throw new UnauthorizedException('Token inválido.');
      }
    }

  }



   async updateFrasesOnKeyWordTextService(updateDto:any) {

    try {

            const tokenVer = updateDto.token;


            // Verifique o token usando o AuthService
            const decodedToken = await this.authService.verifyToken(tokenVer);
            
              const login   = decodedToken.login;





              const user = await this.userModel.findOne({ login });




              if (!user) {
                throw new Error('Usuário não encontrado');
              }


              // Acesse o campo "word_text_frases" do documento do usuário
              const wordTextFrases = user.word_text_frases;

              const textoBuscado  = updateDto.keytext;
              const newfrases        = updateDto.frases;



              // Crie um filtro personalizado com base no campo "text" dentro de "wordTextFrases"
                const filtro = wordTextFrases.find((item) => item.text === textoBuscado);


                //return {"dados":filtro}


                const atualizacao = {
                  $setOnInsert:{
                    text: textoBuscado,
                    ativo:true,
                    frase_radom: {
                      frases:newfrases
                    }
                  }
                };


              const options = {
                upsert: true, // Crie um novo documento se não existir
                new: true, // Retorne o documento atualizado
              };

              const newFilter = {
                          login:login, // Filtre pelo login do usuário
                          'word_text_frases.text': textoBuscado, // Filtre pelo texto desejado
                        };

              const filterWordtext = {
                          login:login, // Filtre pelo login do usuário
                        };



               // Tente encontrar um documento com base no filtro
                const documentoEncontrado = await this.userModel.findOne(newFilter);

               //return {"dados":documentoEncontrado}


                if (documentoEncontrado) {
                      // O documento existe, atualize-o
                      const documentoAtualizado = await this.userModel.findOneAndUpdate(
                      newFilter,

                        {
                        $set: {
                              'word_text_frases.$.frase_radom.frases': newfrases, // Atualize o campo frases
                            }
                            },
                        { 
                          new: true,
                          select: 'word_text_frases', 
                        }, // Isso garante que o método retorne o usuário atualizado
                      );
                      console.log("Documento atualizado:", documentoAtualizado);
                    } else {

                      //return {"dados":"ACESSADO"}

                      const documentoInseridoAtualizado = await this.userModel.findOneAndUpdate(
                        filterWordtext, // Certifique-se de que este filtro esteja correto
                        {
                          $push: {
                            "word_text_frases": {
                              "ativo":true,
                              "text": textoBuscado,
                              "frase_radom": {
                                "frases": newfrases
                              }
                            }
                          }
                        },
                        {
                          new: true,
                          select: 'word_text_frases'
                        }
                      );





                      return {"respota":documentoInseridoAtualizado}
                    }
            //Este código tentará encontrar um documento com base no filtro especificado (filtro). Se o documento for encontrado, ele será atualizado com os valores fornecidos em atualizacao. Se o documento não for encontrado, um novo documento será criado com base em atualizacao.$setOnInsert. Certifique-se de ajustar o filtro e os valores de atualização conforme necessário para corresponder aos requisitos do seu aplicativo.

              //const documentoAtualizado = await this.userModel.findOneAndUpdate(filtro, atualizacao, options);
              //console.log("Documento atualizado ou criado:", documentoAtualizado);
    }

    catch (error) {
  if (error.name === 'TokenExpiredError') {
    // Lidar com erros de token expirado
    throw new UnauthorizedException('Token expirado.');
  } else {
    // Lidar com outros erros, como erros de atualização
    console.error("Erro durante a atualização:", error);
    // Trate o erro de acordo com sua lógica
    // Por exemplo, você pode lançar uma exceção personalizada ou retornar uma mensagem de erro
  }
}
}
    





 /* async findDominio(login: string): Promise<{ hostname: string}> {
  try {
    // Busque um usuário com o login fornecido
    const user = await this.userModel.findOne({ login }).exec();

    if (!user) {
      return null; // Retorna nulo se o usuário não for encontrado
    }

    const userHostname =user.hostname

    // Retorna as propriedades desejadas do usuário, considerando que user_dominio pode ser nulo
    return { hostname: userHostname };

  } catch (error) {
    // Lidar com erros de consulta, se necessário
    throw new Error(`Erro ao buscar usuário por login: ${error.message}`);
  }
}

*/


async updateImgLinksService(updateDto: any) {
  try {
    const tokenVer = updateDto.token;

    // Verifique o token usando o AuthService
    const decodedToken = await this.authService.verifyToken(tokenVer);

    const login = decodedToken.login;
    const selectimg = updateDto.selectimg;
    const imgurl = updateDto.imgurl;

    const user = await this.userModel.findOne({ login: login });

    if (!user) {
      throw new NotFoundException('Usuário não encontrado');
    }

    // Certifique-se de que `img_principais` seja um array vazio se não existir
    if (!user.img_principais) {
      user.img_principais = [];
    }

    // Encontre o índice do elemento existente (se houver)
    const existingIndex = user.img_principais.findIndex((item) => item.hasOwnProperty(selectimg));

    if (existingIndex !== -1) {
      // Atualize a propriedade existente com $set
      const update = {
        $set: { [`img_principais.${existingIndex}.${selectimg}`]: imgurl },
      };
      await this.userModel.updateOne({ _id: user._id }, update);
    } else {
      // Adicione uma nova propriedade
      const newItem = { [selectimg]: imgurl };
      user.img_principais.push(newItem);

      // Atualize o objeto `img_principais` no documento do usuário
      await user.save();
    }

    return user.img_principais;
  } catch (error) {
    // Ocorreu um erro ao verificar o token
    if (error.name === 'TokenExpiredError') {
      throw new UnauthorizedException('Token expirado.');
    } else {
      throw new UnauthorizedException('Token inválido.');
    }
  }
}


async updateImgLinksService_old(updateDto:any) {

    try {


            const tokenVer = updateDto.token;


            // Verifique o token usando o AuthService
            const decodedToken = await this.authService.verifyToken(tokenVer);
      
            const login   = decodedToken.login;
            const selectimg  = updateDto.selectimg;
            const imgurl  = updateDto.imgurl;

            const user = await this.userModel.findOne({ login: login });

              if (!user) {
                throw new NotFoundException('Usuário não encontrado');
              }

              // Certifique-se de que `img_principais` seja um array vazio se não existir
              if (!user.img_principais) {
                user.img_principais = [];
              }

              // Adicione ou atualize a propriedade selectimg no objeto img_principais
              const imgPrincipaisItem = user.img_principais.find((item) => item.hasOwnProperty(selectimg));
              if (imgPrincipaisItem) {


                imgPrincipaisItem[selectimg] = imgurl;
              } else {
                const newItem = { [selectimg]: imgurl };
                user.img_principais.push(newItem);
              }

              // Atualize o objeto img_principais no documento do usuário
              await user.save();

              return user.img_principais;
      

    }
     catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
      } else {
        throw new UnauthorizedException('Token inválido.');
      }
    }

  }







  async findAllUsers(): Promise<User[]> {
    return await this.userModel.find().exec();
  }




  findAll() {
    return `This action returns all user`;
  }

  findOne(id: number) {
    return `This action returns a #${id} user`;
  }



  remove(id: number) {
    return `This action removes a #${id} user`;
  }
}

import { Controller, Get, Post, Body, Patch, Param, Delete ,Req, UnauthorizedException} from '@nestjs/common';
import { UserService } from './user.service';

import { User} from './user.model';

//
import { AuthService } from '../auth/auth.service'; // Importe o AuthService

interface CreateUserRequest {
  user: User;
  token: string;
}


@Controller('user')
export class UserController {
  constructor(
    private readonly userService: UserService,
    private readonly authService: AuthService

    ) {}



  /*

        {
        "login": "marcosleite",
        "password": "080591Jm",
        "user_dominio":"trafegoarcaweb",
        "hostname":"trafego-pago.arcaweb.com.br"

          }

    */


  @Post('findeAllUserMaster')
  async findDadosUserMaster(
        @Body() dados: any,
        ) {

        try {

            const token = dados.token; // Obtenha o token de dados
            //''return {token}
            //return dados.token
            const dadosUsuario = await this.userService.findDadosUserMaster(token);
            return {"mensagem":dadosUsuario};
            /*const typeUser =  dadosUsuario.dados.funcao;
            return {"mensagem":typeUser}*/

            //if()
            return {dadosUsuario}
          }catch (error) {
          // Ocorreu um erro ao verificar o token
          if (error.name === 'TokenExpiredError') {
            throw new UnauthorizedException('Token expirado.');
          } else {
            throw new UnauthorizedException('Token inválido.');
          }
        }
    
  }



  @Post('createnew')
  async createUser(@Body() request: CreateUserRequest): Promise<User | any> {

    try {
          const { user, token } = request;



          const decodedToken = await this.authService.verifyToken(token);
          

          if(decodedToken.funcao!=null && decodedToken.funcao!=undefined){
              if(decodedToken.funcao=="userAdminMaster"){

                        const resposta = await this.userService.createUser(token, user);
                      if(resposta){
                      return ({"mensagem":resposta })
                      }

              }
            }
      }catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
        return ({"mensagem":error+' Token expirado.' })
      } else {
        return ({"mensagem":error+' Token Invalido.' })
      }
    }



    

    
  }


@Post('loginUserOnMaster')
  async loginUserOnMaster(@Body() loginData: { login: string, token:string}): Promise<{ tokenLogin: string }> {
    const { login, token} = loginData;

    // Autenticar o usuário com base no login e na senha
    const authenticatedUser = await this.userService.findLoginUserOnMaster(login, token);

    if (!authenticatedUser) {
      throw new UnauthorizedException('Login não inválidos.');
    }

    const {  hostname, user_dominio, s3pasta, funcao } = await this.userService.findDominio(login);

     // Se o usuário foi autenticado com sucesso, gere um token JWT usando o AuthService
    const payload = { login, hostname, user_dominio, s3pasta, funcao  }; // O payload pode conter outras informações, se necessário
    const tokenLogin = await this.authService.generateToken(payload);

    // Retorne o token JWT no corpo da resposta
    return { tokenLogin };

    //hostname e user_dominio
    //return 'logado';
    //return authenticatedUser;
  }


  



  /*@Post('createnew_old')
  async createUserold(@Body() user: User): Promise<User> {
   
    return await this.userService.createUser(user);
  }*/



  /*


    http://localhost:3170/user/login


        {
          "login": "marcosleite",
          "password": "080591Jm"
          
        }

  */
  
  //async loginUser(@Body() loginData: { login: string, password: string }): Promise<User> 
  @Post('login')
  async loginUser(@Body() loginData: { login: string, password: string }): Promise<{ tokenLogin: string }> {
    const { login, password } = loginData;

    // Autenticar o usuário com base no login e na senha
    const authenticatedUser = await this.userService.findLoginSenha(login, password);

    if (!authenticatedUser) {
      throw new UnauthorizedException('Login ou senha inválidos.');
    }

    const {  hostname, user_dominio, s3pasta, funcao } = await this.userService.findDominio(login);

     // Se o usuário foi autenticado com sucesso, gere um token JWT usando o AuthService
    const payload = { login, hostname, user_dominio, s3pasta, funcao  }; // O payload pode conter outras informações, se necessário
    const tokenLogin = await this.authService.generateToken(payload);
    
    // Retorne o token JWT no corpo da resposta
    return { tokenLogin };

    //hostname e user_dominio
    //return 'logado';
    //return authenticatedUser;
  }
  
    /*'

      http://localhost:3170/user/verify-token

      {
        "token":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJsb2dpbiI6Im1hcmNvc2xlaXRlIiwiaWF0IjoxNjk1NjU2NTMzLCJleHAiOjE2OTU2NjczMzN9.PGU558dt0HI5HWfp9huFKACB5CMbGtYtHdHJ3QEaCtU"
        
      }


  */

  @Post('verify-token')
  async verifyToken(@Body() { token }: { token: string }): Promise<{ message: string , user:string, hostname:string, user_dominio:string, s3pasta:string}> {
    try {
      // Verifique o token usando o AuthService
      const decodedToken = await this.authService.verifyToken(token);

      // O token é válido
      return { message: 'autorizado',  user:  decodedToken.login, hostname:decodedToken.hostname, user_dominio:decodedToken.user_dominio, s3pasta:decodedToken.s3pasta };
    } catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
      } else {
        throw new UnauthorizedException('Token inválido.');
      }
    }

  }


   /*        
            
            http://localhost:3370/user/update-tags-seo

              {
            "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJsb2dpbiI6Im1hcmNvc2xlaXRlIiwiaG9zdG5hbWUiOiJzZW8tYmguYXJjYXdlYi5jb20uYnIiLCJ1c2VyX2RvbWluaW8iOiJ0cmFmZWdvYXJjYXdlYiIsInMzcGFzdGEiOiJtYXJjb3NsZWl0ZS1hcmNhd2ViLXNlby1icE1TVFZmQ2dIdWQiLCJpYXQiOjE2OTYyNTgyMTQsImV4cCI6MTY5NjI2OTAxNH0.h6dqasWLOBuyR5C4MrQC9jjKxFHpJtcmXC_fVf3vg-s",
            "tags_seo" : [
                        "Google Ads",
                        "Facebook Ads",
                        "Anúncios online",
                        "Marketing de busca",
                        "Remarketing",
                        "Publicidade paga",
                        "Campanhas de anúncios",
                        "Publicidade digital",
                        "Anúncios pagos",
                        "Palavras-chave patrocinadas",
                        "Anúncios segmentados",
                        "Redes de display",
                        "Anúncios em mídias sociais",
                        "Publicidade online",
                        "Links patrocinados",
                        "Marketing de performance",
                        "Anúncios pagos por clique",
                        "PPC no Google",
                        "Campanhas de publicidade online"
                    ]
        }


   */


  /* 

      /user/ativarUserOnMaster

  */


   @Post('ativarUserOnMaster') // Rota para atualizar campos de SEO
  async ativarUserOnMasterController(
    @Body() updateDto: any,
    ) {

    try {

        //console.log("teste");
        //return updateDto;
        return this.userService.updateUserAtivoService(updateDto);
      }catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
      } else {
        throw new UnauthorizedException('Token inválido.');
      }
    }
  }



 @Post('update-seotags') // Rota para atualizar campos de SEO
  async updateSeoTags(
    @Body() updateDto: any,
    ) {

    try {

      

        //console.log("teste");
        //return updateDto;

        //return {"msg":updateDto}
        return this.userService.updateSeoTagsService(updateDto);
      }catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
      } else {
        throw new UnauthorizedException('Token inválido.');
      }
    }
  }



 

   /*

            http://localhost:3370/user/update-palavrachave


              {
            "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJsb2dpbiI6Im1hcmNvc2xlaXRlIiwiaG9zdG5hbWUiOiJzZW8tYmguYXJjYXdlYi5jb20uYnIiLCJ1c2VyX2RvbWluaW8iOiJ0cmFmZWdvYXJjYXdlYiIsInMzcGFzdGEiOiJtYXJjb3NsZWl0ZS1hcmNhd2ViLXNlby1icE1TVFZmQ2dIdWQiLCJpYXQiOjE2OTYyNTgyMTQsImV4cCI6MTY5NjI2OTAxNH0.h6dqasWLOBuyR5C4MrQC9jjKxFHpJtcmXC_fVf3vg-s",
            "palavras_chave_word" : [
                "Trafego pago",
                "Facebook Ads",
                "Criação de Landing Pages",
                "Gestor de Tráfego Pago",
                "Google Ads",
                "Google maps",
                "Agência de Marketing Digital",
                "Agência de Tráfego pago",
                "Trafégo Pago em Contagem"
            ]
        }


   */

  @Post('update-palavrachave') // Rota para atualizar campos de SEO
  async updatePalavraChave(
    @Body() updateDto: any,
    ) {

    try {

        //console.log("teste");
        //return updateDto;
        return this.userService.updatePalavraChave(updateDto);
      }catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
      } else {
        throw new UnauthorizedException('Token inválido.');
      }
    }
  }





  /*        
            
            http://localhost:3370/user/update-frases-seo

              {
            "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJsb2dpbiI6Im1hcmNvc2xlaXRlIiwiaG9zdG5hbWUiOiJzZW8tYmguYXJjYXdlYi5jb20uYnIiLCJ1c2VyX2RvbWluaW8iOiJ0cmFmZWdvYXJjYXdlYiIsInMzcGFzdGEiOiJtYXJjb3NsZWl0ZS1hcmNhd2ViLXNlby1icE1TVFZmQ2dIdWQiLCJpYXQiOjE2OTYyNTgyMTQsImV4cCI6MTY5NjI2OTAxNH0.h6dqasWLOBuyR5C4MrQC9jjKxFHpJtcmXC_fVf3vg-s",
            "frases_seo" : [
                Trafégo Pago em Contagem",
                "Aumente seu alcance online com tráfego pago e anúncios direcionados",
                "Obtenha resultados imediatos com tráfego pago e anúncios estrategicamente colocados.",
                "Impulsione suas vendas com anúncios pagos e tráfego segmentado",
                "Maximize sua visibilidade online através de anúncios e tráfego pago",
                "Alcance seu público-alvo de forma eficaz com tráfego pago e anúncios personalizados",
                "Atraia visitantes qualificados para seu site com tráfego pago e anúncios relevantes",
                "Impulsione seu negócio com tráfego pago e anúncios de alto desempenho",
                "Aumente sua taxa de conversão com tráfego pago e anúncios persuasivos",
                "Otimize seu ROI investindo em tráfego pago e anúncios bem planejados",
                "Alcance novos clientes com tráfego pago e anúncios segmentados"
            ]
        }


   */

  @Post('update-frases-seo') // Rota para atualizar campos de SEO
  async updateFrasesSeoController(
    @Body() updateDto: any,
    ) {

    try {

        //console.log("teste");
        //return updateDto;
        return this.userService.updateFrasesSeoService(updateDto);
      }catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
      } else {
        throw new UnauthorizedException('Token inválido.');
      }
    }
  }



   /*        
            
            http://localhost:3370/user/update-user-ativo

              {
            "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJsb2dpbiI6Im1hcmNvc2xlaXRlIiwiaG9zdG5hbWUiOiJzZW8tYmguYXJjYXdlYi5jb20uYnIiLCJ1c2VyX2RvbWluaW8iOiJ0cmFmZWdvYXJjYXdlYiIsInMzcGFzdGEiOiJtYXJjb3NsZWl0ZS1hcmNhd2ViLXNlby1icE1TVFZmQ2dIdWQiLCJmdW5jYW8iOiJ1c2VyQWRtaW5NYXN0ZXIiLCJpYXQiOjE2OTYyNjE4MjcsImV4cCI6MTY5NjI3MjYyN30.d2Gl5E4ibRE3nyyJIM3grHhKUOI-oysLu4WPe9yunT0",
            "ativo" : true
        }


   */

  @Post('update-user-ativo') // Rota para atualizar campos de SEO
  async updateUserAtivoControl(
    @Body() updateDto: any,
    ) {

    try {

        //console.log("teste");
        //return updateDto;
        return this.userService.updateUserAtivoService(updateDto);
      }catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
      } else {
        throw new UnauthorizedException('Token inválido.');
      }
    }
  }


 


  //




  @Post('update-user') // Rota para atualizar campos de SEO
  async updateSeoFields(
    @Body() updateDto: any,
    ) {

    try {

        //console.log(updateDto);
        //return updateDto;
        return this.userService.updateUserFields(updateDto);
      }catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
      } else {
        throw new UnauthorizedException('Token inválido.');
      }
    }
  }







  





  @Post('dados-user') // Rota para atualizar campos de SEO
  async findDadosUser(
    @Body() dados: any,
    ) {

    try {

        const token = dados.token; // Obtenha o token de dados
        //''return {token}
        //return dados.token
        const dadosUsuario = await this.userService.findDadosUser(token);
        return {dadosUsuario}
      }catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
      } else {
        throw new UnauthorizedException('Token inválido.');
      }
    }
  }




  @Post('find-all-user') // Rota para atualizar campos de SEO
  async findAllUser(
    @Body() dados: any,
    ) {

    try {
        const dadosUsuario = await this.userService.findParceiros();
        return {dadosUsuario}
      }catch (error) {
      return {'msg':error}
    }
  }


  @Post('find-all-user-text') // Rota para atualizar campos de SEO
  async findAllUserText(
    @Body() dados: any,
    ) {

    try {
        const dadosUsuario = await this.userService.findParceirosTexts();
        return {dadosUsuario}
      }catch (error) {
      return {'msg':error}
    }
  }


  



   /*        
            
            http://localhost:3370/user/update-anuncio-loc

              {
                "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJsb2dpbiI6Im1hcmNvc2xlaXRlIiwiaG9zdG5hbWUiOiJzZW8tYmguYXJjYXdlYi5jb20uYnIiLCJ1c2VyX2RvbWluaW8iOiJ0cmFmZWdvYXJjYXdlYiIsInMzcGFzdGEiOiJtYXJjb3NsZWl0ZS1hcmNhd2ViLXNlby1icE1TVFZmQ2dIdWQiLCJmdW5jYW8iOiJ1c2VyQWRtaW5NYXN0ZXIiLCJpYXQiOjE2OTYzNDc5NzIsImV4cCI6MTY5NjM1ODc3Mn0.5qEqO8AacGF6zmpIuMPR5ngNBkP13OS7XZC-L8YVglY",
                "anuncio_loc" : [
                                {
                                    "state" : "MG",
                                    "cities" : [
                                        {
                                            "name" : "Contagem"
                                        },
                                        {
                                            "name" : "Belo Horizonte"
                                        }
                                        
                                    ]
                                },
                                {
                                    "state" : "SP",
                                    "cities" : [
                                        {
                                            "name" : "São Paulo"
                                        },
                                        {
                                            "name" : "Caraguatatuba"
                                        }
                                    ]
                                }
                            ]
                          }


   */

    @Post('update-anuncio-loc') // Rota para atualizar campos de SEO
  async updateAnucioLocCont(
    @Body() updateDto: any,
    ) {

    try {

        //console.log(updateDto);
        //return updateDto;
        return this.userService.updateAnuncioLoc(updateDto);
      }catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
      } else {
        throw new UnauthorizedException('Token inválido.');
      }
    }
  }



   /*        
            
            http://localhost:3370/user/update-anuncio-loc

              {
                "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJsb2dpbiI6Im1hcmNvc2xlaXRlIiwiaG9zdG5hbWUiOiJzZW8tYmguYXJjYXdlYi5jb20uYnIiLCJ1c2VyX2RvbWluaW8iOiJ0cmFmZWdvYXJjYXdlYiIsInMzcGFzdGEiOiJtYXJjb3NsZWl0ZS1hcmNhd2ViLXNlby1icE1TVFZmQ2dIdWQiLCJmdW5jYW8iOiJ1c2VyQWRtaW5NYXN0ZXIiLCJpYXQiOjE2OTYzNDc5NzIsImV4cCI6MTY5NjM1ODc3Mn0.5qEqO8AacGF6zmpIuMPR5ngNBkP13OS7XZC-L8YVglY",
                "word_text_frases" : [
                        {
                            "text" : "ALL_WORDS",
                            "status" : true,
                            "children" : [

                            ],
                            "frase_radom" : {
                                "frases" : [
                            "O tráfego pago é uma das estratégias mais importantes e eficazes para impulsionar o crescimento e aumentar a visibilidade de uma empresa na internet. ",
                            "Ao contrário do tráfego orgânico, que é gerado por meio de conteúdo de qualidade e otimização para mecanismos de busca, o tráfego pago envolve investir dinheiro em anúncios para alcançar um público mais amplo e direcionado."

                                ]
                            }
                        },
                        {
                            "text" : "Trafego pago",
                            "status" : true,
                            "children" : [

                            ],
                            "frase_radom" : {
                                "frases" : [
                                    "O tráfego pago é uma das estratégias mais importantes e eficazes para impulsionar o crescimento e aumentar a visibilidade de uma empresa na internet. ",
                                    "Ao contrário do tráfego orgânico, que é gerado por meio de conteúdo de qualidade e otimização para mecanismos de busca, o tráfego pago envolve investir dinheiro em anúncios para alcançar um público mais amplo e direcionado.",
                                    "A importância do tráfego pago é que ele permite que as empresas alcancem seus objetivos de marketing com rapidez e eficiência. ",
                                    "Com uma campanha de anúncios bem planejada, é possível direcionar o tráfego para o site da empresa, aumentar as vendas, gerar leads e construir a marca.",
                                    "Além disso, o tráfego pago permite que as empresas segmentem seu público-alvo de forma mais precisa. Isso significa que é possível direcionar anúncios para usuários com base em sua localização geográfica, interesses, comportamentos de compra e outras características relevantes. "
                                ]
                            }
                        }]
        
                          }


   */

  @Post('update-word-text-frases') // Rota para atualizar campos de SEO
  async updateWordTextCont(
    @Body() updateDto: any,
    ) {

    try {

        //console.log(updateDto);
        //return updateDto;
        return this.userService.updateWordTextService(updateDto);
      }catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
      } else {
        throw new UnauthorizedException('Token inválido.');
      }
    }
  }


  /*

              {
                "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJsb2dpbiI6Im1hcmNvc2xlaXRlIiwiaG9zdG5hbWUiOiJzZW8tYmguYXJjYXdlYi5jb20uYnIiLCJ1c2VyX2RvbWluaW8iOiJ0cmFmZWdvYXJjYXdlYiIsInMzcGFzdGEiOiJtYXJjb3NsZWl0ZS1hcmNhd2ViLXNlby1icE1TVFZmQ2dIdWQiLCJmdW5jYW8iOiJ1c2VyQWRtaW5NYXN0ZXIiLCJpYXQiOjE2OTYzNDc5NzIsImV4cCI6MTY5NjM1ODc3Mn0.5qEqO8AacGF6zmpIuMPR5ngNBkP13OS7XZC-L8YVglY"
              }
  */

  @Post('get-word-on-keyword-text-frases') // Rota para atualizar campos de SEO
  async getWordTextCont(
    @Body() updateDto: any,
    ) {

    try {

        //console.log(updateDto);
        //return updateDto;
        return this.userService.getWordOnKeyWordTextService(updateDto);
      }catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
      } else {
        throw new UnauthorizedException('Token inválido.');
      }
    }
  }

  /*

              {
                "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJsb2dpbiI6Im1hcmNvc2xlaXRlIiwiaG9zdG5hbWUiOiJzZW8tYmguYXJjYXdlYi5jb20uYnIiLCJ1c2VyX2RvbWluaW8iOiJ0cmFmZWdvYXJjYXdlYiIsInMzcGFzdGEiOiJtYXJjb3NsZWl0ZS1hcmNhd2ViLXNlby1icE1TVFZmQ2dIdWQiLCJmdW5jYW8iOiJ1c2VyQWRtaW5NYXN0ZXIiLCJpYXQiOjE2OTYzNDc5NzIsImV4cCI6MTY5NjM1ODc3Mn0.5qEqO8AacGF6zmpIuMPR5ngNBkP13OS7XZC-L8YVglY",
                "keytext":"ALL_WORD",
                "frases":[]
              }
  */


  @Post('update-frases-on-keyword-text-frases') // Rota para atualizar campos de SEO
  async getFrasesWordTextCont(
    @Body() updateDto: any,
    ) {

    try {

        //console.log(updateDto);
        //return updateDto;
        return this.userService.updateFrasesOnKeyWordTextService(updateDto);
      }catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
      } else {
        throw new UnauthorizedException('Token inválido.');
      }
    }
  }



    /*        
            
            http://localhost:3370/user/update-user-ativo

              {
            "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJsb2dpbiI6Im1hcmNvc2xlaXRlIiwiaG9zdG5hbWUiOiJzZW8tYmguYXJjYXdlYi5jb20uYnIiLCJ1c2VyX2RvbWluaW8iOiJ0cmFmZWdvYXJjYXdlYiIsInMzcGFzdGEiOiJtYXJjb3NsZWl0ZS1hcmNhd2ViLXNlby1icE1TVFZmQ2dIdWQiLCJmdW5jYW8iOiJ1c2VyQWRtaW5NYXN0ZXIiLCJpYXQiOjE2OTYyNjE4MjcsImV4cCI6MTY5NjI3MjYyN30.d2Gl5E4ibRE3nyyJIM3grHhKUOI-oysLu4WPe9yunT0",
            "ativo" : true
        }


   */

  @Post('update-links-img') // Rota para atualizar campos de SEO
  async updateUserLinksImgControl(
    @Body() updateDto: any,
    ) {

    try {

        //console.log("teste");
        //return updateDto;
        return this.userService.updateImgLinksService(updateDto);
      }catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
      } else {
        throw new UnauthorizedException('Token inválido.');
      }
    }
  }


  @Get('getall')
  async findAllUsers(): Promise<User[]> {
    return await this.userService.findAllUsers();
  }




  @Get()
  findAll() {
    return this.userService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.userService.findOne(+id);
  }



  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.userService.remove(+id);
  }
}

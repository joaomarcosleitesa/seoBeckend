import { Schema, Document } from 'mongoose';
const bcrypt = require('bcrypt');


// Função para definir a senha com criptografia
const setSenha = function (plainPassword) {
  const keyword = 'ArcaWebAgencia2024';
  const saltRounds = 10;
  const salt = bcrypt.genSaltSync(saltRounds);
  // Concatenar a palavra-chave à senha
  const senhaComKeyword = plainPassword + keyword;
  const hashedPassword = bcrypt.hashSync(senhaComKeyword, salt);
  return hashedPassword;
};




const setRenderPast = function () {
  const alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
  let randomLetters = '';

  for (let i = 0; i < 12; i++) {
    const randomIndex = Math.floor(Math.random() * alphabet.length);
    randomLetters += alphabet.charAt(randomIndex);
  }
  const keyword = this.login + '-arcaweb-seo-' + randomLetters;

  return keyword;
};

const setRender = {
  type: String,
  default: function() {
    return setRenderPast.call(this);
  },
  // Impede que o campo seja modificado posteriormente
};

const setFuncao = {
  type: String,
  default: 'userComum', // Define 'userComum' como valor padrão
  // Impede que o campo seja modificado posteriormente
  set: function(value) {
    return 'userComum';
  },
};





export interface User extends Document {
  login: string,
  password: string,
  funcao: string,
  hostname: string,
  user_dominio: string,
  s3pasta:string,
  cp_seo:string,
  cp_descript:string,
  cp_analytcs:string,
  cp_telefone:string,
  cp_url_site_principal:string,
  cp_nome_empresa:string,
  cp_link_facebook:string,
  cp_link_instagram:string,
  cp_number_whatsapp:string,
  cp_text_api_zap:string,
  cp_endress:string,
  cp_email:string,
  tags_seo:string[],
  palavras_chave_word:string[],
  frases_seo:string[],
  anuncio_loc: {
    state: string;
    cities: { name: string }[];
  }[],
   word_text_frases:any[],
  ativo: boolean,
  img_principais: {
    [key: string]: string;
  }[],



}

// Defina o nome da coleção personalizado no esquema
export const UserSchema  = new Schema({


  login: { 
      type:String,
      default:""
      },
  password: { 
      type:String,
      default:""
      },
  funcao: setFuncao, // FUNCAO PODE SER  // 'masterAdmin', 'userComum', 'AdminEditor'
  hostname: { 
      type:String,
      default:""
      },
  user_dominio: { 
      type:String,
      default:""
      },
  s3pasta: setRender,
  cp_seo: { 
      type:String,
      default:""
      },
  cp_descript: { 
      type:String,
      default:""
      },
  cp_analytcs: { 
      type:String,
      default:""
      },
  cp_telefone: { 
      type:String,
      default:""
      },
  cp_url_site_principal: { 
      type:String,
      default:""
      },
  cp_nome_empresa: { 
      type:String,
      default:""
      },
  cp_link_facebook: { 
      type:String,
      default:""
      },
  cp_link_instagram: { 
      type:String,
      default:""
      },
  cp_number_whatsapp: { 
      type:String,
      default:""
      },
  cp_text_api_zap: { 
      type:String,
      default:""
      },
  cp_endress: { 
      type:String,
      default:""
      },
  cp_email: { 
      type:String,
      default:""
      },
  tags_seo:[String],
  palavras_chave_word:[String], // Adicione este campo como uma matriz de strings
  frases_seo:[String],
  anuncio_loc: [
    {
      state: String,
      cities: [
        {
          name: String,
        },
      ],
    },
  ],
  word_text_frases: {
    type: [{}], // Define um array de objetos de qualquer tipo
    default: [], // Define um array vazio como valor padrão
  },
   ativo: {
    type: Boolean,
    default: false // Definir o padrão como false
  },
  img_principais: {
    type: [{}], // Define um array de objetos de qualquer tipo
    default: [], // Define um array vazio como valor padrão
  },


}, {
  collection: 'dados_user_login', // Substitua 'dados_empresa' pelo nome desejado da coleção
});




// Antes de salvar, use a função setSenha para definir a senha criptografada
UserSchema.pre('save', function (next) {
  if (this.isModified('password')) {
    this.password = setSenha(this.password);
  }

  if (this.isModified('ativo')) {
    this.ativo = false;
  }

 if (!this.s3pasta) {
    this.s3pasta = setRenderPast.call(this);
  }
  next();
});
//Neste código, o campo "senha" é definido simplesmente como uma string no esquema Mongoose, e a função setSenha é usada no middleware pre('save', ...) para definir a senha criptografada antes de salvar o documento no banco de dados. Isso é uma prática comum para lidar com senhas criptografadas em bancos de dados.



// Método para verificar a senha
UserSchema.methods.verifyPassword = function (password) {

  const keyword = 'ArcaWebAgencia2024';
  // Concatenar a palavra-chave à senha inserida pelo usuário
  const senhaComKeyword = password + keyword;

  // Comparar a senha inserida com a senha criptografada no banco de dados
  return bcrypt.compareSync(senhaComKeyword, this.senha);
};






// Função para criar um novo usuário com senha criptografada
/*UserSchema.pre('save', async function (next) {
  if (this.isModified('senha')) {

    const keyword = 'ArcaWebAgencia2024';


    const saltRounds = 10;
    const salt = bcrypt.genSaltSync(saltRounds);
       // Concatenar a palavra-chave à senha
    const senhaComKeyword = this.senha + keyword;

    const hashedPassword = bcrypt.hashSync(senhaComKeyword, salt);
    this.senha = hashedPassword;
  }
  next();
});*/



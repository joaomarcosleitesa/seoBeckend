
// user.module.ts
import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt'; // Importe o JwtModule
import { MongooseModule } from '@nestjs/mongoose';
import { UserService } from './user.service';
import { UserController } from './user.controller';
import { UserSchema } from './user.model';


// import Authservice 
import { jwtConstants } from '../auth/jwt.config'; // Importe a configuração JWT
import { AuthService } from '../auth/auth.service'; // Importe o AuthService
//import { databaseConnection } from '../databaseConnection'; // Importe a função de conexão

@Module({
  imports: [
    MongooseModule.forFeature([{ name: 'User', schema: UserSchema }]),
    JwtModule.register({
      secret: jwtConstants.secret,
      signOptions: { expiresIn: jwtConstants.expiresIn },
    }),

  ],
  controllers: [UserController],
  providers: [UserService, AuthService],
})
export class UserModule {}

// auth.service.ts
import { Injectable } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';

@Injectable()
export class AuthService {
  constructor(private readonly jwtService: JwtService) {}

  async generateToken(payload: any): Promise<string> {
    return this.jwtService.sign(payload);
  }


  async verifyToken(token: string): Promise<any> {
    try {
      return this.jwtService.verify(token);
    } catch (error) {
      throw new Error('Token inválido');
    }
  }

  async verifyTokenReturnDados(token: string): Promise<{ message: string , user:string, hostname:string, user_dominio:string, s3pasta:string, funcao:string}> {
    try {

      const decodedToken =this.jwtService.verify(token)
      return { message: 'autorizado',  user:  decodedToken.login, hostname:decodedToken.hostname, user_dominio:decodedToken.user_dominio, s3pasta:decodedToken.s3pasta, funcao:decodedToken.funcao };
     
    } catch (error) {
      throw new Error('Token inválido');
    }
  }
}



/*async verifyToken(token: string): Promise<any> {
    try {
      return this.jwtService.verify(token);
    } catch (error) {
      throw new Error('Token inválido');
    }
  }*/
import { IsString, IsNotEmpty, IsIn } from 'class-validator';

export class CreateUserDto {
  @IsString()
  @IsNotEmpty()
  login: string;

  @IsString()
  @IsNotEmpty()
  senha: string;

  @IsString()
  @IsNotEmpty()
  @IsIn(['masterAdmin', 'userComum', 'AdminEditor'])
  funcao: string;

  @IsString()
  @IsNotEmpty()
  dominio: string;

  @IsString()
  @IsNotEmpty()
  user_dominio: string;
}

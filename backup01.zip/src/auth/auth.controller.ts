// src/auth/auth.controller.ts
import { Controller, Post, Body, HttpStatus, HttpException } from '@nestjs/common';
import { AuthService } from './auth.service';

@Controller('auth')
export class AuthController {
  constructor(private readonly authService: AuthService) {}

  @Post('login')
  async login(@Body() userCredentials: any) {
    // Implemente a lógica de autenticação aqui usando o serviço AuthService.
    // Por exemplo, você pode chamar this.authService.login(userCredentials) para autenticar o usuário.

    const username =  userCredentials.username;
    const password =  userCredentials.password;
  


      // Retorne apenas o 'username' como resposta.
      return { username:  username , password:password};
   


    //return userCredentials;

  }
}
export const jwtConstants = {
  secret: '231fa4s9fd88w7er8q987@@90d8fasfdlsajk', // Substitua pela sua chave secreta
  expiresIn: '3h',
};
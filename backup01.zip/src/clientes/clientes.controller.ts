import { Controller, Get, Post, Body, Patch, Param, Delete, UnauthorizedException } from '@nestjs/common';
import { ClientesService } from './clientes.service';
import { ClienteSchema } from './clientes.model';

@Controller('clientes')
export class ClientesController {
  constructor(private readonly clientesService: ClientesService) {}



  @Post('create-new-client') // Rota para atualizar campos de SEO
  async createAnewCliente(
    @Body() updateDto: any,
    ) {

    try {


      //return {"msg":updateDto}

        //console.log("teste");
        //return updateDto;
        return this.clientesService.createNewClienteService(updateDto);
      }catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
      } else {
        throw new UnauthorizedException('Token inválido.');
      }
    }
  }


  @Post('find-all-clients') // Rota para atualizar campos de SEO
  async findAllClients(
    @Body() updateDto: any,
    ) {

    try {


      //return {"msg":updateDto}

        //console.log("teste");
        //return updateDto;
        return this.clientesService.findClientestOneUserToken(updateDto);
      }catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
      } else {
        throw new UnauthorizedException('Token inválido.');
      }
    }
  }


  @Post('find-one-client-id') // Rota para atualizar campos de SEO
  async findOneClientId(
    @Body() updateDto: any,
    ) {

    try {


      //return {"msg":updateDto}

        //console.log("teste");
        //return updateDto;
        return this.clientesService.findClienteId(updateDto);
      }catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
      } else {
        throw new UnauthorizedException('Token inválido.');
      }
    }
  }


   @Post('update-one-client-id') // Rota para atualizar campos de SEO
  async updateOneClientId(
    @Body() updateDto: any,
    ) {

    try {


      //return {"msg":updateDto}

        //console.log("teste");
        //return updateDto;
        return this.clientesService.updateClientSelect(updateDto);
      }catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
      } else {
        throw new UnauthorizedException('Token inválido.');
      }
    }
  }



  


 
}

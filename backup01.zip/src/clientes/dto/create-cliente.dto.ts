export class CreateClienteDto {}

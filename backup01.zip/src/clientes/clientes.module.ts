import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt'; // Importe o JwtModule

import { ClientesController } from './clientes.controller';
import { ClientesService } from './clientes.service';
import { ClienteSchema } from './clientes.model';
import { UserSchema } from '../user/user.model';
import { MongooseModule } from '@nestjs/mongoose';




// import Authservice 
import { jwtConstants } from '../auth/jwt.config'; // Importe a configuração JWT
import { AuthService } from '../auth/auth.service'; // Importe o AuthService

@Module({
  imports:[

    MongooseModule.forFeature([{ name: 'Clientes', schema: ClienteSchema}]),

    JwtModule.register({
      secret: jwtConstants.secret,
      signOptions: { expiresIn: jwtConstants.expiresIn },
    }),
    ],
  controllers: [ClientesController],
  providers: [ClientesService, AuthService],
})
export class ClientesModule {}

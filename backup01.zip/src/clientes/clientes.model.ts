import { Schema, Document } from 'mongoose';
const bcrypt = require('bcrypt');



export interface Cliente extends Document {
   

   cnpj: string;
   cpf: string;
   nomeCompleto: string;
   razaoSocial: string;
   nomeContato: string;
   telefone: string;
   email: string;
   cep: string;
   endereco: string;
   numero: string;
   complemento: string;
   bairro: string;
   cidade: string;
   estado: string;
   regiao: string;
   dataNascimento: string;
   codigoSku: string;
   nota: string;
   descricao: string;
   data_criacao: Date;
   idLogin:string;

}

// Defina o nome da coleção personalizado no esquema
export const ClienteSchema  = new Schema({


      cnpj: {
        type: String,
        default: ""
     },
     cpf: {
        type: String,
        default: ""
     },
     nomeCompleto: {
        type: String,
        default: ""
     },
     razaoSocial: {
        type: String,
        default: ""
     },
     nomeContato: {
        type: String,
        default: ""
     },
     telefone: {
        type: String,
        default: ""
     },
     email: {
        type: String,
        default: ""
     },
     cep: {
        type: String,
        default: ""
     },
     endereco: {
        type: String,
        default: ""
     },
     numero: {
        type: String,
        default: ""
     },
     complemento: {
        type: String,
        default: ""
     },
     bairro: {
        type: String,
        default: ""
     },
     cidade: {
        type: String,
        default: ""
     },
     estado: {
        type: String,
        default: ""
     },
     regiao: {
        type: String,
        default: ""
     },
     dataNascimento: {
        type: String,
        default: ""
     },
     codigoSku: {
        type: String,
        default: ""
     },
     nota: {
        type: String,
        default: ""
     },
     descricao: {
        type: String,
        default: ""
     },
     data_criacao: {
          type: Date,
          default: Date.now // Define a data atual como valor padrão
      },

      idLogin: {
          type: String,
          default: "" // Define a data atual como valor padrão
      },





  }, 



  {
    collection: 'clientes', // Substitua 'dados_empresa' pelo nome desejado da coleção
  });







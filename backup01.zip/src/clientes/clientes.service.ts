import { Injectable, NotFoundException, ConflictException, UnauthorizedException } from '@nestjs/common';
import { Model } from 'mongoose'; // Certifique-se de importar o Model do Mongoose
import { AuthService } from '../auth/auth.service'; // Importe o AuthService
import { Cliente } from './clientes.model';
import { InjectModel } from '@nestjs/mongoose'; // Importe o InjectModel para injetar o modelo


@Injectable()
export class ClientesService {


  constructor(
    @InjectModel('Clientes') 
      private readonly userCliente: Model<Cliente>,
      private readonly authService: AuthService,
    ) {}


   async createNewClienteService(updateDto: any) {

    try {
      // Valide os dados de entrada aqui, se necessário.
      // 
      // 
      

          const { 
                  cnpj,
                  cpf,
                  nomeCompleto,
                  razaoSocial,
                  nomeContato,
                  telefone,
                  email,
                  cep,
                  endereco,
                  numero,
                  complemento,
                  bairro,
                  cidade,
                  estado,
                  regiao,
                  dataNascimento,
                  codigoSku,
                  nota,
                  descricao


          } = updateDto.dados;


          const token = updateDto.token;

       const decodedToken = await this.authService.verifyToken(token);

       const {login} = decodedToken
       //return {"msgToken":decodedToken}

            if (cnpj !== "" ) {


                  // Verificar se o CNPJ ou CPF já existe
                  const existingCliente = await this.userCliente.findOne({ 
                  
                    $or: [{ cnpj: cnpj }],  
                    idLogin: login  

                  });

                  if (existingCliente) {
                    // Se o cliente já existir, retornar uma mensagem de erro
                    return {
                      success: false,
                      message: 'CNPJ já existe.',
                    };
                  }
          }


          if (cpf !== "" ) {


                  // Verificar se o CNPJ ou CPF já existe
                  const existingCliente = await this.userCliente.findOne({  
                  
                    $or: [{ cpf: cpf }],  
                    idLogin: login  

                  });

                  if (existingCliente) {
                    // Se o cliente já existir, retornar uma mensagem de erro
                    return {
                      success: false,
                      message: 'CPF já esta cadastrado.',
                    };
                  }
          }




          if (cnpj === "" && cpf === "") {



            return {
                      success: false,
                      message: 'CPF e CNPJ não pode ficar em  Branco.',
                    };



          }




      

  



      const newProduct = new this.userCliente({
          idLogin:login,
          cnpj:cnpj,
          cpf:cpf,
          nomeCompleto:nomeCompleto,
          razaoSocial:razaoSocial,
          nomeContato:nomeContato,
          telefone:telefone,
          email:email,
          cep:cep,
          endereco:endereco,
          numero:numero,
          complemento:complemento,
          bairro:bairro,
          cidade:cidade,
          estado:estado,
          regiao:regiao,
          dataNascimento:dataNascimento,
          codigoSku:codigoSku,
          nota:nota,
          descricao:descricao


      });

      const savedProduct = await newProduct.save();

      if (savedProduct) {
        return {
          success: true,
          message: 'Cliente salvo com sucesso!',
          product: savedProduct,
        };
      } else {
        return {
          success: false,
          message: 'Falha ao salvar o Clientes.',
        };
      }
    }catch (error) {
          // Lidar com erros de consulta, se necessário
            return {
              "msg":error.message,
              success: false,
            }
            throw new Error(`Erro ao buscar dados por login, token inválido: ${error.message}`);
        }
    }


    async findClientestOneUserToken(updateDto: any): Promise<{ dados: any; } | null> {
        try {



      // Valide os dados de entrada aqui, se necessário.
            const token = updateDto.token;



             const decodedToken = await this.authService.verifyToken(token);


          


        // Filtra todos os usuários ativos com os campos desejados
        const users = await this.userCliente
          .find({
            idLogin: decodedToken.login,
            //funcao: 'userComum'
            //funcao: 'userComum'
            // funcao: 'userComum' // Se desejar filtrar por 'funcao' também
          })
          .select({})
          .exec();

        // Retorna a lista de usuários que atendem aos critérios
        return { dados: users };
      } catch (error) {
        // Lidar com erros de consulta, se necessário
        throw new Error(`Erro ao buscar dados de usuários: ${error.message}`);
      }
        }

     async findClienteId(updateDto: any): Promise<{ dados: any; success:any} | null> {
        try {

          const clienteId = updateDto.clienteId;


        // Filtra todos os usuários ativos com os campos desejados
        const users = await this.userCliente
          .findOne({
            _id: clienteId ,
            //funcao: 'userComum'
            //funcao: 'userComum'
            // funcao: 'userComum' // Se desejar filtrar por 'funcao' também
          })
          .select({})
          .exec();

        // Retorna a lista de usuários que atendem aos critérios
        return { 
          dados: users,
          success:true
         };
      } catch (error) {
        // Lidar com erros de consulta, se necessário
        throw new Error(`Erro ao buscar dados de usuários: ${error.message}`);
      }
        }


async updateClientSelect(updateDto:any): Promise<{ dados: any; success:any; msg:any} | null>  {

    try {

      //return {dados:updateDto , success:false, msg:"erro"}
      //
      // const tokenVer = updateDto.token;
      const dados = updateDto.dados;
      const id = updateDto.id;



      const formData = {};

      const entriesArray = Object.entries(dados);

       //return {dados:id , success:false, msg:"erro"}
       //
       //

      const mappedArray = entriesArray.map(([key, value]) => {
                              // Aqui você pode aplicar a lógica desejada
                              // Por exemplo, apenas imprimir cada item
                              // 
                              // 
                              // 
                              if(key !=='__v'&& key !== '_id'&& key !== 'data_criacao'){

                                  formData[key] = value
                              }
                              //console.log(formData);
                              // Retornar o item ou qualquer transformação que você deseja aplicar
                              
                          });

      const jsonResult = JSON.stringify(formData);


      const json = {   
              nomeCompleto:dados.nomeCompleto,
              nomeContato:dados.nomeContato
       
            };

    //return {dados:formData , success:false, msg:"erro"}


  try{
    const user = await this.userCliente.findOneAndUpdate(
      {  _id:id },
          formData
      ,
      { new: true,
        //select: '*', 
        //select: 'hostname cp_seo cp_descript cp_analytics cp_telefone cp_url_site_principal cp_nome_empresa cp_link_facebook cp_link_instagram cp_number_whatsapp', 
      }, // Isso garante que o método retorne o usuário atualizado
    );

    if (!user) {

      return {dados:[], success:false, msg:"Usuário não encontrado"};
      throw new NotFoundException('Usuário não encontrado');
    }

    return {dados:user, success:true, msg:"Editado Com sucesso"};





     }

    catch (error) {
 console.error("Erro ao atualizar o usuário:", error);
}






     }catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
      } else {
        throw new UnauthorizedException('Token inválido.');
      }
    }

    
  }



  findAll() {
    return `This action returns all clientes`;
  }

  findOne(id: number) {
    return `This action returns a #${id} cliente`;
  }



  remove(id: number) {
    return `This action removes a #${id} cliente`;
  }
}

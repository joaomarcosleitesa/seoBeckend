export class CreateTicketDto {}

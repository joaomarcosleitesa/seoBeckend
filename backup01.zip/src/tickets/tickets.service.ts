

//Padrão 
//
//

import { Injectable, NotFoundException, ConflictException, UnauthorizedException } from '@nestjs/common';
import { Model } from 'mongoose'; // Certifique-se de importar o Model do Mongoose
import { InjectModel } from '@nestjs/mongoose'; // Importe o InjectModel para injetar o modelo

import { TicketsInt } from './tickets.model';

import { AuthService } from '../auth/auth.service'; // Importe o AuthService
import { UserService } from '../user/user.service'; // Importe o AuthService


@Injectable()
export class TicketsService {


  constructor(
    @InjectModel('Tickets') 
    private readonly userModelTicket: Model<TicketsInt>, 
    private readonly authService: AuthService,
    private readonly userService: UserService

    ) {}


  async createNewTicketService(updateDto: any): Promise<{ dados: any; success:any; msg:any} | null>  {


    try {

          const token = updateDto.token;

          const decodedToken = await this.authService.verifyToken(token);

          const {login} = decodedToken;


          const formData = {};

          const dados = updateDto.dados;
          const id = updateDto.id;

          const entriesArray = Object.entries(dados);

          formData['idLogin'] = login;


          const mappedArray = entriesArray.map(([key, value]) => {
                // Aqui você pode aplicar a lógica desejada
                // Por exemplo, apenas imprimir cada item
                // 
                // 
                // 
                if(key !=='__v'&& key !== '_id'&& key !== 'data_criacao'){

                    formData[key] = value
                }
                //console.log(formData);
                // Retornar o item ou qualquer transformação que você deseja aplicar
                
            });

          const newServicos = new this.userModelTicket(
          
            formData

          );



         

          const savedServicos = await newServicos.save();




          if (savedServicos) {
            return {
              dados:formData,
              success: true,
              "msg": 'Cliente salvo com sucesso!',
            };
          } else {
            return {
              dados:[],
              success: false,
              "msg": 'Falha ao salvar o Clientes.',
            };
          }







    }catch (error) {
          // Lidar com erros de consulta, se necessário
            return {
              dados:[],
              "msg":'Erro ao buscar dados por login, token inválido: ' +error.message,
              success: false,
            }
            throw new Error(`Erro ao buscar dados por login, token inválido: ${error.message}`);
        }



  }



  async findTicketOneUserToken( updateDto: any): Promise <{ dados: any; success:any; } | null> {
        try {



      // Valide os dados de entrada aqui, se necessário.
            const token = updateDto.token;



             const decodedToken = await this.authService.verifyToken(token);


          


              // Filtra todos os usuários ativos com os campos desejados
              const users = await this.userModelTicket
                .find({
                  idLogin: decodedToken.login,
                  //funcao: 'userComum'
                  //funcao: 'userComum'
                  // funcao: 'userComum' // Se desejar filtrar por 'funcao' também
                })
                .sort({ dataCriacao: -1 }) // Ordena os resultados por data em ordem ascendente
                .select({})
                .exec();

              // Retorna a lista de usuários que atendem aos critérios
              return { dados: users, success:true };
            } catch (error) {
              // Lidar com erros de consulta, se necessário
              // 
              return { dados: 'Erro ao buscar dados de usuários', success:false }
              throw new Error(`Erro ao buscar dados de usuários: ${error.message}`);
            }
      }

async findTicketIDTicketToken( updateDto: any): Promise <{ dados: any; success:any; } | null> {
        try {



      // Valide os dados de entrada aqui, se necessário.
            const token = updateDto.token;
            const id_ticket =updateDto.id_ticket



             const decodedToken = await this.authService.verifyToken(token);


          


              // Filtra todos os usuários ativos com os campos desejados
              const users = await this.userModelTicket
                .find({
                  idLogin: decodedToken.login,
                   _id:id_ticket
                  //funcao: 'userComum'
                  //funcao: 'userComum'
                  // funcao: 'userComum' // Se desejar filtrar por 'funcao' também
                })
               // .sort({ dataCriacao: -1 }) // Ordena os resultados por data em ordem ascendente
                .select({})
                .exec();

              // Retorna a lista de usuários que atendem aos critérios
              return { dados: users, success:true };
            } catch (error) {
              // Lidar com erros de consulta, se necessário
              // 
              return { dados: 'Erro ao buscar dados de usuários', success:false }
              throw new Error(`Erro ao buscar dados de usuários: ${error.message}`);
            }
      }


async updateTicketsSelect(updateDto:any): Promise<{ dados: any; success:any; msg:any} | null>  {

    try {

      //return {dados:updateDto , success:false, msg:"erro"}
      //
      // const tokenVer = updateDto.token;
      const dados = updateDto.dados;
      const id = updateDto.id;

      const id_ticket = updateDto.id_ticket



      const formData = {};



      const entriesArray = Object.entries(dados);

       //return {dados:id , success:false, msg:"erro"}
       //
       //

      const mappedArray = entriesArray.map(([key, value]) => {
                              // Aqui você pode aplicar a lógica desejada
                              // Por exemplo, apenas imprimir cada item
                              // 
                              // 
                              // 
                              if(key !=='__v'&& key !== '_id'&& key !== 'data_criacao'){

                                  formData[key] = value
                              }
                              //console.log(formData);
                              // Retornar o item ou qualquer transformação que você deseja aplicar
                              
                          });

 


                  try{
                    const user = await this.userModelTicket.findOneAndUpdate(
                      {  _id:id_ticket},
                          formData
                      ,
                      { new: true,
                        //select: '*', 
                        //select: 'hostname cp_seo cp_descript cp_analytics cp_telefone cp_url_site_principal cp_nome_empresa cp_link_facebook cp_link_instagram cp_number_whatsapp', 
                      }, // Isso garante que o método retorne o usuário atualizado
                    );

                    if (!user) {

                      return {dados:[], success:false, msg:"Usuário não encontrado"};
                      throw new NotFoundException('Usuário não encontrado');
                    }

                    return {dados:user, success:true, msg:"Editado Com sucesso"};





                     }

                  catch (error) {
               console.error("Erro ao atualizar o usuário:", error);
              }






     }catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
      } else {
        throw new UnauthorizedException('Token inválido.');
      }
    }

    
  }

  findAll() {
    return `This action returns all tickets`;
  }

  findOne(id: number) {
    return `This action returns a #${id} ticket`;
  }



  remove(id: number) {
    return `This action removes a #${id} ticket`;
  }
}

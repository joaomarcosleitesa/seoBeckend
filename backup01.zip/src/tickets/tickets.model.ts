import { Schema, Document , model} from 'mongoose';
const bcrypt = require('bcrypt');





export interface TicketsInt extends Document {

 


idLogin: string;
 titulo: string;
 descricao: string;
 dataCriacao: Date;
 numeroTicket: string;
 idTicketSku: string;
 status: 'Novo' | 'Aberto' | 'Encerrado' | 'Resolvido';
 tipo: 'Suporte' | 'Atendimento' | 'Problemas' | 'Servico.';
 prioridade: 'Baixa' | 'Media' | 'Alta' | 'Extremo';
 historicoAtendimento: Array<{
    dataAtualizacao: Date;
    descricao: string;
 }>;
 solucao: string;

 notas: string;
  id_cliente: string;
  id_produto: string;
  id_servico: string;
  nome_cliente: string;
  nome_produto: string;
  nome_servico: string;

}

// Defina o nome da coleção personalizado no esquema
export const TicketsSchema  = new Schema({

        idLogin: { type: String, default: "" },
       titulo: { type: String, default: "" },
     descricao: { type: String, default: "" },
     dataCriacao: { type: Date, default: Date.now },
     numeroTicket: { type: String, default: "" },
     idTicketSku: { type: String, default: "" },
     status: { type: String, enum: ['Novo', 'Aberto', 'Encerrado', 'Resolvido'], default: 'Novo' },
     tipo: { type: String, enum: ['Suporte', 'Atendimento', 'Problemas', 'Servico'], default: 'Suporte' },
     prioridade: { type: String, enum: ['Baixa', 'Media', 'Alta', 'Extremo'], default: 'Suporte' },
     historicoAtendimento: [{
        dataAtualizacao: { type: Date, default: Date.now },
        descricao: { type: String, default: "" },
     }],
     solucao: { type: String, default: "" },
     notas: { type: String, default: "" },
     id_cliente: { type: String, default: "" },
     id_produto: { type: String, default: "" },
     id_servico: { type: String, default: "" },

     nome_cliente: { type: String, default: "" },
     nome_produto: { type: String, default: "" },
     nome_servico: { type: String, default: "" },
  }, 



  {
    collection: 'tickets', // Substitua 'dados_empresa' pelo nome desejado da coleção
  });









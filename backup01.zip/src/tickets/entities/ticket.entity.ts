export class Ticket {}

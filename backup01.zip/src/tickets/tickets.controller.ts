import { Controller, Get, Post, Body, Patch, Param, Delete, UnauthorizedException } from '@nestjs/common';
import { TicketsService } from './tickets.service';


@Controller('tickets')
export class TicketsController {
  constructor(private readonly ticketsService: TicketsService) {}



   @Post('create-new-ticket') // Rota para atualizar campos de SEO
  async createAnewCliente(
    @Body() updateDto: any,
    ) {

    try {


      //return {"msg":updateDto}

        //console.log("teste");
        //return updateDto;
        return this.ticketsService.createNewTicketService(updateDto);
      }catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
      } else {
        throw new UnauthorizedException('Token inválido.');
      }
    }
  }



  @Post('find-all-tickets') // Rota para atualizar campos de SEO
  async findAllServicos(
    @Body() updateDto: any,
    ) {

    try {


      //return {"msg":updateDto}

        //console.log("teste");
        //return updateDto;
        return this.ticketsService.findTicketOneUserToken(updateDto);
      }catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
      } else {
        throw new UnauthorizedException('Token inválido.');
      }
    }
  }




  @Post('find-one-ticket-by-id') // Rota para atualizar campos de SEO
  async findOneTicketById(
    @Body() updateDto: any,
    ) {

    try {


      //return {"msg":updateDto}

        //console.log("teste");
        //return updateDto;
        return this.ticketsService.findTicketIDTicketToken(updateDto);
      }catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
      } else {
        throw new UnauthorizedException('Token inválido.');
      }
    }
  }



  @Post('update-one-ticket-id') // Rota para atualizar campos de SEO
  async updateOneTicktId(
    @Body() updateDto: any,
    ) {

    try {


      //return {"msg":updateDto}

        //console.log("teste");
        //return updateDto;
        return this.ticketsService.updateTicketsSelect(updateDto);
      }catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
      } else {
        throw new UnauthorizedException('Token inválido.');
      }
    }
  }









  @Get()
  findAll() {
    return this.ticketsService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.ticketsService.findOne(+id);
  }

 

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.ticketsService.remove(+id);
  }
}

import { PartialType } from '@nestjs/mapped-types';
import { CreateS3uploadDto } from './create-s3upload.dto';

export class UpdateS3uploadDto extends PartialType(CreateS3uploadDto) {}

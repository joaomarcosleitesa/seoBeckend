export class CreateS3uploadDto {}

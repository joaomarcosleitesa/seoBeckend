import { Test, TestingModule } from '@nestjs/testing';
import { S3uploadController } from './s3upload.controller';
import { S3uploadService } from './s3upload.service';

describe('S3uploadController', () => {
  let controller: S3uploadController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [S3uploadController],
      providers: [S3uploadService],
    }).compile();

    controller = module.get<S3uploadController>(S3uploadController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});



import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
import { S3uploadService } from './s3upload.service';
import { CreateS3uploadDto } from './dto/create-s3upload.dto';
import { UpdateS3uploadDto } from './dto/update-s3upload.dto';




@Controller('s3-bucket')
export class S3uploadController {
  private readonly bucketName = 'arcawebbuscas'; // Bucket predefinido
  //private readonly folderName = 'criemos-um-teste'; // Pasta predefinida



  constructor(
    private readonly s3uploadService: S3uploadService,
    

    ) {}

  @Post('past')
  create(@Body() createS3uploadDto: CreateS3uploadDto) {
    return this.s3uploadService.create(createS3uploadDto);
  }




/*

json = {
          token: newCookie, 
          fileName: "logo-smalltop",
          fileType:'.png'
          
    } 

*/

  @Post('presigned-url-img')
    async generatePresignedUrl(@Body() payload: { fileName: string , fileType:string,  token: string }): Promise<{ presignedUrl: string }> {
      

      const {token} = payload;
      const { fileName } = payload;
      const { fileType } = payload;
      const bucket = this.bucketName;
      //const folder = this.folderName;

      const presignedUrl = await this.s3uploadService.generatePresignedUrl(bucket, fileName, fileType, token);

      return { presignedUrl };
    }

   @Post('presigned-url-img-mult')
  async generatePresignedUrlMult(@Body() payload: { fileNames: string[], fileType: string, token: string }): Promise<{ presignedUrls: Array<{ s3: string, time: string }> }> {
      

      const { token, fileNames, fileType } = payload;
      const bucket = this.bucketName;

      const presignedUrls = await this.s3uploadService.generatePresignedUrlsMult(bucket, fileNames, fileType, token);

      return { presignedUrls };
  }



  @Get()
  findAll() {
    return this.s3uploadService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.s3uploadService.findOne(+id);
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() updateS3uploadDto: UpdateS3uploadDto) {
    return this.s3uploadService.update(+id, updateS3uploadDto);
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.s3uploadService.remove(+id);
  }
}

//aws-s3-config.ts

export const awsS3Config = {
  endpoint: 'https://usc1.contabostorage.com',
  use_path_style_endpoint: true,
  use_aws_shared_config_files: false,
  version: 'latest',
  region: 'usc1',
  credentials: {
    key: '1843e1f53cfa4d9ab9422171c5f8df70',
    secret: '18c7e44e03a497c0ec9eb41ed8b5221d',
  },
};
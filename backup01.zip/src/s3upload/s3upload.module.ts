//s3upload.module.ts
import { Module } from '@nestjs/common';
import { S3uploadService } from './s3upload.service';
import { S3uploadController } from './s3upload.controller';
import { AwsS3Service } from './aws-s3.service'; // Importe o serviço



//import auth.module
import { JwtModule } from '@nestjs/jwt';
import { jwtConstants } from '../auth/jwt.config';
import { AuthService} from '../auth/auth.service';


@Module({

  imports: [
    JwtModule.register({
      secret: jwtConstants.secret,
      signOptions: { expiresIn: jwtConstants.expiresIn },
    }),
  ],

  controllers: [S3uploadController],
  providers: [S3uploadService, AwsS3Service, AuthService],
})
export class S3uploadModule {}

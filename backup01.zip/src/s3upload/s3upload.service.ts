//s3upload.service.ts

import { S3 } from 'aws-sdk';
import {Injectable, Inject  } from '@nestjs/common';
import { awsS3Config } from './aws-s3-config'; 
import { CreateS3uploadDto } from './dto/create-s3upload.dto';
import { UpdateS3uploadDto } from './dto/update-s3upload.dto';
import { AwsS3Service } from './aws-s3.service'; // Importe o serviço AWS S3
import { FileInterceptor } from '@nestjs/platform-express'; // Importe o FileInterceptor do NestJS
import { JwtService } from '@nestjs/jwt';

//AUTH token
import {AuthService} from '../auth/auth.service';


const setRenderPast  = () => {

  const alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let randomLetters = '';

  for (let i = 0; i < 36; i++) {
    const randomIndex = Math.floor(Math.random() * alphabet.length);
    randomLetters += alphabet.charAt(randomIndex);
  }
  const keyword = '-arcaweb-seo-'+randomLetters;
 
  return keyword;
};



@Injectable()
export class S3uploadService {

  private s3: S3;

  constructor(
      //private readonly awsS3Service: AwsS3Service, 
      //private readonly authService: AuthService, // Injeção do AuthService
    

    ) {

       this.s3 = new S3({
      endpoint: awsS3Config.endpoint,
      s3ForcePathStyle: true, // Use estilo de caminho de estilo de URL (necessário para o DigitalOcean Spaces)
      accessKeyId: awsS3Config.credentials.key,
      secretAccessKey: awsS3Config.credentials.secret,
      region: awsS3Config.region,
    });
  }
  @Inject(AuthService) private readonly authService: AuthService;

  @Inject(AwsS3Service) private readonly awsS3Service: AwsS3Service;




  async create(createS3uploadDto: CreateS3uploadDto) {
    // Verifique e crie a pasta no AWS S3 se necessário
    const bucketName = 'arcawebbuscas'; // Substitua pelo nome do seu bucket
    const folderName = setRenderPast(); // Substitua pelo nome da pasta desejada

    await this.awsS3Service.createFolderIfNotExists(bucketName, folderName);

    try {
      // Verifique e crie a pasta no AWS S3 se necessário
      await this.awsS3Service.createFolderIfNotExists(bucketName, folderName);

      // Se a pasta foi criada com sucesso ou já existia, você pode retornar uma resposta de sucesso
      return {
        pasta: true,
        message: 'Pasta verificada/criada com sucesso no AWS S3!',
        folderName: folderName,
      };
    } catch (error) {
      // Se ocorrer um erro ao verificar/criar a pasta, retorne uma resposta de erro
      return {
        pasta: false,
        error: 'Erro ao verificar/criar pasta no AWS S3.',
        details: error.message, // Se desejar, você pode incluir detalhes do erro
      };
    }
  }





async generatePresignedUrlsMult(bucket: string, fileNames: string[], fileType: string, token: string): Promise<any> {
  try {
    const decodedToken = await this.authService.verifyTokenReturnDados(token);
    let mimeType = '';
    let typeFile = '';

    if (fileType === 'png') {
      mimeType = 'image/png';
      typeFile = '.png';
    } else if (fileType === 'jpg' || fileType === 'jpeg') {
      mimeType = 'image/jpeg';
      typeFile = '.jpeg';
    } else {
      return {
        error: 'Erro fileType faltando ou errado, pode ser png, jpg ou jpeg',
      };
    }

   
    const folderSelc = decodedToken.s3pasta;

    const presignedUrls = [];

    for (const fileName of fileNames) {

      const leterCodi = setRenderPast();

      const arqName: string = fileName + leterCodi + typeFile;
      const key = `${folderSelc}/${arqName}`;

      const params = {
        Bucket: bucket,
        Key: key,
        Expires: 1200,
        ContentType: mimeType,
      };

      const data = await this.s3.getSignedUrlPromise('putObject', params);
      const time: string = (params.Expires / 60) + ' Min';

      presignedUrls.push({ s3: data, time });
    }

    return presignedUrls;
  } catch (error) {
    return {
      error: 'Erro token expirado ou inválidos.',
      details: error.message,
    };
  }
}












/*
    {
        "fileType":"png",
      "fileName": "nome-do-arquivo",
      "token":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJsb2dpbiI6Im1hcmNvc2xlaXRlIiwiaG9zdG5hbWUiOiJ0cmFmZWdvLXBhZ28uYXJjYXdlYi5jb20uYnIiLCJ1c2VyX2RvbWluaW8iOiJ0cmFmZWdvYXJjYXdlYiIsInMzcGFzdGEiOiJtYXJjb3NsZWl0ZS1hcmNhd2ViLXNlby1icE1TVFZmQ2dIdWQiLCJpYXQiOjE2OTU3NDE0ODEsImV4cCI6MTY5NTc1MjI4MX0.n2-9adDyoSZFpXtAHnCA0yGj5-WVhJo9C0mIwR1-VOQ"
    }
return
{
    "presignedUrl": "https://usc1.contabostorage.com/arcawebbuscas/criemos-um-teste/nome-do-arquivo.jpg?AWSAccessKeyId=1843e1f53cfa4d9ab9422171c5f8df70&Content-Type=image%2Fjpeg&Expires=1695737206&Signature=6SiDi%2F11danGfceu915dRnEyOdM%3D"
}
*/




   async generatePresignedUrl(bucket: string,  fileName: string, fileType: string, token: string): Promise<any> {
    
     
 
   
      try {

        const decodedToken =  await this.authService.verifyTokenReturnDados(token);

        
           let mimeType="";
           let typeFile = "";

        if(fileType==="png"){

            mimeType ='image/png' 
            typeFile ='.png';

        }else if(fileType==="jpg" || fileType==="jpeg" ){
            mimeType ='image/jpeg'
            typeFile ='.jpeg';

        }else{

          return {
            error: 'Erro fileType faltando ou errado, pode ser png, jpg ou jpeg'
        };


        }


        const leterCodi =setRenderPast();

        const folderSelc = decodedToken.s3pasta;
        const arqName:string = fileName+leterCodi+typeFile;
        const key = `${folderSelc}/${arqName}`;



        //const mimeType = fileType==="png" ? 'image/png' : 'image/jpeg';

        const params = {
          Bucket: bucket, // Use o bucket fornecido como argumento
          Key: key,
          Expires: 1200, // O URL expirará em 60 segundos (ajuste conforme necessário)
          ContentType: mimeType,  // Defina o tipo de conteúdo apropriado para o seu caso
        };

        const dados = await  this.s3.getSignedUrlPromise('putObject', params);
        const time:string=  (params.Expires /60) +' Min';


        return {"s3":dados, "time": time };



      }catch (error) {


        return {
            error: 'Erro token expirado ou inválidos.',
            details: error.message, // Se desejar, você pode incluir detalhes do erro
        };


      }




   
  }



  findAll() {
    return `This action returns all s3upload`;
  }

  findOne(id: number) {
    return `This action returns a #${id} s3upload`;
  }

  update(id: number, updateS3uploadDto: UpdateS3uploadDto) {
    return `This action updates a #${id} s3upload`;
  }

  remove(id: number) {
    return `This action removes a #${id} s3upload`;
  }
}

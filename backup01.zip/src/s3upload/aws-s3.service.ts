// aws-s3.service.ts
import { Injectable } from '@nestjs/common';
import { S3 } from 'aws-sdk';
import { awsS3Config } from './aws-s3-config'; // Importe as configurações

@Injectable()
export class AwsS3Service {
  private s3: S3;

  constructor() {
    this.s3 = new S3({
      endpoint: awsS3Config.endpoint,
      s3ForcePathStyle: true, // Use estilo de caminho de estilo de URL (necessário para o DigitalOcean Spaces)
      accessKeyId: awsS3Config.credentials.key,
      secretAccessKey: awsS3Config.credentials.secret,
      region: awsS3Config.region,
    });
  }

  async createFolderIfNotExists(bucketName: string, folderName: string): Promise<void> {
    try {
      const listObjectsResponse = await this.s3
        .listObjectsV2({
          Bucket: bucketName,
          Prefix: `${folderName}/`,
        })
        .promise();

      // Se a pasta não existir, listeObjectsResponse.Contents.length será igual a 0
      if (listObjectsResponse.Contents.length === 0) {
        // Crie a pasta
        await this.s3
          .putObject({
            Bucket: bucketName,
            Key: `${folderName}/`, // Certifique-se de adicionar uma barra para representar uma pasta vazia
            Body: '', // Conteúdo vazio
          })
          .promise();
      }
    } catch (error) {
      console.error('Erro ao verificar/criar pasta no AWS S3:', error);
      throw error;
    }
  }
}



//Padrão 
//
//

import { Injectable, NotFoundException, ConflictException, UnauthorizedException } from '@nestjs/common';
import { Model } from 'mongoose'; // Certifique-se de importar o Model do Mongoose
import { InjectModel } from '@nestjs/mongoose'; // Importe o InjectModel para injetar o modelo

import { ServicosInt } from './servicos.model';

import { AuthService } from '../auth/auth.service'; // Importe o AuthService
import { UserService } from '../user/user.service'; // Importe o AuthService


@Injectable()
export class ServicosService {

  constructor(
    @InjectModel('Servicos') 
    private readonly userModelServicos: Model<ServicosInt>, 
    private readonly authService: AuthService,
    private readonly userService: UserService

    ) {}


   async createNewServicosService(updateDto: any): Promise<{ dados: any; success:any; msg:any} | null>  {


    try {

          const token = updateDto.token;

          const decodedToken = await this.authService.verifyToken(token);

          const {login} = decodedToken


          const formData = {};

          const dados = updateDto.dados;
          const id = updateDto.id;

          const entriesArray = Object.entries(dados);






          //id_cliente
          //
          //

          formData['idLogin'] = login;

          const mappedArray = entriesArray.map(([key, value]) => {
                // Aqui você pode aplicar a lógica desejada
                // Por exemplo, apenas imprimir cada item
                // 
                // 
                // 
                if(key !=='__v'&& key !== '_id'&& key !== 'data_criacao'){

                    formData[key] = value
                }
                //console.log(formData);
                // Retornar o item ou qualquer transformação que você deseja aplicar
                
            });


          /*return {
              dados:formData,
              success: true,
              "msg": 'Cliente salvo com sucesso!',
            };*/







          const newServicos = new this.userModelServicos(
          
            formData

          );



         

          const savedServicos = await newServicos.save();




          if (savedServicos) {
            return {
              dados:formData,
              success: true,
              "msg": 'Cliente salvo com sucesso!',
            };
          } else {
            return {
              dados:[],
              success: false,
              "msg": 'Falha ao salvar o Clientes.',
            };
          }





   }catch (error) {
          // Lidar com erros de consulta, se necessário
            return {
              dados:[],
              "msg":'Erro ao buscar dados por login, token inválido: ' +error.message,
              success: false,
            }
            throw new Error(`Erro ao buscar dados por login, token inválido: ${error.message}`);
        }



   }


   async findServiceOneUserToken( updateDto: any): Promise <{ dados: any; success:any; } | null> {
        try {



      // Valide os dados de entrada aqui, se necessário.
            const token = updateDto.token;

            const id_cliente = updateDto.clienteId;



             const decodedToken = await this.authService.verifyToken(token);


          


              // Filtra todos os usuários ativos com os campos desejados
              const users = await this.userModelServicos
                .find({
                  idLogin: decodedToken.login,
                  id_cliente:id_cliente
                  //funcao: 'userComum'
                  //funcao: 'userComum'
                  // funcao: 'userComum' // Se desejar filtrar por 'funcao' também
                })
                .sort({ data: -1 }) // Ordena os resultados por data em ordem ascendente
                .select({})
                .exec();

              // Retorna a lista de usuários que atendem aos critérios
              return { dados: users, success:true };
            } catch (error) {
              // Lidar com erros de consulta, se necessário
              // 
              return { dados: 'Erro ao buscar dados de usuários', success:false }
              throw new Error(`Erro ao buscar dados de usuários: ${error.message}`);
            }
      }






  findAll() {
    return `This action returns all servicos`;
  }

  findOne(id: number) {
    return `This action returns a #${id} servico`;
  }


  remove(id: number) {
    return `This action removes a #${id} servico`;
  }
}

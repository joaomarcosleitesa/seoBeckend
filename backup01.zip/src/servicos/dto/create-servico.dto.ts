export class CreateServicoDto {}

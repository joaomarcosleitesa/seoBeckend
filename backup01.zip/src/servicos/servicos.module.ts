

import { ServicosService } from './servicos.service';
import { ServicosController } from './servicos.controller';

//import Schema Service
import { ServiSchema } from './servicos.model';



//PADRÃO PARA TODOS
//--------------------------------------------------------------------

import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt'; // Importe o JwtModule


//mongose Module import
import { MongooseModule } from '@nestjs/mongoose';

//User service para o Authservice Funcionar 
import { UserSchema } from '../user/user.model';
import { UserService } from '../user/user.service'; // Importe o AuthService

// import Authservice 
import { jwtConstants } from '../auth/jwt.config'; // Importe a configuração JWT
import { AuthService } from '../auth/auth.service'; // Importe o AuthService





@Module({
  imports:[
    MongooseModule.forFeature([{ name: 'Servicos', schema: ServiSchema }]),
    MongooseModule.forFeature([{ name: 'User', schema: UserSchema }]),
    JwtModule.register({
      secret: jwtConstants.secret,
      signOptions: { expiresIn: jwtConstants.expiresIn },
    }),
    ],
  controllers: [ServicosController],
  providers: [ServicosService, AuthService, UserService],
})
export class ServicosModule {}

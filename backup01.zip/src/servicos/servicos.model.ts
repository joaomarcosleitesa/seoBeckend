import { Schema, Document , model} from 'mongoose';
const bcrypt = require('bcrypt');





export interface ServicosInt extends Document {
      
   idLogin:string;
   id_cliente: string;
   nome_cliente: string;
   codigo_sku: string;
   descricao: string;
   data: string;
   hora: string;
   problema_relatado: string;
   orcamento: string;
   servicos: string;
   prazos_de_entrega: string;
   garantia: string;
   descricao_equipamentos: string;
   observacoes: string;
   tecnico: string;
   condicoes_de_pagamento: string;
   endereco: string;
   numero_ordem_servico: number; // This field will be auto-incremented
   atendente:string;
   title_servico:string;
   

}

// Defina o nome da coleção personalizado no esquema
export const ServiSchema  = new Schema({


       idLogin: { type: String, default: "" },
       id_cliente: { type: String, default: "" },
       nome_cliente: { type: String, default: "" },
       codigo_sku: { type: String, default: "" },
       descricao: { type: String, default: "" },
       data: { type: String, default: "" },
       hora: { type: String, default: "" },
       problema_relatado: { type: String, default: "" },
       orcamento: { type: String, default: "" },
       servicos: { type: String, default: "" },
       prazos_de_entrega: { type: String, default: "" },
       garantia: { type: String, default: "" },
       descricao_equipamentos: { type: String, default: "" },
       observacoes: { type: String, default: "" },
       tecnico: { type: String, default: "" },
       condicoes_de_pagamento: { type: String, default: "" },
       endereco: { type: String, default: "" },
       numero_ordem_servico: { type: Number, default: 0 },
       atendente: { type: String, default: "" },
       title_servico: { type: String, default: "" },





  }, 



  {
    collection: 'servicos', // Substitua 'dados_empresa' pelo nome desejado da coleção
  });









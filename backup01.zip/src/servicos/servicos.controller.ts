import { Controller, Get, Post, Body, Patch, Param, Delete, UnauthorizedException } from '@nestjs/common';
import { ServicosService } from './servicos.service';




//PAD



@Controller('servicos')
export class ServicosController {
  constructor(private readonly servicosService: ServicosService) {}


  @Post('create-new-servico') // Rota para atualizar campos de SEO
  async createAnewCliente(
    @Body() updateDto: any,
    ) {

    try {


      //return {"msg":updateDto}

        //console.log("teste");
        //return updateDto;
        return this.servicosService.createNewServicosService(updateDto);
      }catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
      } else {
        throw new UnauthorizedException('Token inválido.');
      }
    }
  }



  @Post('find-all-servico') // Rota para atualizar campos de SEO
  async findAllServicos(
    @Body() updateDto: any,
    ) {

    try {


      //return {"msg":updateDto}

        //console.log("teste");
        //return updateDto;
        return this.servicosService.findServiceOneUserToken(updateDto);
      }catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
      } else {
        throw new UnauthorizedException('Token inválido.');
      }
    }
  }

  

  @Get()
  findAll() {
    return this.servicosService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.servicosService.findOne(+id);
  }

 

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.servicosService.remove(+id);
  }
}

export class Search {}

export class CreateSearchDto {}

import { Injectable, NotFoundException, ConflictException, UnauthorizedException } from '@nestjs/common';
import { Model } from 'mongoose'; // Certifique-se de importar o Model do Mongoose
import { InjectModel } from '@nestjs/mongoose'; // Importe o InjectModel para injetar o modelo
import * as bcrypt from 'bcrypt'; // Certifique-se de importar o módulo bcrypt
import { User} from '../user/user.model';

import { AuthService } from '../auth/auth.service'; // Importe o AuthService


@Injectable()
export class SearchUserService {

  
  constructor(@InjectModel('User') private readonly userModel: Model<User>, 
    private readonly authService: AuthService) {}



  async findUsersByKeyword(search: string): Promise<User[]> {

    const regex = new RegExp(search, 'i'); // 'i' para tornar a busca case-insensitive

    return this.userModel
      .find({
        ativo: true,
        funcao: 'userComum',
        palavras_chave_word: regex,
      })
      .select({
        hostname: 1,
        user_dominio: 1,
        s3pasta: 1,
        cp_nome_empresa: 1,
        cp_number_whatsapp: 1,
        cp_text_api_zap: 1,
        palavras_chave_word: 1,
        tags_seo: 1,
        anuncio_loc: 1,
        img_principais: 1,
        cp_descript: 1,
        cp_telefone: 1
      })
      .exec();
 }


 async findUsersByTagsSeo(search: string): Promise<User[]> {

   //const regex = new RegExp(`[${search.normalize("NFD").replace(/[\u0300-\u036f]/g, "")}]`, 'i');
   const regex = new RegExp(search, 'i'); // 'i' para tornar a busca case-insensitive


    return this.userModel
      .find({
        ativo: true,
        funcao: 'userComum',
        tags_seo: regex,
      })
      .select({
        hostname: 1,
        user_dominio: 1,
        s3pasta: 1,
        cp_nome_empresa: 1,
        cp_number_whatsapp: 1,
        cp_text_api_zap: 1,
        palavras_chave_word: 1,
        tags_seo: 1,
        anuncio_loc: 1,
        img_principais: 1,
        cp_descript: 1,
        cp_telefone: 1
      })
      .exec();
 }






   async findKeyWord_dadosEmpresa(search: any): Promise<{dados:any} | null> {
        try {
  // Filtra todos os usuários ativos com os campos desejados
  
        //const search = dados.search;
        //
        //
        //

          //return {dados: search }

        const usersKeywords = await this.findUsersByKeyword(search);


          if(usersKeywords.length==0){

                  const usersTags= await this.findUsersByTagsSeo(search);

                  return { dados: usersTags };


            
          }else{

              // Retorna a lista de usuários que atendem aos critérios
              return { dados: usersKeywords };


          }

        
      } catch (error) {
        // Lidar com erros de consulta, se necessário
        throw new Error(`Erro ao buscar dados de usuários: ${error.message}`);
      }
        }




  
}

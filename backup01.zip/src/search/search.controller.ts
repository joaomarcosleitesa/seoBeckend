
import { Controller, Get, Post, Body, Patch, Param, Delete ,Req, UnauthorizedException} from '@nestjs/common';

import { SearchService } from './search.service';
import { User} from '../user/user.model';
import { Search} from './search.model';


//IMPORT OUTRO MODULOS
import { SearchUserService  } from './search.user.service';
import { AuthService } from '../auth/auth.service'; // Importe o AuthService

@Controller('search')
export class SearchController {
  constructor(
      private readonly searchService: SearchService,
      private readonly searchUserService: SearchUserService,
      private readonly authService: AuthService
    ) {}


      @Post('find_key_word_parceiros') // Rota para atualizar campos de SEO
        async findKeyWord_dadosEmpresa(
          @Body() dados: any,
          ) {

              const search = dados.search;
             
              const dadosUsuario = await this.searchUserService.findKeyWord_dadosEmpresa(search);
              return {dadosUsuario}
         
        }



  @Get()
  findAll() {
    return this.searchService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.searchService.findOne(+id);
  }

 

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.searchService.remove(+id);
  }
}

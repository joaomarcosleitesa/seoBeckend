import { Schema, Document } from 'mongoose';


export interface Search extends Document {
  login: string,
  password: string,
  hostname: string,
  user_dominio: string,
  cp_seo:string,
  cp_descript:string,
  cp_analytcs:string,
  cp_telefone:string,
  cp_url_site_principal:string,
  cp_nome_empresa:string,
  cp_link_facebook:string,
  cp_link_instagram:string,
  cp_number_whatsapp:string,
  cp_text_api_zap:string,
  cp_endress:string,
  cp_email:string,
  tags_seo:string[],
  palavras_chave_word:string[],
  frases_seo:string[],
  anuncio_loc: {
    state: string;
    cities: { name: string }[];
  }[],
   word_text_frases:any[],
  ativo: boolean,
  img_principais: {
    [key: string]: string;
  }[],



}

// Defina o nome da coleção personalizado no esquema
export const SearchSchema  = new Schema({


  login: { 
      type:String,
      default:""
      },
  password: { 
      type:String,
      default:""
      },
  hostname: { 
      type:String,
      default:""
      },
  user_dominio: { 
      type:String,
      default:""
      },

  cp_seo: { 
      type:String,
      default:""
      },
  cp_descript: { 
      type:String,
      default:""
      },
  cp_analytcs: { 
      type:String,
      default:""
      },
  cp_telefone: { 
      type:String,
      default:""
      },
  cp_url_site_principal: { 
      type:String,
      default:""
      },
  cp_nome_empresa: { 
      type:String,
      default:""
      },
  cp_link_facebook: { 
      type:String,
      default:""
      },
  cp_link_instagram: { 
      type:String,
      default:""
      },
  cp_number_whatsapp: { 
      type:String,
      default:""
      },
  cp_text_api_zap: { 
      type:String,
      default:""
      },
  cp_endress: { 
      type:String,
      default:""
      },
  cp_email: { 
      type:String,
      default:""
      },
  tags_seo:[String],
  palavras_chave_word:[String], // Adicione este campo como uma matriz de strings
  frases_seo:[String],
  anuncio_loc: [
    {
      state: String,
      cities: [
        {
          name: String,
        },
      ],
    },
  ],
  word_text_frases: {
    type: [{}], // Define um array de objetos de qualquer tipo
    default: [], // Define um array vazio como valor padrão
  },
   ativo: {
    type: Boolean,
    default: false // Definir o padrão como false
  },
  img_principais: {
    type: [{}], // Define um array de objetos de qualquer tipo
    default: [], // Define um array vazio como valor padrão
  },


}, {
  collection: 'dados_empresa', // Substitua 'dados_empresa' pelo nome desejado da coleção
});






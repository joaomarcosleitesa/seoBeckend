import { Controller, Get, Post, Body, Patch, Param, Delete } from '@nestjs/common';
import { CepsService } from './ceps.service';
import { CreateCepDto } from './dto/create-cep.dto';
import { UpdateCepDto } from './dto/update-cep.dto';

@Controller('ceps')
export class CepsController {
  constructor(private readonly cepsService: CepsService) {}

  @Post()
  create(@Body() createCepDto: CreateCepDto) {
    return this.cepsService.create(createCepDto);
  }

  // RETORNA TODAS AS SIGLAS DE CIDADES DO BRASIl
  /*

  */
  // http://localhost:3370/ceps/all-uf
  @Post('alluf')
  async findAllUf() {

    console.log("teste");

     const ufs = await this.cepsService.findAlluf();
    return ufs; // Isso irá retornar a lista de todos os documentos na coleção "uf"
  }

/*
    {
        "uf": "MG"
    }
  
  http://localhost:3370/ceps/all-city
*/
  @Post('all-city')
  async findAllCity(@Body() data: { uf: string }) {


    const dados = data.uf;

     const ufs = await this.cepsService.findAllCity({ uf: dados});
    return ufs; // Isso irá retornar a lista de todos os documentos na coleção "uf"
  }


  @Post('all-bairros')
  async findAllBairros(@Body() data: { city: string }) {


    const dados = data.city;

     const respot = await this.cepsService.findAllBairros({ city: dados});
    return respot; // Isso irá retornar a lista de todos os documentos na coleção "uf"
  }

  @Get()
  findAll() {
    return this.cepsService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.cepsService.findOne(+id);
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() updateCepDto: UpdateCepDto) {
    return this.cepsService.update(+id, updateCepDto);
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.cepsService.remove(+id);
  }
}

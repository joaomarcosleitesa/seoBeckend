//ceps.service.ts


//mongodb://localhost/ceps
import * as diacritics from 'diacritics';
import { CreateCepDto } from './dto/create-cep.dto';
import { UpdateCepDto } from './dto/update-cep.dto';


import { Injectable , Logger} from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';


//import { MongooseModule } from '@nestjs/mongoose';
import { uf } from './models/uf.model';
import { city } from './models/city.model';


@Injectable()
export class CepsService{

  constructor(

    @InjectModel('uf') private readonly ufModel: Model<any>,
    @InjectModel('city') private readonly cityModel: Model<any>

    ) {}



  async findAlluf(): Promise<any[]> {
      const ufDocuments = await this.ufModel.find({}).exec();
      const ufs = ufDocuments.map((doc) => ({ uf: doc.uf }));
      return ufs;
    }

  /*
        {
          "uf":"MG"
      }
  */

async findAllCity({ uf }: { uf: string }): Promise<any[]> {
      try {

        const txt:string = uf
        const dado = txt.toUpperCase();

        const aggregation = [
          {
            $match: {
               UF_Est: dado, // Use a versão em maiúsculas de 'uf' na consulta
            },
          },
          {
            $group: {
              _id: '$UF_sig',
              count: { $sum: 1 }, // Contar quantas vezes cada UF_sig aparece
            },
          },
          {
            $project: {
              _id: 0, // Remover o campo "_id" do resultado
              UF_sig: '$_id',
            },
          },

        ];

        const result = await this.cityModel.aggregate(aggregation).sort({ UF_sig: 1 }).exec();
        return result;

      } catch (error) {
        // Lidar com erros, se necessário
        throw new Error(`Erro ao buscar usuário por login: ${error.message}`);
      }



  }


  async findAllBairros({ city }: { city: string }): Promise<any[]> {

    try {

        const normalizedCity = diacritics.remove(city); // Remova acentos da cidade

const aggregation = [
          {
            $match: {
              UF_sig: {
                $regex: new RegExp(normalizedCity, 'i'), // Use $regex com a opção 'i' para correspondência insensível a maiúsculas/minúsculas
              },
            },
          },
          {
            $group: {
              _id: '$bairro',
              count: { $sum: 1 }, // Contar quantas vezes cada bairro aparece
            },
          },
          {
            $project: {
              _id: 0, // Remover o campo "_id" do resultado
              bairro: '$_id',
            },
          },
        ];

        const result = await this.cityModel.aggregate(aggregation).sort({ bairro: 1 }).exec();
        return result;

      } catch (error) {
        // Lidar com erros, se necessário
        throw new Error(`Erro ao buscar usuário por login: ${error.message}`);
      }






  }


  create(createCepDto: CreateCepDto) {
    return 'This action adds a new cep';
  }

  findAll() {
    return `This action returns all ceps`;
  }

  

  findOne(id: number) {
    return `This action returns a #${id} cep`;
  }

  update(id: number, updateCepDto: UpdateCepDto) {
    return `This action updates a #${id} cep`;
  }

  remove(id: number) {
    return `This action removes a #${id} cep`;
  }
}

// uf.model.ts


import { Prop,  SchemaFactory } from '@nestjs/mongoose';
import { Schema, Document } from 'mongoose';

export class uf extends Document {}


export const UfSchema  = new Schema({
  uf: String,
  //password: String,

}, {
  collection: 'uf', // Substitua 'dados_empresa' pelo nome desejado da coleção
});

//export const UfSchema = SchemaFactory.createForClass(Uf);
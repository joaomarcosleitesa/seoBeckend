// uf.model.ts


import { Prop,  SchemaFactory } from '@nestjs/mongoose';
import { Schema, Document } from 'mongoose';

export class city extends Document {}


export const CitySchema  = new Schema({
  cep: String,
  Uf: String,
  bairro: String,
  rua: String,
  infor: String,
  UF_Est: String,
  UF_sig: String,
  //password: String,

}, {
  collection: 'pais', // Substitua 'dados_empresa' pelo nome desejado da coleção
});

//export const UfSchema = SchemaFactory.createForClass(Uf);
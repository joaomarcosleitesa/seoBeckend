//databaseUf.schemas.ts


import * as mongoose from 'mongoose';

export const UfSchema = new mongoose.Schema({
  uf: String
});
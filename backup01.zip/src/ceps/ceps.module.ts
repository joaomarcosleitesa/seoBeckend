//ceps.module.ts
import { Module } from '@nestjs/common';



import { CepsService } from './ceps.service';
import { CepsController } from './ceps.controller';
import { MongooseModule } from '@nestjs/mongoose';
import { uf, UfSchema } from './models/uf.model';
import { city, CitySchema } from './models/city.model';


@Module({

    imports: [
 
  
       MongooseModule.forFeature([{ name: 'uf', schema: UfSchema }]), 
        MongooseModule.forFeature([{ name: 'city', schema: CitySchema}]), 
  ],



  controllers: [CepsController],
  providers: [CepsService ],
})
export class CepsModule {}

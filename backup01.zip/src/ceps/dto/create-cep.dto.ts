export class CreateCepDto {}

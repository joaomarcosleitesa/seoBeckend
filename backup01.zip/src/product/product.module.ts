import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt'; // Importe o JwtModule
import { ProductService } from './product.service';
import { ProductController } from './product.controller';
import { ProdSchema } from './product.model';
import { UserSchema } from '../user/user.model';
import { MongooseModule } from '@nestjs/mongoose';
import { UserService } from '../user/user.service'; // Importe o AuthService

// import Authservice 
import { jwtConstants } from '../auth/jwt.config'; // Importe a configuração JWT
import { AuthService } from '../auth/auth.service'; // Importe o AuthService


@Module({
  imports:[
    MongooseModule.forFeature([{ name: 'Product', schema: ProdSchema }]),
    MongooseModule.forFeature([{ name: 'User', schema: UserSchema }]),
    JwtModule.register({
      secret: jwtConstants.secret,
      signOptions: { expiresIn: jwtConstants.expiresIn },
    }),
    ],
  controllers: [ProductController],
  providers: [ProductService , AuthService, UserService],
})
export class ProductModule {}

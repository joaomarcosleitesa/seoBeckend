import { Controller, Get, Post, Body, Patch, Param, Delete, UnauthorizedException } from '@nestjs/common';
import { ProductService } from './product.service';
import { CreateProductDto } from './dto/create-product.dto';
import { UpdateProductDto } from './dto/update-product.dto';
import { ProdSchema } from './product.model';


@Controller('product')
export class ProductController {
  constructor(private readonly productService: ProductService) {}

  @Post('create-new-product') // Rota para atualizar campos de SEO
  async createAnewProduct(
    @Body() updateDto: any,
    ) {

    try {


      //return {"msg":updateDto}

        //console.log("teste");
        //return updateDto;
        return this.productService.createNewProductService(updateDto);
      }catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
      } else {
        throw new UnauthorizedException('Token inválido.');
      }
    }
  }



  @Post('create-new-product-adult') // Rota para atualizar campos de SEO
  async createAnewProductAdult(
    @Body() updateDto: any,
    ) {

    try {


      //return {"msg":updateDto}

        //console.log("teste");
        //return updateDto;
        return this.productService.createNewProductServiceAdult(updateDto);
      }catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
      } else {
        throw new UnauthorizedException('Token inválido.');
      }
    }
  }


  @Post('find-allproduct') // Rota para atualizar campos de SEO
  async findAllProducts(
    @Body() updateDto: any,
    ) {

    try {


      //return {"msg":updateDto}

        //console.log("teste");
        //return updateDto;
        return this.productService.findProductOneUser(updateDto);
      }catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
      } else {
        throw new UnauthorizedException('Token inválido.');
      }
    }
  }



  @Post('find-allproduct-token') // Rota para atualizar campos de SEO
  async findAllProductsToken(
    @Body() updateDto: any,
    ) {

    try {


      //return {"msg":updateDto}

        //console.log("teste");
        //return updateDto;
        return this.productService.findProductOneUserToken(updateDto);
      }catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
      } else {
        throw new UnauthorizedException('Token inválido.');
      }
    }
  }



    @Post('find-allproduct-hostname') // Rota para atualizar campos de SEO
  async findAllProductsHostname(
    @Body() updateDto: any,
    ) {

    try {


      //return {"msg":updateDto}

        //console.log("teste");
        //return updateDto;
        return this.productService.findProductOneUserHostname(updateDto);
      }catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
      } else {
        throw new UnauthorizedException('Token inválido.');
      }
    }
  }



  @Post('find-one-product-id') // Rota para atualizar campos de SEO
  async findOneProductId(
    @Body() updateDto: any,
    ) {

    try {


      //return {"msg":updateDto}

        //console.log("teste");
        //return updateDto;
        return this.productService.findProduct(updateDto);
      }catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
      } else {
        throw new UnauthorizedException('Token inválido.');
      }
    }
  }



  @Post('find-product-partners') // Rota para atualizar campos de SEO
  async findproductpartners(
    @Body() updateDto: any,
    ) {

    try {


      //return {"msg":updateDto}

        //console.log("teste");
        //return updateDto;
        return this.productService.findProductPatners(updateDto);
      }catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
      } else {
        throw new UnauthorizedException('Token inválido.');
      }
    }
  }




  @Post('find-product-partnersAdult') // Rota para atualizar campos de SEO
  async findproductpartnersAdult(
    @Body() updateDto: any,
    ) {

    try {


      //return {"msg":updateDto}

        //console.log("teste");
        //return updateDto;
        return this.productService.findProductPatnersAdult(updateDto);
      }catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
      } else {
        throw new UnauthorizedException('Token inválido.');
      }
    }
  }



   @Post('update-product-select') // Rota para atualizar campos de SEO
  async updateProductSelect(
    @Body() updateDto: any,
    ) {

    try {


      //return {"msg":updateDto}

        //console.log("teste");
        //return updateDto;
        return this.productService.updateProductSelect(updateDto);
      }catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
      } else {
        throw new UnauthorizedException('Token inválido.');
      }
    }
  }

 

  @Get()
  findAll() {
    return this.productService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.productService.findOne(+id);
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() updateProductDto: UpdateProductDto) {
    return this.productService.update(+id, updateProductDto);
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.productService.remove(+id);
  }
}

import { Schema, Document } from 'mongoose';
const bcrypt = require('bcrypt');



export interface Product extends Document {
  titulo_anuncio: string;
  tel: string;
  whatsapp: string;
  preco: string;
  sku: string;
  text_box: string;
  cep: {
    campo_cep: string;
    cidade: string;
    uf: string;
    bairro: string;
    endereco: string;
    numero: string;
    compl: string;
  };
  tags_seo: string[];
  hostname: string;
  login: string;
  user_dominio: string;
  s3pasta: string;
  adulto:number;
  vendido:number;
  esgotado:number;
  ativo:number;
  fotos_imgs: string[];
  data: Date;




}

// Defina o nome da coleção personalizado no esquema
export const ProdSchema  = new Schema({


  titulo_anucio: { 
      type:String,
      default:""
      },

  tel: { 
      type:String,
      default:""
      },

  whatsapp: { 
      type:String,
      default:""
      },

  preco: { 
      type:String,
      default:""
      },

  sku: { 
      type:String,
      default:""
      },

  text_box: { 
      type:String,
      default:""
      },


  cep: {
    campo_cep: {
      type: String,
      default: ''
    },
    cidade: {
      type: String,
      default: ''
    },
    uf: {
      type: String,
      default: ''
    },
    bairro: {
      type: String,
      default: ''
    },
    endereco: {
      type: String,
      default: ''
    },
    numero: {
      type: String,
      default: ''
    },
    compl: {
      type: String,
      default: ''
    }
  },

    tags_seo: {
      type: [String],  // Defina o campo como um array de strings
      default: []  // Defina um array vazio como valor padrão
    },

  hostname: { 
      type:String,
      default:""
      },

  login: { 
      type:String,
      default:""
      },

  user_dominio: { 
      type:String,
      default:""
      },

  s3pasta: { 
      type:String,
      default:""
      },


    adulto: {
        type: Number,
        default: 0
    },

    vendido: {
        type: Number,
        default: 0
    },


    esgotado: {
        type: Number,
        default: 0
    },

    ativo: {
        type: Number,
        default: 1
    },


  fotos_imgs: {
      type: [String],  // Defina o campo como um array de strings
      default: []  // Defina um array vazio como valor padrão
    },


    data_criacao: {
          type: Date,
          default: Date.now // Define a data atual como valor padrão
  },





  }, 



  {
    collection: 'js_produtos', // Substitua 'dados_empresa' pelo nome desejado da coleção
  });







import { Injectable, NotFoundException, ConflictException, UnauthorizedException } from '@nestjs/common';
import { Model } from 'mongoose'; // Certifique-se de importar o Model do Mongoose
import { InjectModel } from '@nestjs/mongoose'; // Importe o InjectModel para injetar o modelo
import { CreateProductDto } from './dto/create-product.dto';
import { UpdateProductDto } from './dto/update-product.dto';
import { Product } from './product.model';
import { AuthService } from '../auth/auth.service'; // Importe o AuthService
import { UserService } from '../user/user.service'; // Importe o AuthService

@Injectable()
export class ProductService {

   constructor(
    @InjectModel('Product') 
    private readonly userModel: Model<Product>, 
    private readonly authService: AuthService,
    private readonly userService: UserService

    ) {}


 async createNewProductService(updateDto: any) {

    try {
      // Valide os dados de entrada aqui, se necessário.
      const token = updateDto.token;

       const decodedToken = await this.authService.verifyToken(token);
       //return {"msgToken":decodedToken}

      const { imgUrls, describ, title } = updateDto;
      //const pastaS3 = imgsUrls[0].pastaS3;

      const nomeImageArray = imgUrls.map((item) => item.nomeImage);;




      const newProduct = new this.userModel({
        text_box: describ,
        titulo_anucio:title,
        fotos_imgs:nomeImageArray,
        hostname:decodedToken.hostname, 
        login:decodedToken.login,
        s3pasta:decodedToken.s3pasta,
        user_dominio:decodedToken.user_dominio


      });

      const savedProduct = await newProduct.save();

      if (savedProduct) {
        return {
          success: true,
          message: 'Produto salvo com sucesso!',
          product: savedProduct,
        };
      } else {
        return {
          success: false,
          message: 'Falha ao salvar o produto.',
        };
      }
    }catch (error) {
          // Lidar com erros de consulta, se necessário
            return {
              "msg":error.message,
              success: true,
            }
            throw new Error(`Erro ao buscar dados por login: ${error.message}`);
        }
    }



     async createNewProductServiceAdult(updateDto: any) {

    try {
      // Valide os dados de entrada aqui, se necessário.
      const token = updateDto.token;

       const decodedToken = await this.authService.verifyToken(token);
       //return {"msgToken":decodedToken}

      const { imgUrls, describ, title } = updateDto;
      //const pastaS3 = imgsUrls[0].pastaS3;

      const nomeImageArray = imgUrls.map((item) => item.nomeImage);;




      const newProduct = new this.userModel({
        text_box: describ,
        titulo_anucio:title,
        fotos_imgs:nomeImageArray,
        hostname:decodedToken.hostname, 
        login:decodedToken.login,
        s3pasta:decodedToken.s3pasta,
        user_dominio:decodedToken.user_dominio,
        adulto:1


      });

      const savedProduct = await newProduct.save();

      if (savedProduct) {
        return {
          success: true,
          message: 'Produto salvo com sucesso!',
          product: savedProduct,
        };
      } else {
        return {
          success: false,
          message: 'Falha ao salvar o produto.',
        };
      }
    }catch (error) {
          // Lidar com erros de consulta, se necessário
            return {
              "msg":error.message,
              success: true,
            }
            throw new Error(`Erro ao buscar dados por login: ${error.message}`);
        }
    }



      async findProductOneUserToken(updateDto: any): Promise<{ dados: any; } | null> {
        try {



      // Valide os dados de entrada aqui, se necessário.
            const token = updateDto.token;

             const decodedToken = await this.authService.verifyToken(token);


        // Filtra todos os usuários ativos com os campos desejados
        const users = await this.userModel
          .find({
            login: decodedToken.login,
            //funcao: 'userComum'
            //funcao: 'userComum'
            // funcao: 'userComum' // Se desejar filtrar por 'funcao' também
          })
          .select({})
          .exec();

        // Retorna a lista de usuários que atendem aos critérios
        return { dados: users };
      } catch (error) {
        // Lidar com erros de consulta, se necessário
        throw new Error(`Erro ao buscar dados de usuários: ${error.message}`);
      }
        }




  async findProductOneUser(updateDto: any): Promise<{ dados: any; } | null> {
        try {

    const login = updateDto.login;


  // Filtra todos os usuários ativos com os campos desejados
  const users = await this.userModel
    .find({
      login: login,
      //funcao: 'userComum'
      //funcao: 'userComum'
      // funcao: 'userComum' // Se desejar filtrar por 'funcao' também
    })
    .select({})
    .exec();

  // Retorna a lista de usuários que atendem aos critérios
  return { dados: users };
} catch (error) {
  // Lidar com erros de consulta, se necessário
  throw new Error(`Erro ao buscar dados de usuários: ${error.message}`);
}
  }




  async findProductOneUserHostname(updateDto: any): Promise<{ dados: any; } | null> {
        try {

    const login = updateDto.login;


  // Filtra todos os usuários ativos com os campos desejados
  const users = await this.userModel
    .find({
      user_dominio: login,
      //funcao: 'userComum'
      //funcao: 'userComum'
      // funcao: 'userComum' // Se desejar filtrar por 'funcao' também
    })
    .select({})
    .exec();

  // Retorna a lista de usuários que atendem aos critérios
  return { dados: users };
} catch (error) {
  // Lidar com erros de consulta, se necessário
  throw new Error(`Erro ao buscar dados de usuários: ${error.message}`);
}
  }



  async findProduct(updateDto: any): Promise<{ dados: any; } | null> {
        try {

    const productId = updateDto.productId;


  // Filtra todos os usuários ativos com os campos desejados
  const users = await this.userModel
    .findOne({
      _id: productId ,
      //funcao: 'userComum'
      //funcao: 'userComum'
      // funcao: 'userComum' // Se desejar filtrar por 'funcao' também
    })
    .select({})
    .exec();

  // Retorna a lista de usuários que atendem aos critérios
  return { dados: users };
} catch (error) {
  // Lidar com erros de consulta, se necessário
  throw new Error(`Erro ao buscar dados de usuários: ${error.message}`);
}
  }



  async findProductPatners(updateDto: any): Promise<{ dados: any; } | null> {
        try {


   const allparceiros = await this.userService.findParceirosProducts();
    const allDados =allparceiros.dados;
   //return {dados :allDados};
    const id ="";


 const products = [];

    for (const data of allDados) {
      const userDominio = data.user_dominio;

      // Consulta todos os produtos com base no user_dominio
      const userProducts = await this.userModel.find({ user_dominio:userDominio, adulto:0 });

      if (userProducts.length > 0) {
        // Gere um índice aleatório
        const randomIndex = Math.floor(Math.random() * userProducts.length);

        // Selecione um produto aleatório
        const randomProduct = userProducts[randomIndex];

        products.push(randomProduct);
      }
    }

    return { dados: products };

} catch (error) {
  // Lidar com erros de consulta, se necessário
  throw new Error(`Erro ao buscar dados de usuários: ${error.message}`);
}
  }






  async findProductPatnersAdult(updateDto: any): Promise<{ dados: any; } | null> {
        try {


   const allparceiros = await this.userService.findParceirosProducts();
    const allDados =allparceiros.dados;
   //return {dados :allDados};
    const id ="";


 const products = [];

    for (const data of allDados) {
      const userDominio = data.user_dominio;

      // Consulta todos os produtos com base no user_dominio
      const userProducts = await this.userModel.find({ user_dominio:userDominio});

      if (userProducts.length > 0) {
        // Gere um índice aleatório
        const randomIndex = Math.floor(Math.random() * userProducts.length);

        // Selecione um produto aleatório
        const randomProduct = userProducts[randomIndex];

        products.push(randomProduct);
      }
    }

    return { dados: products };

} catch (error) {
  // Lidar com erros de consulta, se necessário
  throw new Error(`Erro ao buscar dados de usuários: ${error.message}`);
}
  }



   async updateProductSelect(updateDto:any) {

    try {

      //return {dados:updateDto}


      const tokenVer = updateDto.token;
      const campo = updateDto.campo;
      const state = updateDto.state;
      const id = updateDto.id;


   


      // Verifique o token usando o AuthService
      const decodedToken = await this.authService.verifyToken(tokenVer);
      
    const login = decodedToken.login;

    let campoSelect ={};



    if(campo=="ativo"){
          campoSelect = { 
              ativo:updateDto.state
       
            }
      }


      if(campo=="vendido"){
          campoSelect = { 
              vendido:updateDto.state
       
            }
      }

      if(campo=="esgotado"){
          campoSelect = { 
              esgotado:updateDto.state
       
            }
      }

    const user = await this.userModel.findOneAndUpdate(
      { login: login, _id:id },
      campoSelect
      ,
      { new: true,
        select: 'ativo esgotado vendido', 
        //select: 'hostname cp_seo cp_descript cp_analytics cp_telefone cp_url_site_principal cp_nome_empresa cp_link_facebook cp_link_instagram cp_number_whatsapp', 
      }, // Isso garante que o método retorne o usuário atualizado
    );

    if (!user) {
      throw new NotFoundException('Usuário não encontrado');
    }

    return user;





    }
     catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
      } else {
        throw new UnauthorizedException('Token inválido.');
      }
    }

    
  }



  
  

  findAll() {
    return `This action returns all product`;
  }

  findOne(id: number) {
    return `This action returns a #${id} product`;
  }

  update(id: number, updateProductDto: UpdateProductDto) {
    return `This action updates a #${id} product`;
  }

  remove(id: number) {
    return `This action removes a #${id} product`;
  }
}

import { ValidationPipe } from '@nestjs/common';
import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import mongoose from 'mongoose';
import { Logger } from '@nestjs/common';

async function bootstrap() {

  const app = await NestFactory.create(AppModule);
  app.useGlobalPipes(new ValidationPipe());


  app.enableCors({
     origin:[
            '*',
            'https://dashloginseo.arcaweb.com.br',
            'https://www.dashloginseo.arcaweb.com.br',
            'http://localhost:3000',
            'http://192.168.1.100',
            'http://localhost:3001',
            'http://localhost:3002',
            'http://localhost:3003',
            'http://localhost:3004',
            'http://localhost:3005',
            'https://desentupidora-24hrs.desentupidoragrandebh.com.br',
            'https://www.desentupidora-24hrs.desentupidoragrandebh.com.br',
            'https://desentupidoragrandebh.com.br',
            'http://209.126.1.106',
            'https://pecas-fiat.cappecasbh.com.br',
            'https://www.pecas-fiat.cappecasbh.com.br',
            'http://158.220.83.209',
            '158.220.83.209',
            'https://oficina-mecanica.arcaweb.com.br',
            'https://www.oficina-mecanica.arcaweb.com.br',
            'https://arvveiculoscontagem.com.br',
            'https://www.arvveiculoscontagem.com.br',
            'https://mecanica.arthmaliaautocenter.com.br',
            'https://www.mecanica.arthmaliaautocenter.com.br',
            'https://extintor-de-incendio.extingfirebh.com.br',
            'https://www.extintor-de-incendio.extingfirebh.com.br',
            'https://poda-de-arvores.jaguarsa.com.br',
            'https://www.poda-de-arvores.jaguarsa.com.br',
            'https://seo-para-empresas.arcaweb.com.br',
            'https://www.seo-para-empresas.arcaweb.com.br',
            'https://gas-eldorado.arcaweb.com.br',
            'https://www.gas-eldorado.arcaweb.com.br',
            'https://veterinaria-daqui-dali.arcaweb.com.br',
            'https://www.veterinaria-daqui-dali.arcaweb.com.br',
            'https://cacambas-contagem.cacambasnenem.com.br',
            'https://wwww.cacambas-contagem.cacambasnenem.com.br',
            'https://aluguel-de-cacambas.cacambaseldorado.com.br',
            'https://www.aluguel-de-cacambas.cacambaseldorado.com.br',
            'https://mecanica.arthmaliaautocenter.com.br',
            'https://www.mecanica.arthmaliaautocenter.com.br',
            'https://andrade576.arcaweb.com.br',
            'https://www.andrade576.arcaweb.com.br',
            'https://www.buscas.arcaweb.com.br',
            'https://buscas.arcaweb.com.br',
            'https://www.corrimaoinoxbh.lfinoxbh.com.br',
            'https://corrimaoinoxbh.lfinoxbh.com.br',
            'https://bhsegurosaude.com.br',
            'https://www.bhsegurosaude.com.br'
        ] ,
  //origin: 'https://dashloginseo.arcaweb.com.br/, *, http://localhost:3000', // Especifique a origem permitida
  methods: 'GET,HEAD,PUT,PATCH,POST,DELETE', // Métodos permitidos
  credentials: true, // Permite credenciais (por exemplo, cookies)
});

  //Teste de conexão com o MongoDB
  // try {
  //   await mongoose.connect('mongodb://localhost/ceps');
  //   Logger.log('Conexão com o MongoDB estabelecida com sucesso', 'Mongoose');
  // } catch (error) {
  //   Logger.error('Erro ao conectar ao MongoDB: ' + error.message, '', 'Mongoose');
  // }



  await app.listen(3574, '0.0.0.0');
}
bootstrap();

import { Injectable } from '@nestjs/common';
import { Model } from 'mongoose'; // Certifique-se de importar o Model do Mongoose
import { InjectModel } from '@nestjs/mongoose'; // Importe o InjectModel para injetar o modelo
import { Cat, CatSchema } from './cats.model';
import { CreateCatDto } from './dto/create-cat.dto'; // Caminho correto

@Injectable()
export class CatsService {
  constructor(@InjectModel('Cat') private readonly catModel: Model<Cat>) {}

  async create(catData: CreateCatDto): Promise<Cat> {
    try {
      const createdCat = new this.catModel(catData);
      const savedCat = await createdCat.save();

      console.log('Cat saved:', savedCat);
      return savedCat;
    } catch (error) {
      console.error('Error creating cat:', error);
      throw error;
    }
  }


  async findAll(): Promise<Cat[]> {
    return await this.catModel.find().exec();
  }

  async findOne(id: string): Promise<Cat> {
    return await this.catModel.findById(id).exec();
  }

  async update(id: string, catData: CreateCatDto): Promise<Cat> {
    return await this.catModel.findByIdAndUpdate(id, catData, { new: true }).exec();
  }

  async remove(id: string): Promise<Cat> {
    return await this.catModel.findByIdAndRemove(id).exec();
  }
}
import { Controller, Get, Post, Put, Delete, Param, Body , HttpException, HttpStatus} from '@nestjs/common';
import { CreateCatDto } from './dto/create-cat.dto'; // Caminho correto
import { CatsService } from './cats.services';



@Controller('cats')
export class CatsController {

  constructor(private readonly catsService: CatsService) {}

  
  @Get()
  findAll(): string {
    return 'Lista de todos os gatos';
  }

  @Get(':id')
  findOne(@Param('id') id: string): string {
    return `Detalhes do gato com o ID ${id}`;
  }

  @Post()
async create(@Body() catData: CreateCatDto): Promise<string> {
  try {
    // Adicione um console.log para verificar os dados recebidos
    //console.log(catData);
    const createdCat = await this.catsService.create(catData);

    
    const { name, age, raca } = catData;

    console.log(name, age, raca);

    // Sua lógica de criação de gato aqui
    console.log(name)
    return `Gato criado com sucesso. Nome: ${catData.name} Age: ${catData.age} Raca: ${catData.raca}`;
  } catch (error) {
    throw new HttpException('Erro de validação', HttpStatus.BAD_REQUEST);
    //console.error(error);
    //return 'Erro ao criar o gato.';
  }
}

  @Put(':id')
  update(@Param('id') id: string, @Body() catData: CreateCatDto): string {
    // Aqui você pode adicionar lógica para atualizar um gato no banco de dados
    return `Gato com o ID ${id} atualizado. Novo nome: ${catData.name}`;
  }

  @Delete(':id')
  remove(@Param('id') id: string): string {
    // Aqui você pode adicionar lógica para excluir um gato do banco de dados
    return `Gato com o ID ${id} removido com sucesso`;
  }
}

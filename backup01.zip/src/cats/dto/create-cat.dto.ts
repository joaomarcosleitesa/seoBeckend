import { IsString, IsInt, MinLength,MaxLength } from 'class-validator';

export class CreateCatDto {
  @IsString()
  @MinLength(3)
  @MaxLength(6)
  name: string;

  @IsInt()
  age: number;

  @IsString()
  @MinLength(4)
  raca:string;
}

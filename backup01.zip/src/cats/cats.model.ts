import { Schema, Document } from 'mongoose';

export interface Cat extends Document {
  name: string;
  age: number;
  raca: string;
}

export const CatSchema = new Schema({
  name: String,
  age: Number,
  raca: String,
});
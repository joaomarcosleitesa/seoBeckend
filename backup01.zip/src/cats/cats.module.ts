// cats.module.ts
import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { CatsService } from './cats.services';
import { CatsController } from './cats.controller';
import { CatSchema } from './cats.model';
//import { databaseConnection } from '../databaseConnection'; // Importe a função de conexão

@Module({
  imports: [
    MongooseModule.forFeature([{ name: 'Cat', schema: CatSchema }]),
    MongooseModule.forRootAsync({
      useFactory: async () => {
        //const connection = await databaseConnection(); // Chame a função aqui
        return {
          uri: 'mongodb://localhost/shop_bd',
        };
      },
    }),
  ],
  controllers: [CatsController],
  providers: [CatsService],
})
export class CatsModule {}

import { Schema, Document } from 'mongoose';
const mongoose = require('mongoose');


export interface financ extends Document {
  hostname: string;
  categoria: string;
  login: string;
  user_dominio: string;
  subCategoria: string[];
  tipo_entrada_saida: string;
  data: string;
  dia: number;
  mes: number;
  ano: number;
  descricao:string;
  valor:number;
  
}

// Defina o nome da coleção personalizado no esquema
export const FinancSchema  = new Schema({


  hostname: { 
      type:String,
      default:""
      },

  categoria: { 
      type:String,
      default:""
      },




  login: { 
      type:String,
      default:""
      },

  user_dominio: { 
      type:String,
      default:""
      },

  
  subCategoria: {
      type: [String],  // Defina o campo como um array de strings
      default: []  // Defina um array vazio como valor padrão
    },

  tipo_entrada_saida: { 
      type:String,
      default:""
      },

  data: { 
      type:String,
      default:""
      },


  dia: {
     type: Number,
     default: 0
 },




     mes: {
         type: Number,
         default: 0
     },
     ano: {
         type: Number,
         default: 0
     },

     descricao: { 
      type:String,
      default:""
      },


      valor: { 
      type: mongoose.Schema.Types.Decimal128,
      default:""
      },


    },

  {
      collection: 'financ_emp', // Substitua 'dados_empresa' pelo nome desejado da coleção
 

  });







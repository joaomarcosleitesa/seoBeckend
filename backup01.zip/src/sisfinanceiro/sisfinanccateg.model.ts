import { Schema, Document } from 'mongoose';


export interface finCateg extends Document {
  hostname: string;
  login: string;
  user_dominio: string;
  categoria: string;
  subCategoria: string[];
  tipo_entrada_saida: string;
  data: string;
  
}

// Defina o nome da coleção personalizado no esquema
export const FinCategSchema  = new Schema({


  hostname: { 
      type:String,
      default:""
      },

  login: { 
      type:String,
      default:""
      },

  user_dominio: { 
      type:String,
      default:""
      },

  categoria: { 
      type:String,
      default:""
      },

  subCategoria: {
      type: [String],  // Defina o campo como um array de strings
      default: []  // Defina um array vazio como valor padrão
    },

  tipo_entrada_saida: { 
      type:String,
      default:""
      },

  data: { 
      type:String,
      default:""
      },
  }, 

  {
    collection: 'financ_categorias', // Substitua 'dados_empresa' pelo nome desejado da coleção
  });







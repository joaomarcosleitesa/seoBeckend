import { Test, TestingModule } from '@nestjs/testing';
import { SisfinanceiroService } from './sisfinanceiro.service';

describe('SisfinanceiroService', () => {
  let service: SisfinanceiroService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [SisfinanceiroService],
    }).compile();

    service = module.get<SisfinanceiroService>(SisfinanceiroService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});

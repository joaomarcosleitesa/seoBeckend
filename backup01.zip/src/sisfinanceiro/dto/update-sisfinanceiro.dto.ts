import { PartialType } from '@nestjs/mapped-types';
import { CreateSisfinanceiroDto } from './create-sisfinanceiro.dto';

export class UpdateSisfinanceiroDto extends PartialType(CreateSisfinanceiroDto) {}

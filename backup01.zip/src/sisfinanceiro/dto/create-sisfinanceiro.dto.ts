export class CreateSisfinanceiroDto {}

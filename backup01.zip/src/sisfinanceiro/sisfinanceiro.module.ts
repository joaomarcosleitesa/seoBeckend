import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt'; // Importe o JwtModule

import { SisfinanceiroService } from './sisfinanceiro.service';
import { SisfinanceiroController } from './sisfinanceiro.controller';
import { UserSchema } from '../user/user.model';
import { MongooseModule } from '@nestjs/mongoose';


import { UserService } from '../user/user.service'; // Importe o AuthService
import { FinCategSchema } from './sisfinanccateg.model';
import { FinancSchema } from './sisfinanc.model';
// import Authservice 
import { jwtConstants } from '../auth/jwt.config'; // Importe a configuração JWT
import { AuthService } from '../auth/auth.service'; // Importe o AuthService


@Module({
  imports:[
    MongooseModule.forFeature([{ name: 'financ', schema: FinancSchema }]),
    MongooseModule.forFeature([{ name: 'finCateg', schema: FinCategSchema }]),
    MongooseModule.forFeature([{ name: 'User', schema: UserSchema }]),
    JwtModule.register({
      secret: jwtConstants.secret,
      signOptions: { expiresIn: jwtConstants.expiresIn },
    }),
    ],
  controllers: [SisfinanceiroController],
  providers: [SisfinanceiroService, AuthService],
})
export class SisfinanceiroModule {}

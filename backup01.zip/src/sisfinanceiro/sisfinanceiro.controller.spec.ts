import { Test, TestingModule } from '@nestjs/testing';
import { SisfinanceiroController } from './sisfinanceiro.controller';
import { SisfinanceiroService } from './sisfinanceiro.service';

describe('SisfinanceiroController', () => {
  let controller: SisfinanceiroController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [SisfinanceiroController],
      providers: [SisfinanceiroService],
    }).compile();

    controller = module.get<SisfinanceiroController>(SisfinanceiroController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});

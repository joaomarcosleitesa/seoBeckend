import { Injectable, NotFoundException, ConflictException, UnauthorizedException } from '@nestjs/common';
import { CreateSisfinanceiroDto } from './dto/create-sisfinanceiro.dto';
import { UpdateSisfinanceiroDto } from './dto/update-sisfinanceiro.dto';

import { InjectModel } from '@nestjs/mongoose'; // Importe o InjectModel para injetar o modelo
import { Model } from 'mongoose'; // Certifique-se de importar o Model do Mongoose
import { finCateg } from './sisfinanccateg.model';
import { financ } from './sisfinanc.model';
import { AuthService } from '../auth/auth.service'; // Importe o AuthService

function getDateSevenDaysBefore(day, month, year) {
 const date = new Date(year, month - 1, day);
 date.setDate(date.getDate() - 7);
 return date;
}


@Injectable()
export class SisfinanceiroService {

  constructor(
    @InjectModel('finCateg')
    private readonly finCategModel: Model<finCateg>,
 
     @InjectModel('financ') 
     private readonly financModel: Model<financ>, 
    private readonly authService: AuthService,


    ) {}



async findSumBySubCategoryService(updateDto: any) {

  /* 

       http://localhost:3570/sisfinanceiro/create-new-financ


            tipo_entrada_saida: pode ser "entrada" ou "saida"

       {
                    "token":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJsb2dpbiI6Im1hcmNvc2xlaXRlIiwiaG9zdG5hbWUiOiJzZW8tYmguYXJjYXdlYi5jb20uYnIiLCJ1c2VyX2RvbWluaW8iOiJ0cmFmZWdvYXJjYXdlYiIsInMzcGFzdGEiOiJtYXJjb3NsZWl0ZS1hcmNhd2ViLXNlby1icE1TVFZmQ2dIdWQiLCJmdW5jYW8iOiJ1c2VyQWRtaW5NYXN0ZXIiLCJpYXQiOjE2OTk3NTYyMjgsImV4cCI6MTY5OTc2NzAyOH0._X-RGsqhEyaWTrhqHlhLC1Ob9AHzAzYj4kH9MyxLSNs",
              "tipo_entrada_saida": "entrada",
              "ano":"ano",
              "mes":"mes"

          
        }*/

 try {
  // Valide os dados de entrada aqui, se necessário.
  const token = updateDto.token;

  const decodedToken = await this.authService.verifyToken(token);

  if (!decodedToken) {
    return {
      success: false,
      message: 'Token inválido.',
    };
  }

  const { 
    mes, 
    ano, 
    tipo_entrada_saida 
  } = updateDto;

  const sumBySubCategory = await this.financModel.aggregate([
    { 
      $match: {
        tipo_entrada_saida: tipo_entrada_saida,
        mes: mes,
        ano: ano,
        login: decodedToken.login // Adicione a verificação de login aqui
      }
    },
    { 
      $group: {
        _id: { categoria: "$categoria", subCategoria: "$subCategoria" },
        total: { $sum: "$valor" }
      }
    },
    {
      $lookup: {
        from: "finCateg",
        localField: "_id.categoria",
        foreignField: "categoria",
        as: "categoria_info"
      }
    },
    {
      $unwind: "$categoria_info"
    },
    {
      $addFields: {
        "categoria_nome": "$categoria_info.nome",
        "categoria_soma": "$categoria_info.valor"
      }
    },
    {
      $project: {
        "categoria_info": 0
      }
    }
  ]);

  if (sumBySubCategory.length > 0) {
    return {
      success: true,
      message: 'Soma dos valores das subcategorias do mês calculada com sucesso!',
      total: sumBySubCategory,
    };
  } else {
    return {
      success: false,
      message: 'Nenhum valor encontrado para as subcategorias do mês especificado.',
    };
  }
 } catch (error) {
 return {
   "msg":error.message,
   success: false,
 }
 throw new Error(`Erro ao calcular a soma dos valores das subcategorias do mês: ${error.message}`);
 }
}



async findSumSubCategoryService02(updateDto: any) {
  try {
    // Valide os dados de entrada aqui, se necessário.
    const token = updateDto.token;

    const decodedToken = await this.authService.verifyToken(token);

    if (!decodedToken) {
      return {
        success: false,
        message: 'Token inválido.',
      };
    }

    const { mes, ano, tipo_entrada_saida } = updateDto;


     const sumByCat = await this.financModel.aggregate([
      {
        $match: {
          tipo_entrada_saida: tipo_entrada_saida,
          mes: mes,
          ano: ano,
          login: decodedToken.login,
        },
      },
      {
        $group: {
          _id: "$categoria", // Agrupa apenas pelas categorias
          totalCategoria: { $sum: "$valor" },
        },
      },
      {
        $sort: { "totalCategoria": -1 },
      },
      {
        $group: {
          _id: null,
          categories: {
            $push: {
              categoria: "$_id",
              total: "$totalCategoria",
            },
          },
          totalGeralCateg: { $sum: "$totalCategoria" }, // Adiciona a soma das categorias
        },
      },
    ]);

    const sumByCategory = await this.financModel.aggregate([
      {
        $match: {
          tipo_entrada_saida: tipo_entrada_saida,
          mes: mes,
          ano: ano,
          login: decodedToken.login,
        },
      },
      {
        $group: {
          _id: {
            categoria: "$categoria",
            subCategoria: "$subCategoria", // Agrupa também pelas subcategorias
          },
          total: { $sum: "$valor" },
        },
      },
      {
        $group: {
          _id: "$_id.categoria",
          subCategorias: {
            $push: {
              subCategoria: "$_id.subCategoria",
              total: "$total",
            },
          },
          totalCategoria: { $sum: "$total" },
        },
      },
       {
        $unwind: "$subCategorias", // Desconstrói o array de subCategorias para permitir a classificação
      },
      {
        $sort: { "subCategorias.total": -1 }, // Classifica em ordem decrescente pelo total da subCategoria
      },
      {
        $group: {
          _id: null,
          categories: {
            $push: {
              categoria: "$_id",
              subCategorias: "$subCategorias",
              total: "$totalCategoria",
            },
          },
          totalGeral: { $sum: "$totalCategoria" },
        },
      },
    ]);

    if (sumByCategory.length > 0) {
      return {
        success: true,
        message: 'Soma dos valores das categorias do mês'+ tipo_entrada_saida+'calculada com sucesso!',
        total: sumByCategory[0].categories,
        totalGeral: sumByCategory[0].totalGeral,
        totalGeralCateg: sumByCat[0].totalGeralCateg, // Adiciona totalGeralCateg
      };
    } else {
      return {
        success: false,
        message: 'Nenhum valor encontrado para as categorias do mês especificado.',
      };
    }
  } catch (error) {
    return {
      msg: error.message,
      success: false,
    };
    // throw new Error(`Erro ao calcular a soma dos valores das categorias do mês: ${error.message}`);
  }
}



async findSumCategoryService(updateDto: any) {
  try {
    // Valide os dados de entrada aqui, se necessário.
    const token = updateDto.token;

    const decodedToken = await this.authService.verifyToken(token);

    if (!decodedToken) {
      return {
        success: false,
        message: 'Token inválido.',
      };
    }

    const { 
      mes, 
      ano, 
      tipo_entrada_saida 
    } = updateDto;

    const sumByCategory = await this.financModel.aggregate([
      { 
        $match: {
          tipo_entrada_saida: tipo_entrada_saida,
          mes: mes,
          ano: ano,
          login: decodedToken.login // Adicione a verificação de login aqui
        }
      },
      {
        $group: {
          _id: "$categoria",
          total: { $sum: "$valor" }
        }
      },
      {
        $group: {
          _id: null,
          categories: { $push: { categoria: "$_id", total: "$total" } },
          totalGeral: { $sum: "$total" } // Calcula a soma total de todas as categorias
        }
      },
      {
        $unwind: "$categories" // Desconstrói o array para permitir a classificação
      },
      {
        $sort: { "categories.total": -1 } // Classifica em ordem decrescente pelo total
      },
      {
        $group: {
          _id: null,
          categories: { $push: "$categories" },
          totalGeral: { $first: "$totalGeral" }
        }
      }
    ]);

    if (sumByCategory.length > 0) {
      return {
        success: true,
        message: 'Soma dos valores das categorias do mês calculada com sucesso!',
        total: sumByCategory[0].categories,
        totalGeral: sumByCategory[0].totalGeral,
      };
    } else {
      return {
        success: false,
        message: 'Nenhum valor encontrado para as categorias do mês especificado.',
      };
    }
  } catch (error) {
    return {
      msg: error.message,
      success: false,
    };
    // throw new Error(`Erro ao calcular a soma dos valores das categorias do mês: ${error.message}`);
  }
}




async findSumBy12MonthService(updateDto: any) {

  /* 

        http://localhost:3570/sisfinanceiro/create-new-financ


      tipo_entrada_saida: pode ser "entrada" ou "saida"

        {
              "token":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJsb2dpbiI6Im1hcmNvc2xlaXRlIiwiaG9zdG5hbWUiOiJzZW8tYmguYXJjYXdlYi5jb20uYnIiLCJ1c2VyX2RvbWluaW8iOiJ0cmFmZWdvYXJjYXdlYiIsInMzcGFzdGEiOiJtYXJjb3NsZWl0ZS1hcmNhd2ViLXNlby1icE1TVFZmQ2dIdWQiLCJmdW5jYW8iOiJ1c2VyQWRtaW5NYXN0ZXIiLCJpYXQiOjE2OTk3NTYyMjgsImV4cCI6MTY5OTc2NzAyOH0._X-RGsqhEyaWTrhqHlhLC1Ob9AHzAzYj4kH9MyxLSNs",
              "tipo_entrada_saida": "entrada",

          
        }
  */
 try {
  // Valide os dados de entrada aqui, se necessário.
  const token = updateDto.token;

  const decodedToken = await this.authService.verifyToken(token);

  if (!decodedToken) {
    return {
      success: false,
      message: 'Token inválido.',
    };
  }

  const { 
    tipo_entrada_saida 
  } = updateDto;

  const today = new Date();
  const oneYearAgo = new Date(today.setFullYear(today.getFullYear() - 1));

  const sumByMonth = await this.financModel.aggregate([
    { 
      $match: {
        tipo_entrada_saida: tipo_entrada_saida,
        data: { $gte: oneYearAgo },
        login: decodedToken.login // Adicione a verificação de login aqui
      }
    },
    { 
      $group: {
        _id: { mes: "$mes", ano: "$ano" },
        total: { $sum: "$valor" }
      }
    }
  ]);

  if (sumByMonth.length > 0) {
    return {
      success: true,
      message: 'Soma dos valores dos últimos 12 meses calculada com sucesso!',
      total: sumByMonth,
    };
  } else {
    return {
      success: false,
      message: 'Nenhum valor encontrado para os últimos 12 meses.',
    };
  }
 } catch (error) {
  return {
    "msg":error.message,
    success: false,
  }
  throw new Error(`Erro ao calcular a soma dos valores dos últimos 12 meses: ${error.message}`);
 }
}


 /* 

 http://localhost:3570/sisfinanceiro/create-new-financ


      tipo_entrada_saida: pode ser "entrada" ou "saida"

 {
              "token":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJsb2dpbiI6Im1hcmNvc2xlaXRlIiwiaG9zdG5hbWUiOiJzZW8tYmguYXJjYXdlYi5jb20uYnIiLCJ1c2VyX2RvbWluaW8iOiJ0cmFmZWdvYXJjYXdlYiIsInMzcGFzdGEiOiJtYXJjb3NsZWl0ZS1hcmNhd2ViLXNlby1icE1TVFZmQ2dIdWQiLCJmdW5jYW8iOiJ1c2VyQWRtaW5NYXN0ZXIiLCJpYXQiOjE2OTk3NTYyMjgsImV4cCI6MTY5OTc2NzAyOH0._X-RGsqhEyaWTrhqHlhLC1Ob9AHzAzYj4kH9MyxLSNs",
              "tipo_entrada_saida": "entrada",
              "ano":"ano",
              "mes":"mes"

          
        }*/


async sumBySemanalService(updateDto: any) {
 try {
  // Valide os dados de entrada aqui, se necessário.
  const token = updateDto.token;

  const decodedToken = await this.authService.verifyToken(token);

  if (!decodedToken) {
    return {
      success: false,
      message: 'Token inválido.',
    };
  }

  const { 
    dia,
    mes, 
    ano, 
    tipo_entrada_saida 
  } = updateDto;

  const sumByMonth = await this.financModel.aggregate([
    { 
      $match: {
        dia: {
            $gte: dia - 7, // Dia atual menos 7
            $lte: dia,     // Dia atual
        },
        ano: ano,
        mes: mes,
        tipo_entrada_saida: tipo_entrada_saida,
        login: decodedToken.login // Adicione a verificação de login aqui
      }
    },
    { 
      $group: {
        _id: null,
        total: { $sum: "$valor" }
      }
    }
  ]);
  if (sumByMonth.length > 0) {
    return {
      success: true,
      message: 'Soma dos valores do Dia calculada com sucesso!',
      total: sumByMonth[0].total,
    };
  } else {
    return {
      success: false,
      message: 'Nenhum valor encontrado para o Dia especificado.',
    };
  }
 } catch (error) {
  return {
    "msg":error.message,
    success: false,
  }
  throw new Error(`Erro ao calcular a soma dos valores do dia: ${error.message}`);
 }
}


async sumByDayMonthEntSaidService(updateDto: any) {
 try {
   const token = updateDto.token;
   const decodedToken = await this.authService.verifyToken(token);

   if (!decodedToken) {
     return {
       success: false,
       message: 'Token inválido.',
     };
   }

   const { mes, ano } = updateDto;

   const sumByDay = await this.financModel.aggregate([
     { 
       $match: {
         mes: mes,
         ano: ano,
         login: decodedToken.login 
       }
     },
     { 
       $group: {
         _id: { dia: "$dia", tipo_entrada_saida: "$tipo_entrada_saida" },
         total: { $sum: "$valor" }
       }
     },
     {
       $sort: { "_id.dia": 1 }
     }
   ]);

   if (sumByDay.length > 0) {
     return {
       success: true,
       message: 'Soma dos valores do Dia calculada com sucesso!',
       total: sumByDay,
     };
   } else {
     return {
       success: false,
       message: 'Nenhum valor encontrado para o Dia especificado.',
     };
   }
 } catch (error) {
   return {
     "msg":error.message,
     success: false,
   }
   throw new Error(`Erro ao calcular a soma dos valores do dia: ${error.message}`);
 }


}//fim da func






async sumByDayService(updateDto: any) {
 try {
  // Valide os dados de entrada aqui, se necessário.
  const token = updateDto.token;

  const decodedToken = await this.authService.verifyToken(token);

  if (!decodedToken) {
    return {
      success: false,
      message: 'Token inválido.',
    };
  }

  const { 
    dia,
    mes, 
    ano, 
    tipo_entrada_saida 
  } = updateDto;

  const sumByMonth = await this.financModel.aggregate([
    { 
      $match: {
        dia:dia,
        ano: ano,
        mes: mes,
        tipo_entrada_saida: tipo_entrada_saida,
        login: decodedToken.login // Adicione a verificação de login aqui
      }
    },
    { 
      $group: {
        _id: null,
        total: { $sum: "$valor" }
      }
    }
  ]);
  if (sumByMonth.length > 0) {
    return {
      success: true,
      message: 'Soma dos valores do Dia calculada com sucesso!',
      total: sumByMonth[0].total,
    };
  } else {
    return {
      success: false,
      message: 'Nenhum valor encontrado para o Dia especificado.',
    };
  }
 } catch (error) {
  return {
    "msg":error.message,
    success: false,
  }
  throw new Error(`Erro ao calcular a soma dos valores do dia: ${error.message}`);
 }
}

  async sumByMonthService(updateDto: any) {
 try {
  // Valide os dados de entrada aqui, se necessário.
  const token = updateDto.token;

  const decodedToken = await this.authService.verifyToken(token);

  if (!decodedToken) {
    return {
      success: false,
      message: 'Token inválido.',
    };
  }

  const { 
    mes, 
    ano, 
    tipo_entrada_saida 
  } = updateDto;

  const sumByMonth = await this.financModel.aggregate([
    { 
      $match: {
        ano: ano,
        mes: mes,
        tipo_entrada_saida: tipo_entrada_saida,
        login: decodedToken.login // Adicione a verificação de login aqui
      }
    },
    { 
      $group: {
        _id: null,
        total: { $sum: "$valor" }
      }
    }
  ]);

  if (sumByMonth.length > 0) {
    return {
      success: true,
      message: 'Soma dos valores do mês calculada com sucesso!',
      total: sumByMonth[0].total,
    };
  } else {
    return {
      success: false,
      message: 'Nenhum valor encontrado para o mês especificado.',
    };
  }
 } catch (error) {
  return {
    "msg":error.message,
    success: false,
  }
  throw new Error(`Erro ao calcular a soma dos valores do mês: ${error.message}`);
 }
}



 /* 

 http://localhost:3570/sisfinanceiro/create-new-financ


      tipo_entrada_saida: pode ser "entrada" ou "saida"

 {
              "token":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJsb2dpbiI6Im1hcmNvc2xlaXRlIiwiaG9zdG5hbWUiOiJzZW8tYmguYXJjYXdlYi5jb20uYnIiLCJ1c2VyX2RvbWluaW8iOiJ0cmFmZWdvYXJjYXdlYiIsInMzcGFzdGEiOiJtYXJjb3NsZWl0ZS1hcmNhd2ViLXNlby1icE1TVFZmQ2dIdWQiLCJmdW5jYW8iOiJ1c2VyQWRtaW5NYXN0ZXIiLCJpYXQiOjE2OTk3NTYyMjgsImV4cCI6MTY5OTc2NzAyOH0._X-RGsqhEyaWTrhqHlhLC1Ob9AHzAzYj4kH9MyxLSNs",
              "tipo_entrada_saida": "entrada",

          
        }*/


  async findLast50Service(updateDto: any) {
 try {
  // Valide os dados de entrada aqui, se necessário.
  const token = updateDto.token;

  const decodedToken = await this.authService.verifyToken(token);

    if (!decodedToken) {
        return {
          success: false,
          message: 'Token inválido.',
        };
      }
        const { 
          tipo_entrada_saida 
        } = updateDto;

  const last50Entrada = await this.financModel.find(
    { 
      login:decodedToken.login,
      tipo_entrada_saida: tipo_entrada_saida 

    }).sort({ _id: -1 }).limit(50);

  if (last50Entrada) {
    return {
      success: true,
      message: 'Últimos 50 itens de entrada buscados com sucesso!',
      financ: last50Entrada,
    };
  } else {
    return {
      success: false,
      message: 'Falha ao buscar os últimos 50 itens de entrada.',
    };
  }
 } catch (error) {
  return {
    "msg":error.message,
    success: false,
  }
  throw new Error(`Erro ao buscar dados por login: ${error.message}`);
 }
}




async findAllSubCategoriesByCategoryService(updateDto: any) {
 try {
  // Valide os dados de entrada aqui, se necessário.
  const token = updateDto.token;

  const decodedToken = await this.authService.verifyToken(token);



  if (!decodedToken) {
    return {
      success: false,
      message: 'Token inválido.',
    };
  }

  const { 
    categoria,
    tipo_entrada_saida
  } = updateDto;


  if (tipo_entrada_saida!=='entrada' && tipo_entrada_saida!=='saida') {
    return {
      success: false,
      message: 'tipo_entrada_saida invalido aceita entrada ou saida.',
    };
  }

  const allSubCategories = await this.finCategModel.find(
    { 
      login: decodedToken.login,
      categoria: categoria,
      tipo_entrada_saida:tipo_entrada_saida
    }
  ).select('subCategoria'); // Selecione apenas o campo 'subCategoria'

  if (allSubCategories) {
    return {
      success: true,
      message: 'Todas as subcategorias da categoria buscadas com sucesso!',
      financ: allSubCategories,
    };
  } else {
    return {
      success: false,
      message: 'Falha ao buscar todas as subcategorias da categoria especificada.',
    };
  }
 } catch (error) {
 return {
   "msg":error.message,
   success: false,
 }
 throw new Error(`Erro ao buscar todas as subcategorias da categoria: ${error.message}`);
 }
}




async findAllCategoriesService(updateDto: any) {
 try {
  // Valide os dados de entrada aqui, se necessário.
  const token = updateDto.token;

  const decodedToken = await this.authService.verifyToken(token);

  if (!decodedToken) {
    return {
      success: false,
      message: 'Token inválido.',
    };
  }


  const { 
    tipo_entrada_saida 
  } = updateDto;


  if (tipo_entrada_saida!=='entrada' && tipo_entrada_saida!=='saida') {
    return {
      success: false,
      message: 'tipo_entrada_saida invalido aceita entrada ou saida.',
    };
  }

  const allCategories = await this.finCategModel.find(
    { 
      login: decodedToken.login,
      tipo_entrada_saida: tipo_entrada_saida 
    }
  ).select('categoria'); // Selecione apenas o campo 'categoria'

  if (allCategories) {
    return {
      success: true,
      message: 'Todas as categorias buscadas com sucesso!',
      financ: allCategories,
    };
  } else {
    return {
      success: false,
      message: 'Falha ao buscar todas as categorias.',
    };
  }
 } catch (error) {
 return {
   "msg":error.message,
   success: false,
 }
 throw new Error(`Erro ao buscar todas as categorias: ${error.message}`);
 }
}





// FIM DOS FINDS



// START THE CREATE


 /* 

 http://localhost:3570/sisfinanceiro/create-new-financ

 {
              "token":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJsb2dpbiI6Im1hcmNvc2xlaXRlIiwiaG9zdG5hbWUiOiJzZW8tYmguYXJjYXdlYi5jb20uYnIiLCJ1c2VyX2RvbWluaW8iOiJ0cmFmZWdvYXJjYXdlYiIsInMzcGFzdGEiOiJtYXJjb3NsZWl0ZS1hcmNhd2ViLXNlby1icE1TVFZmQ2dIdWQiLCJmdW5jYW8iOiJ1c2VyQWRtaW5NYXN0ZXIiLCJpYXQiOjE2OTk3NTYyMjgsImV4cCI6MTY5OTc2NzAyOH0._X-RGsqhEyaWTrhqHlhLC1Ob9AHzAzYj4kH9MyxLSNs",
              "categoria":"um",
              "subCategoria":["teste","teste"],
              "tipo_entrada_saida": "entrada",
              "data":"11/11/2023 17:46"
              "dia":12
              "mes":11
              "ano":2023
              "descricao":"VAMOS TESTAR PARA VER..." 
              "valor":10.50

          
        }*/


  async createNewFinancService(updateDto: any) {

    try {
      // Valide os dados de entrada aqui, se necessário.
      const token = updateDto.token;

       const decodedToken = await this.authService.verifyToken(token);
       //return {"msgToken":decodedToken}

      const { 
        categoria,
        subCategoria, 
        tipo_entrada_saida, 
        data, 
        dia, 
        mes, 
        ano, 
        descricao, 
        valor 

      } = updateDto;
      //const pastaS3 = imgsUrls[0].pastaS3;


      if (tipo_entrada_saida!=='entrada' && tipo_entrada_saida!=='saida') {
        return {
          success: false,
          message: 'tipo_entrada_saida invalido aceita entrada ou saida.',
        };
      }
      

      const valorNumerico = parseFloat(valor);

      const newFinanc = new this.financModel({


              hostname:decodedToken.hostname, 
              login:decodedToken.login,
              user_dominio:decodedToken.user_dominio,
              categoria:categoria,
              subCategoria:subCategoria,
              tipo_entrada_saida: tipo_entrada_saida,
              data:data,
              dia:dia,
              mes:mes,
              ano:ano,
              descricao:descricao,
              valor:valor


      });

       const savedFinanc = await newFinanc.save();

      if (savedFinanc) {
        return {
          success: true,
          message: 'Categoria salva com sucesso!',
          product: savedFinanc,
        };
      } else {
        return {
          success: false,
          message: 'Falha ao salvar o Categoria.',
        };
      }
    }catch (error) {
          // Lidar com erros de consulta, se necessário
            return {
              "msg":error.message,
              success: true,
            }
            throw new Error(`Erro ao buscar dados por login: ${error.message}`);
        }
    }


 /* 

  http://localhost:3570/sisfinanceiro/create-new-category

 {
              "token":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJsb2dpbiI6Im1hcmNvc2xlaXRlIiwiaG9zdG5hbWUiOiJzZW8tYmguYXJjYXdlYi5jb20uYnIiLCJ1c2VyX2RvbWluaW8iOiJ0cmFmZWdvYXJjYXdlYiIsInMzcGFzdGEiOiJtYXJjb3NsZWl0ZS1hcmNhd2ViLXNlby1icE1TVFZmQ2dIdWQiLCJmdW5jYW8iOiJ1c2VyQWRtaW5NYXN0ZXIiLCJpYXQiOjE2OTk3MzU0MTAsImV4cCI6MTY5OTc0NjIxMH0.FUtlJ1fTxpRydd-7qLhcc_ZzkfL2RjqMyalVfEkwzJQ",
              "hostname":"arcawebagencia.com.br", 
              "login":"marcosleite",
              "user_dominio":"testelogin",
              "categoria":"um",
              "subCategoria":["teste","teste"],
              "tipo_entrada_saida": "entrada",
              "data":"11/11/2023 17:46"

          
        }*/


  async createNewCategoryService(updateDto: any) {
  try {
    // Valide os dados de entrada aqui, se necessário.
    const token = updateDto.token;
    const decodedToken = await this.authService.verifyToken(token);
    const { categoria, subCategoria, tipo_entrada_saida, data } = updateDto;

    // Verificar se a categoria já existe
    const existingCategory = await this.finCategModel.findOne({
      hostname: decodedToken.hostname,
      login: decodedToken.login,
      user_dominio: decodedToken.user_dominio,
      categoria: categoria,
      tipo_entrada_saida: tipo_entrada_saida,

    });

    if (existingCategory) {
      return {
        success: false,
        message: 'A Categoria já existe.',
      };
    }

    // A categoria não existe, então podemos criar e salvar
    const newCategory = new this.finCategModel({
      hostname: decodedToken.hostname,
      login: decodedToken.login,
      user_dominio: decodedToken.user_dominio,
      categoria: categoria,
      subCategoria: subCategoria,
      tipo_entrada_saida: tipo_entrada_saida,
      data: data
    });

    const savedCategory = await newCategory.save();

    if (savedCategory) {
      return {
        success: true,
        message: 'Categoria salva com sucesso!',
        product: savedCategory,
      };
    } else {
      return {
        success: false,
        message: 'Falha ao salvar a Categoria.',
      };
    }
  } catch (error) {
    // Lidar com erros de consulta, se necessário
    return {
      msg: error.message,
      success: false,
    }
  }
}



 /* 

  http://localhost:3570/sisfinanceiro/create-new-category

 {
              "token":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJsb2dpbiI6Im1hcmNvc2xlaXRlIiwiaG9zdG5hbWUiOiJzZW8tYmguYXJjYXdlYi5jb20uYnIiLCJ1c2VyX2RvbWluaW8iOiJ0cmFmZWdvYXJjYXdlYiIsInMzcGFzdGEiOiJtYXJjb3NsZWl0ZS1hcmNhd2ViLXNlby1icE1TVFZmQ2dIdWQiLCJmdW5jYW8iOiJ1c2VyQWRtaW5NYXN0ZXIiLCJpYXQiOjE2OTk3MzU0MTAsImV4cCI6MTY5OTc0NjIxMH0.FUtlJ1fTxpRydd-7qLhcc_ZzkfL2RjqMyalVfEkwzJQ",
              "categoria":"um",
              "subCategoria":["teste687987","teste123"],
              "tipo_entrada_saida": "entrada"

          
        }

        */

    async addSubCategServ(updateDto: any) {

    try {
      // Valide os dados de entrada aqui, se necessário.
      const token = updateDto.token;

       const decodedToken = await this.authService.verifyToken(token);
       //return {"msgToken":decodedToken}

       const login = decodedToken.login;

      const {categoria, tipo_entrada_saida, subCategoria} = updateDto;
      //const pastaS3 = imgsUrls[0].pastaS3;


         // Verifique se login, categoria e tipo_entrada_saida já existem
      const existingRecord = await this.finCategModel.findOne({ login, categoria, tipo_entrada_saida });


      if (existingRecord) {
         // Se login, categoria e tipo_entrada_saida existirem, adicione as novas subcategorias sem duplicatas
         const uniqueSubCategories = [...new Set([...existingRecord.subCategoria, ...subCategoria])];
         existingRecord.subCategoria = uniqueSubCategories;
         
         const updatedRecord = await existingRecord.save();

         return {
           success: true,
           message: 'Subcategorias adicionadas com sucesso!',
           record: updatedRecord,
         };
       } else {
           return {
             success: false,
             message: 'Não Cadastrado, talvez a categoria não existe!'
           };
       }

      

      /*if (savedProduct) {
        return {
          success: true,
          message: 'Categoria salva com sucesso!',
          product: savedProduct,
        };
      } else {
        return {
          success: false,
          message: 'Falha ao salvar o Categoria.',
        };
      }*/
    }catch (error) {
          // Lidar com erros de consulta, se necessário
            return {
              "msg":error.message,
              success: true,
            }
            throw new Error(`Erro ao buscar dados por login: ${error.message}`);
        }
    }


  create(createSisfinanceiroDto: CreateSisfinanceiroDto) {
    return 'This action adds a new sisfinanceiro';
  }

  findAll() {
    return `This action returns all sisfinanceiro`;
  }

  findOne(id: number) {
    return `This action returns a #${id} sisfinanceiro`;
  }

  update(id: number, updateSisfinanceiroDto: UpdateSisfinanceiroDto) {
    return `This action updates a #${id} sisfinanceiro`;
  }

  remove(id: number) {
    return `This action removes a #${id} sisfinanceiro`;
  }
}

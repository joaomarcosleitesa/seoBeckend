import { Controller, Get, Post, Body, Patch, Param, Delete, UnauthorizedException } from '@nestjs/common';
import { SisfinanceiroService } from './sisfinanceiro.service';
import { CreateSisfinanceiroDto } from './dto/create-sisfinanceiro.dto';
import { UpdateSisfinanceiroDto } from './dto/update-sisfinanceiro.dto';

@Controller('sisfinanceiro')
export class SisfinanceiroController {
  constructor(private readonly sisfinanceiroService: SisfinanceiroService) {}

//findAllSubCategoriesByCategoryService

  /* 

       http://localhost:3570/sisfinanceiro/find-categorias-financ


            tipo_entrada_saida: pode ser "entrada" ou "saida"

       {
                    "token":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJsb2dpbiI6Im1hcmNvc2xlaXRlIiwiaG9zdG5hbWUiOiJzZW8tYmguYXJjYXdlYi5jb20uYnIiLCJ1c2VyX2RvbWluaW8iOiJ0cmFmZWdvYXJjYXdlYiIsInMzcGFzdGEiOiJtYXJjb3NsZWl0ZS1hcmNhd2ViLXNlby1icE1TVFZmQ2dIdWQiLCJmdW5jYW8iOiJ1c2VyQWRtaW5NYXN0ZXIiLCJpYXQiOjE2OTk3NTYyMjgsImV4cCI6MTY5OTc2NzAyOH0._X-RGsqhEyaWTrhqHlhLC1Ob9AHzAzYj4kH9MyxLSNs",
              "tipo_entrada_saida": "entrada",
              "ano":"ano",
              "mes":"mes"

          
        }*/

@Post('find-sub-categorias-financ') // Rota para atualizar campos de SEO
  async fundSubCategoriasFinanc(
    @Body() updateDto: any,
    ) {

    try {

      //return {"msg":updateDto}

        //console.log("teste");
        //return updateDto;
        return this.sisfinanceiroService.findAllSubCategoriesByCategoryService(updateDto);
      }catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
      } else {
        throw new UnauthorizedException('Token inválido.');
      }
    }
  }



/* 

       http://localhost:3570/sisfinanceiro/find-categorias-financ


            tipo_entrada_saida: pode ser "entrada" ou "saida"

       {
                    "token":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJsb2dpbiI6Im1hcmNvc2xlaXRlIiwiaG9zdG5hbWUiOiJzZW8tYmguYXJjYXdlYi5jb20uYnIiLCJ1c2VyX2RvbWluaW8iOiJ0cmFmZWdvYXJjYXdlYiIsInMzcGFzdGEiOiJtYXJjb3NsZWl0ZS1hcmNhd2ViLXNlby1icE1TVFZmQ2dIdWQiLCJmdW5jYW8iOiJ1c2VyQWRtaW5NYXN0ZXIiLCJpYXQiOjE2OTk3NTYyMjgsImV4cCI6MTY5OTc2NzAyOH0._X-RGsqhEyaWTrhqHlhLC1Ob9AHzAzYj4kH9MyxLSNs",
              "tipo_entrada_saida": "entrada",
              "ano":"ano",
              "mes":"mes"

          
        }*/

@Post('find-categorias-financ') // Rota para atualizar campos de SEO
  async fundCategoriasFinanc(
    @Body() updateDto: any,
    ) {

    try {

     


      //return {"msg":updateDto}

        //console.log("teste");
        //return updateDto;
        return this.sisfinanceiroService.findAllCategoriesService(updateDto);
      }catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
      } else {
        throw new UnauthorizedException('Token inválido.');
      }
    }
  }


 /* 

       http://localhost:3570/sisfinanceiro/find-sum-subcategoria-financ


            tipo_entrada_saida: pode ser "entrada" ou "saida"

       {
                    "token":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJsb2dpbiI6Im1hcmNvc2xlaXRlIiwiaG9zdG5hbWUiOiJzZW8tYmguYXJjYXdlYi5jb20uYnIiLCJ1c2VyX2RvbWluaW8iOiJ0cmFmZWdvYXJjYXdlYiIsInMzcGFzdGEiOiJtYXJjb3NsZWl0ZS1hcmNhd2ViLXNlby1icE1TVFZmQ2dIdWQiLCJmdW5jYW8iOiJ1c2VyQWRtaW5NYXN0ZXIiLCJpYXQiOjE2OTk3NTYyMjgsImV4cCI6MTY5OTc2NzAyOH0._X-RGsqhEyaWTrhqHlhLC1Ob9AHzAzYj4kH9MyxLSNs",
              "tipo_entrada_saida": "entrada",
              "ano":"ano",
              "mes":"mes"

          
        }*/

@Post('find-sum-subcategoria-financ') // Rota para atualizar campos de SEO
  async fundSumSubCatFinacController(
    @Body() updateDto: any,
    ) {

    try {

     


      //return {"msg":updateDto}

        //console.log("teste");
        //return updateDto;
        return this.sisfinanceiroService.findSumSubCategoryService02(updateDto);
      }catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
      } else {
        throw new UnauthorizedException('Token inválido.');
      }
    }
  }




  /* 

 http://localhost:3570/sisfinanceiro/find-day-by-month-entrada-saida


      tipo_entrada_saida: pode ser "entrada" ou "saida"

 {
              "token":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJsb2dpbiI6Im1hcmNvc2xlaXRlIiwiaG9zdG5hbWUiOiJzZW8tYmguYXJjYXdlYi5jb20uYnIiLCJ1c2VyX2RvbWluaW8iOiJ0cmFmZWdvYXJjYXdlYiIsInMzcGFzdGEiOiJtYXJjb3NsZWl0ZS1hcmNhd2ViLXNlby1icE1TVFZmQ2dIdWQiLCJmdW5jYW8iOiJ1c2VyQWRtaW5NYXN0ZXIiLCJpYXQiOjE2OTk3NTYyMjgsImV4cCI6MTY5OTc2NzAyOH0._X-RGsqhEyaWTrhqHlhLC1Ob9AHzAzYj4kH9MyxLSNs",
              "ano":"ano",
              "mes":"mes"

          
        }*/
@Post('find-day-by-month-entrada-saida') // Rota para atualizar campos de SEO
  async fundDayByMonthEntradaSaidaController(
    @Body() updateDto: any,
    ) {

    try {

       /* 

         http://localhost:3570/sisfinanceiro/find-sum-categ-financ


              tipo_entrada_saida: pode ser "entrada" ou "saida"

         {
                      "token":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJsb2dpbiI6Im1hcmNvc2xlaXRlIiwiaG9zdG5hbWUiOiJzZW8tYmguYXJjYXdlYi5jb20uYnIiLCJ1c2VyX2RvbWluaW8iOiJ0cmFmZWdvYXJjYXdlYiIsInMzcGFzdGEiOiJtYXJjb3NsZWl0ZS1hcmNhd2ViLXNlby1icE1TVFZmQ2dIdWQiLCJmdW5jYW8iOiJ1c2VyQWRtaW5NYXN0ZXIiLCJpYXQiOjE2OTk3NTYyMjgsImV4cCI6MTY5OTc2NzAyOH0._X-RGsqhEyaWTrhqHlhLC1Ob9AHzAzYj4kH9MyxLSNs",
                      "tipo_entrada_saida": "entrada",
                      "ano":"ano",
                      "mes":"mes"

                  
                }
      */


      //return {"msg":updateDto}

        //console.log("teste");
        //return updateDto;
        return this.sisfinanceiroService.sumByDayMonthEntSaidService(updateDto);
      }catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
      } else {
        throw new UnauthorizedException('Token inválido.');
      }
    }
  }



  /* 

 http://localhost:3570/sisfinanceiro/find-sum-subcategoria-financ


      tipo_entrada_saida: pode ser "entrada" ou "saida"

 {
              "token":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJsb2dpbiI6Im1hcmNvc2xlaXRlIiwiaG9zdG5hbWUiOiJzZW8tYmguYXJjYXdlYi5jb20uYnIiLCJ1c2VyX2RvbWluaW8iOiJ0cmFmZWdvYXJjYXdlYiIsInMzcGFzdGEiOiJtYXJjb3NsZWl0ZS1hcmNhd2ViLXNlby1icE1TVFZmQ2dIdWQiLCJmdW5jYW8iOiJ1c2VyQWRtaW5NYXN0ZXIiLCJpYXQiOjE2OTk3NTYyMjgsImV4cCI6MTY5OTc2NzAyOH0._X-RGsqhEyaWTrhqHlhLC1Ob9AHzAzYj4kH9MyxLSNs",
              "tipo_entrada_saida": "entrada",
              "ano":"ano",
              "mes":"mes"

          
        }*/
@Post('find-sum-categ-financ') // Rota para atualizar campos de SEO
  async fundSumCatebFinacController(
    @Body() updateDto: any,
    ) {

    try {

       /* 

         http://localhost:3570/sisfinanceiro/find-sum-categ-financ


              tipo_entrada_saida: pode ser "entrada" ou "saida"

         {
                      "token":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJsb2dpbiI6Im1hcmNvc2xlaXRlIiwiaG9zdG5hbWUiOiJzZW8tYmguYXJjYXdlYi5jb20uYnIiLCJ1c2VyX2RvbWluaW8iOiJ0cmFmZWdvYXJjYXdlYiIsInMzcGFzdGEiOiJtYXJjb3NsZWl0ZS1hcmNhd2ViLXNlby1icE1TVFZmQ2dIdWQiLCJmdW5jYW8iOiJ1c2VyQWRtaW5NYXN0ZXIiLCJpYXQiOjE2OTk3NTYyMjgsImV4cCI6MTY5OTc2NzAyOH0._X-RGsqhEyaWTrhqHlhLC1Ob9AHzAzYj4kH9MyxLSNs",
                      "tipo_entrada_saida": "entrada",
                      "ano":"ano",
                      "mes":"mes"

                  
                }
      */


      //return {"msg":updateDto}

        //console.log("teste");
        //return updateDto;
        return this.sisfinanceiroService.findSumCategoryService(updateDto);
      }catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
      } else {
        throw new UnauthorizedException('Token inválido.');
      }
    }
  }

/* 

        http://localhost:3570/sisfinanceiro/find-soma-12-mes-controller


      tipo_entrada_saida: pode ser "entrada" ou "saida"

        {
              "token":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJsb2dpbiI6Im1hcmNvc2xlaXRlIiwiaG9zdG5hbWUiOiJzZW8tYmguYXJjYXdlYi5jb20uYnIiLCJ1c2VyX2RvbWluaW8iOiJ0cmFmZWdvYXJjYXdlYiIsInMzcGFzdGEiOiJtYXJjb3NsZWl0ZS1hcmNhd2ViLXNlby1icE1TVFZmQ2dIdWQiLCJmdW5jYW8iOiJ1c2VyQWRtaW5NYXN0ZXIiLCJpYXQiOjE2OTk3NTYyMjgsImV4cCI6MTY5OTc2NzAyOH0._X-RGsqhEyaWTrhqHlhLC1Ob9AHzAzYj4kH9MyxLSNs",
              "tipo_entrada_saida": "entrada",

          
        }
  */
@Post('find-soma-12-mes-controller') // Rota para atualizar campos de SEO
  async fundSoma12MesCont(
    @Body() updateDto: any,
    ) {

    try {


      //return {"msg":updateDto}

        //console.log("teste");
        //return updateDto;
        return this.sisfinanceiroService.findSumBy12MonthService(updateDto);
      }catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
      } else {
        throw new UnauthorizedException('Token inválido.');
      }
    }
  }


  /* 

     http://localhost:3570/sisfinanceiro/find-soma-dia


          tipo_entrada_saida: pode ser "entrada" ou "saida"

     {
                  "token":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJsb2dpbiI6Im1hcmNvc2xlaXRlIiwiaG9zdG5hbWUiOiJzZW8tYmguYXJjYXdlYi5jb20uYnIiLCJ1c2VyX2RvbWluaW8iOiJ0cmFmZWdvYXJjYXdlYiIsInMzcGFzdGEiOiJtYXJjb3NsZWl0ZS1hcmNhd2ViLXNlby1icE1TVFZmQ2dIdWQiLCJmdW5jYW8iOiJ1c2VyQWRtaW5NYXN0ZXIiLCJpYXQiOjE2OTk3NTYyMjgsImV4cCI6MTY5OTc2NzAyOH0._X-RGsqhEyaWTrhqHlhLC1Ob9AHzAzYj4kH9MyxLSNs",
                  "tipo_entrada_saida": "entrada",
                  "ano":"ano",
                  "mes":"mes",
                  "dia":"dia",

              
            }
*/


  @Post('find-soma-semanal') // Rota para atualizar campos de SEO
  async fundSomaSemanalCont(
    @Body() updateDto: any,
    ) {

    try {


      //return {"msg":updateDto}

        //console.log("teste");
        //return updateDto;
        return this.sisfinanceiroService.sumBySemanalService(updateDto);
      }catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
      } else {
        throw new UnauthorizedException('Token inválido.');
      }
    }
  }


  /* 

     http://localhost:3570/sisfinanceiro/find-soma-dia


          tipo_entrada_saida: pode ser "entrada" ou "saida"

     {
                  "token":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJsb2dpbiI6Im1hcmNvc2xlaXRlIiwiaG9zdG5hbWUiOiJzZW8tYmguYXJjYXdlYi5jb20uYnIiLCJ1c2VyX2RvbWluaW8iOiJ0cmFmZWdvYXJjYXdlYiIsInMzcGFzdGEiOiJtYXJjb3NsZWl0ZS1hcmNhd2ViLXNlby1icE1TVFZmQ2dIdWQiLCJmdW5jYW8iOiJ1c2VyQWRtaW5NYXN0ZXIiLCJpYXQiOjE2OTk3NTYyMjgsImV4cCI6MTY5OTc2NzAyOH0._X-RGsqhEyaWTrhqHlhLC1Ob9AHzAzYj4kH9MyxLSNs",
                  "tipo_entrada_saida": "entrada",
                  "ano":"ano",
                  "mes":"mes",
                  "dia":"dia",

              
            }
*/


  @Post('find-soma-dia') // Rota para atualizar campos de SEO
  async fundSomaDayCont(
    @Body() updateDto: any,
    ) {

    try {


      //return {"msg":updateDto}

        //console.log("teste");
        //return updateDto;
        return this.sisfinanceiroService.sumByDayService(updateDto);
      }catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
      } else {
        throw new UnauthorizedException('Token inválido.');
      }
    }
  }


 /* 

     http://localhost:3570/sisfinanceiro/find-soma-mes


          tipo_entrada_saida: pode ser "entrada" ou "saida"

     {
                  "token":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJsb2dpbiI6Im1hcmNvc2xlaXRlIiwiaG9zdG5hbWUiOiJzZW8tYmguYXJjYXdlYi5jb20uYnIiLCJ1c2VyX2RvbWluaW8iOiJ0cmFmZWdvYXJjYXdlYiIsInMzcGFzdGEiOiJtYXJjb3NsZWl0ZS1hcmNhd2ViLXNlby1icE1TVFZmQ2dIdWQiLCJmdW5jYW8iOiJ1c2VyQWRtaW5NYXN0ZXIiLCJpYXQiOjE2OTk3NTYyMjgsImV4cCI6MTY5OTc2NzAyOH0._X-RGsqhEyaWTrhqHlhLC1Ob9AHzAzYj4kH9MyxLSNs",
                  "tipo_entrada_saida": "entrada",
                  "ano":"ano",
                  "mes":"mes"

              
            }
*/


  @Post('find-soma-mes') // Rota para atualizar campos de SEO
  async fundSomaMesCont(
    @Body() updateDto: any,
    ) {

    try {


      //return {"msg":updateDto}

        //console.log("teste");
        //return updateDto;
        return this.sisfinanceiroService.sumByMonthService(updateDto);
      }catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
      } else {
        throw new UnauthorizedException('Token inválido.');
      }
    }
  }


/* 

 http://localhost:3570/sisfinanceiro/find-ultimos-50-entrada-saida


      tipo_entrada_saida: pode ser "entrada" ou "saida"

 {
              "token":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJsb2dpbiI6Im1hcmNvc2xlaXRlIiwiaG9zdG5hbWUiOiJzZW8tYmguYXJjYXdlYi5jb20uYnIiLCJ1c2VyX2RvbWluaW8iOiJ0cmFmZWdvYXJjYXdlYiIsInMzcGFzdGEiOiJtYXJjb3NsZWl0ZS1hcmNhd2ViLXNlby1icE1TVFZmQ2dIdWQiLCJmdW5jYW8iOiJ1c2VyQWRtaW5NYXN0ZXIiLCJpYXQiOjE2OTk3NTYyMjgsImV4cCI6MTY5OTc2NzAyOH0._X-RGsqhEyaWTrhqHlhLC1Ob9AHzAzYj4kH9MyxLSNs",
              "tipo_entrada_saida": "entrada",

          
        }*/
  @Post('find-ultimos-50-entrada-saida') // Rota para atualizar campos de SEO
  async fundLast50EntradaSaidaCont(
    @Body() updateDto: any,
    ) {




    try {


      //return {"msg":updateDto}

        //console.log("teste");
        //return updateDto;
        return this.sisfinanceiroService.findLast50Service(updateDto);
      }catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
      } else {
        throw new UnauthorizedException('Token inválido.');
      }
    }
  }




   /* 

 http://localhost:3570/sisfinanceiro/create-new-financ

 {
              "token":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJsb2dpbiI6Im1hcmNvc2xlaXRlIiwiaG9zdG5hbWUiOiJzZW8tYmguYXJjYXdlYi5jb20uYnIiLCJ1c2VyX2RvbWluaW8iOiJ0cmFmZWdvYXJjYXdlYiIsInMzcGFzdGEiOiJtYXJjb3NsZWl0ZS1hcmNhd2ViLXNlby1icE1TVFZmQ2dIdWQiLCJmdW5jYW8iOiJ1c2VyQWRtaW5NYXN0ZXIiLCJpYXQiOjE2OTk3NTYyMjgsImV4cCI6MTY5OTc2NzAyOH0._X-RGsqhEyaWTrhqHlhLC1Ob9AHzAzYj4kH9MyxLSNs",
              "categoria":"um",
              "subCategoria":["teste","teste"],
              "tipo_entrada_saida": "entrada",
              "data":"11/11/2023 17:46",
              "dia":12,
              "mes":11,
              "ano":2023,
              "descricao":"VAMOS TESTAR PARA VER...",
              "valor":10.50

          
        }*/





  @Post('create-new-financ') // Rota para atualizar campos de SEO

  async createNewFinanc(
    @Body() updateDto: any,
    ) {

    try {


      //return {"msg":updateDto}

        //console.log("teste");
        //return updateDto;
        return this.sisfinanceiroService.createNewFinancService(updateDto);
      }catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
      } else {
        throw new UnauthorizedException('Token inválido.');
      }
    }
  }



  @Post('create-new-category') // Rota para atualizar campos de SEO
  async createNewCategory(
    @Body() updateDto: any,
    ) {

    try {


      //return {"msg":updateDto}

        //console.log("teste");
        //return updateDto;
        return this.sisfinanceiroService.createNewCategoryService(updateDto);
      }catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
      } else {
        throw new UnauthorizedException('Token inválido.');
      }
    }
  }



@Post('add-new-subcat') // Rota para atualizar campos de SEO
  async addNewSub(
    @Body() updateDto: any,
    ) {


    /* 

          http://localhost:3570/sisfinanceiro/add-new-subcat

         {
                      "token":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJsb2dpbiI6Im1hcmNvc2xlaXRlIiwiaG9zdG5hbWUiOiJzZW8tYmguYXJjYXdlYi5jb20uYnIiLCJ1c2VyX2RvbWluaW8iOiJ0cmFmZWdvYXJjYXdlYiIsInMzcGFzdGEiOiJtYXJjb3NsZWl0ZS1hcmNhd2ViLXNlby1icE1TVFZmQ2dIdWQiLCJmdW5jYW8iOiJ1c2VyQWRtaW5NYXN0ZXIiLCJpYXQiOjE2OTk3MzU0MTAsImV4cCI6MTY5OTc0NjIxMH0.FUtlJ1fTxpRydd-7qLhcc_ZzkfL2RjqMyalVfEkwzJQ",
                      "categoria":"um",
                      "subCategoria":["teste687987","teste123","teste123", "um", "quatro"],
                      "tipo_entrada_saida": "entrada"

                  
                }

        */

    try {


      //return {"msg":updateDto}

        //console.log("teste");
        //return updateDto;
        return this.sisfinanceiroService.addSubCategServ(updateDto);
      }catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
      } else {
        throw new UnauthorizedException('Token inválido.');
      }
    }
  }

  @Post()
  create(@Body() createSisfinanceiroDto: CreateSisfinanceiroDto) {
    return this.sisfinanceiroService.create(createSisfinanceiroDto);
  }

  @Get()
  findAll() {
    return this.sisfinanceiroService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.sisfinanceiroService.findOne(+id);
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() updateSisfinanceiroDto: UpdateSisfinanceiroDto) {
    return this.sisfinanceiroService.update(+id, updateSisfinanceiroDto);
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.sisfinanceiroService.remove(+id);
  }}

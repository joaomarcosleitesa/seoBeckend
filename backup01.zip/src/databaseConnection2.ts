// database.connection.ts
import { Mongoose } from 'mongoose';

export const databaseConnection = async (): Promise<Mongoose> => {
  const mongoose = new Mongoose();
  await mongoose.connect('mongodb://localhost/ceps');
  return mongoose;
};
import { Schema, Document } from 'mongoose';


export interface gestorTempo extends Document {
  hostname: string;
  login: string;
  user_dominio: string;
  categoria: string;
  subCategoria: string[];
  data: string;
  dia: number
  mes: number;
  ano: number;
  timeInicio: string;
  timeFinal: string;
  descricao: string;
  calcTemp: string;
  horaInicial: number;
  minutoInicial: number;
  horaFinal: number;
  minutoFinal: number;
  
  
}

// Defina o nome da coleção personalizado no esquema
export const GestTempoSchema = new Schema({


  hostname: { 
      type:String,
      default:""
      },

  login: { 
      type:String,
      default:""
      },

  user_dominio: { 
      type:String,
      default:""
      },

  categoria: { 
      type:String,
      default:""
      },

  subCategoria: {
      type: [String],  // Defina o campo como um array de strings
      default: []  // Defina um array vazio como valor padrão
    },

    data: { 
      type:String,
      default:""
      },

    dia: { 
      type:Number,
      default:0
      },

    mes: { 
      type:Number,
      default:0
      },


    ano: { 
        type:Number,
        default:0
      },

     timeInicio: { 
        type:String,
        default:""
      },

      timeFinal: { 
        type:String,
        default:""
      },

      descricao: { 
        type:String,
        default:""
      },

      calcTemp: { 
        type:String,
        default:""
      },

      horaInicial: { 
        type:Number,
        default:0
      },

      minutoInicial: { 
        type:Number,
        default:0
      },

      horaFinal: { 
        type:Number,
        default:0
      },

      minutoFinal: { 
        type:Number,
        default:0
      },




  


  }, 
  




  {
    collection: 'gestortempo', // Substitua 'dados_empresa' pelo nome desejado da coleção
  });







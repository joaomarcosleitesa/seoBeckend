export class Gestortempo {}

import { Module } from '@nestjs/common';
import { JwtModule } from '@nestjs/jwt'; // Importe o JwtModule

import { GestortempoService } from './gestortempo.service';
import { GestortempoController } from './gestortempo.controller';
import { UserSchema } from '../user/user.model';
import { MongooseModule } from '@nestjs/mongoose';

import { UserService } from '../user/user.service'; // Importe o AuthService

import { GestCategSchema } from './gestortempocateg.model';
import { GestTempoSchema } from './gestortempo.model';

// import Authservice 
import { jwtConstants } from '../auth/jwt.config'; // Importe a configuração JWT
import { AuthService } from '../auth/auth.service'; // Importe o AuthService

@Module({
  imports:[
    MongooseModule.forFeature([{ name: 'gestorTempo', schema: GestTempoSchema}]),
    MongooseModule.forFeature([{ name: 'gestCateg', schema: GestCategSchema}]),
    MongooseModule.forFeature([{ name: 'User', schema: UserSchema }]),
    JwtModule.register({
      secret: jwtConstants.secret,
      signOptions: { expiresIn: jwtConstants.expiresIn },
    }),
    ],
  controllers: [GestortempoController],
  providers: [GestortempoService, AuthService],
})
export class GestortempoModule {}

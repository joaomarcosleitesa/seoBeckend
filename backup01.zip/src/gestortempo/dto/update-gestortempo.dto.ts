import { PartialType } from '@nestjs/mapped-types';
import { CreateGestortempoDto } from './create-gestortempo.dto';

export class UpdateGestortempoDto extends PartialType(CreateGestortempoDto) {}

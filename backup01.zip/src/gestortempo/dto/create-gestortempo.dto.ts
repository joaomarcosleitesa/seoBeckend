export class CreateGestortempoDto {}

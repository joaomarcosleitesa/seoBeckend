import { Controller, Get, Post, Body, Patch, Param, Delete, UnauthorizedException } from '@nestjs/common';
import { GestortempoService } from './gestortempo.service';
import { CreateGestortempoDto } from './dto/create-gestortempo.dto';
import { UpdateGestortempoDto } from './dto/update-gestortempo.dto';

@Controller('gestortempo')
export class GestortempoController {
  constructor(private readonly gestortempoService: GestortempoService) {}




 /* 

 http://localhost:3570/sisfinanceiro/find-ultimos-50-entrada-saida


      tipo_entrada_saida: pode ser "entrada" ou "saida"

 {
              "token":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJsb2dpbiI6Im1hcmNvc2xlaXRlIiwiaG9zdG5hbWUiOiJzZW8tYmguYXJjYXdlYi5jb20uYnIiLCJ1c2VyX2RvbWluaW8iOiJ0cmFmZWdvYXJjYXdlYiIsInMzcGFzdGEiOiJtYXJjb3NsZWl0ZS1hcmNhd2ViLXNlby1icE1TVFZmQ2dIdWQiLCJmdW5jYW8iOiJ1c2VyQWRtaW5NYXN0ZXIiLCJpYXQiOjE2OTk3NTYyMjgsImV4cCI6MTY5OTc2NzAyOH0._X-RGsqhEyaWTrhqHlhLC1Ob9AHzAzYj4kH9MyxLSNs",
              "tipo_entrada_saida": "entrada",

          
        }*/
  @Post('find-sum-sub-categ-mes-day-tempo') // Rota para atualizar campos de SEO
  async findSumSubCategoryMesControler(
    @Body() updateDto: any,
    ) {




    try {


      //return {"msg":updateDto}

        //console.log("teste");
        //return updateDto;
        return this.gestortempoService.findSumSubCategoryServiceDayMes(updateDto);
      }catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
      } else {
        throw new UnauthorizedException('Token inválido.');
      }
    }
  }



  /* 

 http://localhost:3570/sisfinanceiro/find-ultimos-50-entrada-saida


      tipo_entrada_saida: pode ser "entrada" ou "saida"

 {
              "token":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJsb2dpbiI6Im1hcmNvc2xlaXRlIiwiaG9zdG5hbWUiOiJzZW8tYmguYXJjYXdlYi5jb20uYnIiLCJ1c2VyX2RvbWluaW8iOiJ0cmFmZWdvYXJjYXdlYiIsInMzcGFzdGEiOiJtYXJjb3NsZWl0ZS1hcmNhd2ViLXNlby1icE1TVFZmQ2dIdWQiLCJmdW5jYW8iOiJ1c2VyQWRtaW5NYXN0ZXIiLCJpYXQiOjE2OTk3NTYyMjgsImV4cCI6MTY5OTc2NzAyOH0._X-RGsqhEyaWTrhqHlhLC1Ob9AHzAzYj4kH9MyxLSNs",
              "tipo_entrada_saida": "entrada",

          
        }*/
  @Post('find-sum-sub-categ-financ-day') // Rota para atualizar campos de SEO
  async findSumSubCategoryDayControler(
    @Body() updateDto: any,
    ) {




    try {


      //return {"msg":updateDto}

        //console.log("teste");
        //return updateDto;
        return this.gestortempoService.findSumSubCategoryServiceDay(updateDto);
      }catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
      } else {
        throw new UnauthorizedException('Token inválido.');
      }
    }
  }





   /* 

 http://localhost:3570/sisfinanceiro/find-ultimos-50-entrada-saida


      tipo_entrada_saida: pode ser "entrada" ou "saida"

 {
              "token":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJsb2dpbiI6Im1hcmNvc2xlaXRlIiwiaG9zdG5hbWUiOiJzZW8tYmguYXJjYXdlYi5jb20uYnIiLCJ1c2VyX2RvbWluaW8iOiJ0cmFmZWdvYXJjYXdlYiIsInMzcGFzdGEiOiJtYXJjb3NsZWl0ZS1hcmNhd2ViLXNlby1icE1TVFZmQ2dIdWQiLCJmdW5jYW8iOiJ1c2VyQWRtaW5NYXN0ZXIiLCJpYXQiOjE2OTk3NTYyMjgsImV4cCI6MTY5OTc2NzAyOH0._X-RGsqhEyaWTrhqHlhLC1Ob9AHzAzYj4kH9MyxLSNs",
              "tipo_entrada_saida": "entrada",

          
        }*/
  @Post('find-sum-categ-financ-day') // Rota para atualizar campos de SEO
  async findSumCategoryDayControler(
    @Body() updateDto: any,
    ) {




    try {


      //return {"msg":updateDto}

        //console.log("teste");
        //return updateDto;
        return this.gestortempoService.findSumCategoryServiceDay(updateDto);
      }catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
      } else {
        throw new UnauthorizedException('Token inválido.');
      }
    }
  }



   /* 

 http://localhost:3570/sisfinanceiro/find-ultimos-50-entrada-saida


      tipo_entrada_saida: pode ser "entrada" ou "saida"

 {
              "token":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJsb2dpbiI6Im1hcmNvc2xlaXRlIiwiaG9zdG5hbWUiOiJzZW8tYmguYXJjYXdlYi5jb20uYnIiLCJ1c2VyX2RvbWluaW8iOiJ0cmFmZWdvYXJjYXdlYiIsInMzcGFzdGEiOiJtYXJjb3NsZWl0ZS1hcmNhd2ViLXNlby1icE1TVFZmQ2dIdWQiLCJmdW5jYW8iOiJ1c2VyQWRtaW5NYXN0ZXIiLCJpYXQiOjE2OTk3NTYyMjgsImV4cCI6MTY5OTc2NzAyOH0._X-RGsqhEyaWTrhqHlhLC1Ob9AHzAzYj4kH9MyxLSNs",
              "tipo_entrada_saida": "entrada",

          
        }*/
  @Post('find-sum-categ-financ') // Rota para atualizar campos de SEO
  async findSumCategoryControler(
    @Body() updateDto: any,
    ) {




    try {


      //return {"msg":updateDto}

        //console.log("teste");
        //return updateDto;
        return this.gestortempoService.findSumCategoryService(updateDto);
      }catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
      } else {
        throw new UnauthorizedException('Token inválido.');
      }
    }
  }



 /* 

 http://localhost:3570/sisfinanceiro/find-ultimos-50-entrada-saida


      tipo_entrada_saida: pode ser "entrada" ou "saida"

 {
              "token":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJsb2dpbiI6Im1hcmNvc2xlaXRlIiwiaG9zdG5hbWUiOiJzZW8tYmguYXJjYXdlYi5jb20uYnIiLCJ1c2VyX2RvbWluaW8iOiJ0cmFmZWdvYXJjYXdlYiIsInMzcGFzdGEiOiJtYXJjb3NsZWl0ZS1hcmNhd2ViLXNlby1icE1TVFZmQ2dIdWQiLCJmdW5jYW8iOiJ1c2VyQWRtaW5NYXN0ZXIiLCJpYXQiOjE2OTk3NTYyMjgsImV4cCI6MTY5OTc2NzAyOH0._X-RGsqhEyaWTrhqHlhLC1Ob9AHzAzYj4kH9MyxLSNs",
              "tipo_entrada_saida": "entrada",

          
        }*/
  @Post('find-date-gestor-tempo-day') // Rota para atualizar campos de SEO
  async fundLast50EntradaSaidaCont(
    @Body() updateDto: any,
    ) {




    try {


      //return {"msg":updateDto}

        //console.log("teste");
        //return updateDto;
        return this.gestortempoService.findDateGestorTempo(updateDto);
      }catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
      } else {
        throw new UnauthorizedException('Token inválido.');
      }
    }
  }



 /*http://localhost:3570/gestortempo/create-new-financ

 {
              "token":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJsb2dpbiI6Im1hcmNvc2xlaXRlIiwiaG9zdG5hbWUiOiJzZW8tYmguYXJjYXdlYi5jb20uYnIiLCJ1c2VyX2RvbWluaW8iOiJ0cmFmZWdvYXJjYXdlYiIsInMzcGFzdGEiOiJtYXJjb3NsZWl0ZS1hcmNhd2ViLXNlby1icE1TVFZmQ2dIdWQiLCJmdW5jYW8iOiJ1c2VyQWRtaW5NYXN0ZXIiLCJpYXQiOjE2OTk3NTYyMjgsImV4cCI6MTY5OTc2NzAyOH0._X-RGsqhEyaWTrhqHlhLC1Ob9AHzAzYj4kH9MyxLSNs",
              "categoria":"um",
              "subCategoria":["teste","teste"],
              "tipo_entrada_saida": "entrada",
              "data":"11/11/2023 17:46",
              "dia":12,
              "mes":11,
              "ano":2023,
              "descricao":"VAMOS TESTAR PARA VER...",
              "valor":10.50

          
        }*/

   @Post('create-new-financ') // Rota para atualizar campos de SEO

  async createNewFinanc(
    @Body() updateDto: any,
    ) {

    try {


      //return {"msg":updateDto}

        //console.log("teste");
        //return updateDto;
        return this.gestortempoService.createNewFinancService(updateDto);
      }catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
      } else {
        throw new UnauthorizedException('Token inválido.');
      }
    }
  }




    /* 

          http://localhost:3570/sisfinanceiro/add-new-subcat

         {
                      "token":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJsb2dpbiI6Im1hcmNvc2xlaXRlIiwiaG9zdG5hbWUiOiJzZW8tYmguYXJjYXdlYi5jb20uYnIiLCJ1c2VyX2RvbWluaW8iOiJ0cmFmZWdvYXJjYXdlYiIsInMzcGFzdGEiOiJtYXJjb3NsZWl0ZS1hcmNhd2ViLXNlby1icE1TVFZmQ2dIdWQiLCJmdW5jYW8iOiJ1c2VyQWRtaW5NYXN0ZXIiLCJpYXQiOjE2OTk3MzU0MTAsImV4cCI6MTY5OTc0NjIxMH0.FUtlJ1fTxpRydd-7qLhcc_ZzkfL2RjqMyalVfEkwzJQ",
                      "categoria":"um",
                      "subCategoria":["teste687987","teste123","teste123", "um", "quatro"],
                      "tipo_entrada_saida": "entrada"

                  
                }

        */
@Post('add-new-subcat') // Rota para atualizar campos de SEO
  async addNewSub(
    @Body() updateDto: any,
    ) {



    try {


      //return {"msg":updateDto}

        //console.log("teste");
        //return updateDto;
        return this.gestortempoService.addSubCategServ(updateDto);
      }catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
      } else {
        throw new UnauthorizedException('Token inválido.');
      }
    }
  }

   @Post('create-new-category') // Rota para atualizar campos de SEO
  async createNewCategory(
    @Body() updateDto: any,
    ) {

    try {


      //return {"msg":updateDto}

        //console.log("teste");
        //return updateDto;
        return this.gestortempoService.createNewCategoryService(updateDto);
      }catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
      } else {
        throw new UnauthorizedException('Token inválido.');
      }
    }
  }


  /* 

       http://localhost:3570/sisfinanceiro/find-categorias-financ


            tipo_entrada_saida: pode ser "entrada" ou "saida"

       {
                    "token":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJsb2dpbiI6Im1hcmNvc2xlaXRlIiwiaG9zdG5hbWUiOiJzZW8tYmguYXJjYXdlYi5jb20uYnIiLCJ1c2VyX2RvbWluaW8iOiJ0cmFmZWdvYXJjYXdlYiIsInMzcGFzdGEiOiJtYXJjb3NsZWl0ZS1hcmNhd2ViLXNlby1icE1TVFZmQ2dIdWQiLCJmdW5jYW8iOiJ1c2VyQWRtaW5NYXN0ZXIiLCJpYXQiOjE2OTk3NTYyMjgsImV4cCI6MTY5OTc2NzAyOH0._X-RGsqhEyaWTrhqHlhLC1Ob9AHzAzYj4kH9MyxLSNs",
              "tipo_entrada_saida": "entrada",
              "ano":"ano",
              "mes":"mes"

          
        }*/

@Post('find-categorias-gestortempo') // Rota para atualizar campos de SEO
  async fundCategoriasFinanc(
    @Body() updateDto: any,
    ) {

    try {


     


      //return {"msg":updateDto}

        //console.log("teste");
        //return updateDto;
        return this.gestortempoService.findAllCategoriesService(updateDto);
      }catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
      } else {
        throw new UnauthorizedException('Token inválido.');
      }
    }
  }


   /* 

       http://localhost:3570/sisfinanceiro/find-sum-subcategoria-financ


            tipo_entrada_saida: pode ser "entrada" ou "saida"

       {
                    "token":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJsb2dpbiI6Im1hcmNvc2xlaXRlIiwiaG9zdG5hbWUiOiJzZW8tYmguYXJjYXdlYi5jb20uYnIiLCJ1c2VyX2RvbWluaW8iOiJ0cmFmZWdvYXJjYXdlYiIsInMzcGFzdGEiOiJtYXJjb3NsZWl0ZS1hcmNhd2ViLXNlby1icE1TVFZmQ2dIdWQiLCJmdW5jYW8iOiJ1c2VyQWRtaW5NYXN0ZXIiLCJpYXQiOjE2OTk3NTYyMjgsImV4cCI6MTY5OTc2NzAyOH0._X-RGsqhEyaWTrhqHlhLC1Ob9AHzAzYj4kH9MyxLSNs",
              "tipo_entrada_saida": "entrada",
              "ano":"ano",
              "mes":"mes"

          
        }*/

@Post('find-subcategoria-gestortempo') // Rota para atualizar campos de SEO
  async fundSubCatGestorController(
    @Body() updateDto: any,
    ) {

    try {

     


      //return {"msg":updateDto}

        //console.log("teste");
        //return updateDto;
        return this.gestortempoService.findAllSubCategoriesByCategoryService(updateDto);
      }catch (error) {
      // Ocorreu um erro ao verificar o token
      if (error.name === 'TokenExpiredError') {
        throw new UnauthorizedException('Token expirado.');
      } else {
        throw new UnauthorizedException('Token inválido.');
      }
    }
  }


  @Post()
  create(@Body() createGestortempoDto: CreateGestortempoDto) {
    return this.gestortempoService.create(createGestortempoDto);
  }

  @Get()
  findAll() {
    return this.gestortempoService.findAll();
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.gestortempoService.findOne(+id);
  }

  @Patch(':id')
  update(@Param('id') id: string, @Body() updateGestortempoDto: UpdateGestortempoDto) {
    return this.gestortempoService.update(+id, updateGestortempoDto);
  }

  @Delete(':id')
  remove(@Param('id') id: string) {
    return this.gestortempoService.remove(+id);
  }
}

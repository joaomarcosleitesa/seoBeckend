import { Test, TestingModule } from '@nestjs/testing';
import { GestortempoController } from './gestortempo.controller';
import { GestortempoService } from './gestortempo.service';

describe('GestortempoController', () => {
  let controller: GestortempoController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [GestortempoController],
      providers: [GestortempoService],
    }).compile();

    controller = module.get<GestortempoController>(GestortempoController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});

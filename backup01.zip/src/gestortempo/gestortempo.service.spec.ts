import { Test, TestingModule } from '@nestjs/testing';
import { GestortempoService } from './gestortempo.service';

describe('GestortempoService', () => {
  let service: GestortempoService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [GestortempoService],
    }).compile();

    service = module.get<GestortempoService>(GestortempoService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});

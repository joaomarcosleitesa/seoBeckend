import { Injectable, NotFoundException, ConflictException, UnauthorizedException } from '@nestjs/common';
import { CreateGestortempoDto } from './dto/create-gestortempo.dto';
import { UpdateGestortempoDto } from './dto/update-gestortempo.dto';

import { InjectModel } from '@nestjs/mongoose'; // Importe o InjectModel para injetar o modelo
import { Model } from 'mongoose'; // Certifique-se de importar o Model do Mongoose
import { gestCateg } from './gestortempocateg.model';
import { gestorTempo } from './gestortempo.model';

import { AuthService } from '../auth/auth.service'; // Importe o AuthService


@Injectable()
export class GestortempoService {

   constructor(
    @InjectModel('gestCateg')

    private readonly gestCategModel: Model<gestCateg>,
    private readonly authService: AuthService,

    @InjectModel('gestorTempo')
    private readonly gestTempoModel: Model<gestorTempo>,
 
    /* @InjectModel('financ') 
     private readonly financModel: Model<financ>, 
    private readonly authService: AuthService,*/


    ) {}


     async findDateGestorTempo(updateDto: any) {
 try {
  // Valide os dados de entrada aqui, se necessário.
  const token = updateDto.token;

  const decodedToken = await this.authService.verifyToken(token);

    if (!decodedToken) {
        return {
          success: false,
          message: 'Token inválido.',
        };
      }
        const { 
          dia, 
          mes, 
          ano,
        } = updateDto;

  const last50Entrada = await this.gestTempoModel.find(
    { 
      login:decodedToken.login,
      dia, 
        mes, 
        ano,

    }).sort({ano: -1,
        mes: -1,
        dia: -1,
        horaInicial: -1,  
        minutoInicial: -1, 
         })

  if (last50Entrada) {
    return {
      success: true,
      message: 'Últimos 50 itens de entrada buscados com sucesso!',
      financ: last50Entrada,
    };
  } else {
    return {
      success: false,
      message: 'Falha ao buscar os últimos 50 itens de entrada.',
    };
  }
 } catch (error) {
  return {
    "msg":error.message,
    success: false,
  }
  throw new Error(`Erro ao buscar dados por login: ${error.message}`);
 }
}



async findSumCategoryServiceDay(updateDto: any) {
 try {
   const token = updateDto.token;
   const decodedToken = await this.authService.verifyToken(token);

   if (!decodedToken) {
     return {
       success: false,
       message: 'Token inválido.',
     };
   }

   const { dia, mes, ano  } = updateDto;



   const sumByCategory = await this.gestTempoModel.aggregate([
     {
       $match: {
         dia:dia,
         mes: mes,
         ano: ano,
         login: decodedToken.login,
       }
     },
     {
       $group: {
         _id: "$categoria",
         total: {
           $sum: {
             $add: [
               { $multiply: [{ $toInt: { $substrBytes: ["$calcTemp", 0, 2] } }, 60] },
               { $toInt: { $substrBytes: ["$calcTemp", 3, 2] } }
             ]
           }
         }
       }
     },
     {
       $group: {
         _id: null,
         categories: { $push: { categoria: "$_id", total: "$total" } },
         totalGeral: { $sum: "$total" }
       }
     },
     {
       $unwind: "$categories"
     },
     {
       $sort: { "categories.total": -1 }
     },
     {
       $group: {
         _id: null,
         categories: { $push: "$categories" },
         totalGeral: { $first: "$totalGeral" }
       }
     }
   ]);

   if (sumByCategory.length > 0) {
     return {
       success: true,
       message: 'Soma dos valores das categorias do mês calculada com sucesso!',
       total: sumByCategory[0].categories,
       totalGeral: sumByCategory[0].totalGeral,
     };
   } else {
     return {
       success: false,
       message: 'Nenhum valor encontrado para as categorias do dia especificado.',
     };
   }
 } catch (error) {
   return {
     msg: error.message,
     success: false,
   };
 }
}


async findSumSubCategoryServiceDayMes(updateDto: any) {
 try {
  const token = updateDto.token;
  const decodedToken = await this.authService.verifyToken(token);

  if (!decodedToken) {
    return {
      success: false,
      message: 'Token inválido.',
    };
  }

  const {  mes, ano } = updateDto;

  const sumByCategory = await this.gestTempoModel.aggregate([
    {
      $match: {
        mes: mes,
        ano: ano,
        login: decodedToken.login,
      }
    },
    {
      $group: {
        _id: {
          categoria: "$categoria",
          subCategoria: "$subCategoria",
        },
        total: {
          $sum: {
            $add: [
              { $multiply: [{ $toInt: { $substrBytes: ["$calcTemp", 0, 2] } }, 60] },
              { $toInt: { $substrBytes: ["$calcTemp", 3, 2] } }
            ]
          }
        }
      }
    },
    {
      $group: {
        _id: "$_id.categoria",
        subCategorias: {
          $push: {
            subCategoria: "$_id.subCategoria",
            total: "$total",
          },
        },
        totalCategoria: { $sum: "$total" },
      },
    },
    {
      $unwind: "$subCategorias",
    },
    {
      $sort: { "subCategorias.total": -1 },
    },
    {
      $group: {
        _id: null,
        categories: {
          $push: {
            categoria: "$_id",
            subCategorias: "$subCategorias",
            total: "$totalCategoria",
          },
        },
        totalGeral: { $sum: "$totalCategoria" },
      },
    }
  ]);

  if (sumByCategory.length > 0) {
    return {
      success: true,
      message: 'Soma dos valores das categorias do dia calculada com sucesso!',
      total: sumByCategory[0].categories,
      totalGeral: sumByCategory[0].totalGeral,
    };
  } else {
    return {
      success: false,
      message: 'Nenhum valor encontrado para as categorias do dia especificado.',
    };
  }
 } catch (error) {
  return {
    msg: error.message,
    success: false,
  };
 }
}

async findSumSubCategoryServiceDay(updateDto: any) {
 try {
  const token = updateDto.token;
  const decodedToken = await this.authService.verifyToken(token);

  if (!decodedToken) {
    return {
      success: false,
      message: 'Token inválido.',
    };
  }

  const { dia, mes, ano } = updateDto;

  const sumByCategory = await this.gestTempoModel.aggregate([
    {
      $match: {
        dia:dia,
        mes: mes,
        ano: ano,
        login: decodedToken.login,
      }
    },
    {
      $group: {
        _id: {
          categoria: "$categoria",
          subCategoria: "$subCategoria",
        },
        total: {
          $sum: {
            $add: [
              { $multiply: [{ $toInt: { $substrBytes: ["$calcTemp", 0, 2] } }, 60] },
              { $toInt: { $substrBytes: ["$calcTemp", 3, 2] } }
            ]
          }
        }
      }
    },
    {
      $group: {
        _id: "$_id.categoria",
        subCategorias: {
          $push: {
            subCategoria: "$_id.subCategoria",
            total: "$total",
          },
        },
        totalCategoria: { $sum: "$total" },
      },
    },
    {
      $unwind: "$subCategorias",
    },
    {
      $sort: { "subCategorias.total": -1 },
    },
    {
      $group: {
        _id: null,
        categories: {
          $push: {
            categoria: "$_id",
            subCategorias: "$subCategorias",
            total: "$totalCategoria",
          },
        },
        totalGeral: { $sum: "$totalCategoria" },
      },
    }
  ]);

  if (sumByCategory.length > 0) {
    return {
      success: true,
      message: 'Soma dos valores das categorias do dia calculada com sucesso!',
      total: sumByCategory[0].categories,
      totalGeral: sumByCategory[0].totalGeral,
    };
  } else {
    return {
      success: false,
      message: 'Nenhum valor encontrado para as categorias do dia especificado.',
    };
  }
 } catch (error) {
  return {
    msg: error.message,
    success: false,
  };
 }
}

async findSumCategoryService(updateDto: any) {
 try {
   const token = updateDto.token;
   const decodedToken = await this.authService.verifyToken(token);

   if (!decodedToken) {
     return {
       success: false,
       message: 'Token inválido.',
     };
   }

   const { mes, ano } = updateDto;

     // Verifica se o campo 'dia' existe
  const diaExists = await this.gestTempoModel.findOne({ dia: { $exists: true } });

   const sumByCategory = await this.gestTempoModel.aggregate([
     {
       $match: {
         mes: mes,
         ano: ano,
         login: decodedToken.login,
       }
     },
     {
       $group: {
         _id: "$categoria",
         total: {
           $sum: {
             $add: [
               { $multiply: [{ $toInt: { $substrBytes: ["$calcTemp", 0, 2] } }, 60] },
               { $toInt: { $substrBytes: ["$calcTemp", 3, 2] } }
             ]
           }
         }
       }
     },
     {
       $group: {
         _id: null,
         categories: { $push: { categoria: "$_id", total: "$total" } },
         totalGeral: { $sum: "$total" }
       }
     },
     {
       $unwind: "$categories"
     },
     {
       $sort: { "categories.total": -1 }
     },
     {
       $group: {
         _id: null,
         categories: { $push: "$categories" },
         totalGeral: { $first: "$totalGeral" }
       }
     }
   ]);

   if (sumByCategory.length > 0) {
     return {
       success: true,
       message: 'Soma dos valores das categorias do mês calculada com sucesso!',
       total: sumByCategory[0].categories,
       totalGeral: sumByCategory[0].totalGeral,
     };
   } else {
     return {
       success: false,
       message: 'Nenhum valor encontrado para as categorias do mês especificado.',
     };
   }
 } catch (error) {
   return {
     msg: error.message,
     success: false,
   };
 }
}





     async createNewFinancService(updateDto: any) {

    try {
      // Valide os dados de entrada aqui, se necessário.
      const token = updateDto.token;

       const decodedToken = await this.authService.verifyToken(token);
       //return {"msgToken":decodedToken}

      const { 
        categoria,
        subCategoria, 
        data, 
        dia, 
        mes, 
        ano, 
        timeInicio,
        timeFinal,
        descricao, 
        calcTemp,
        horaInicial,
        minutoInicial,
        horaFinal,
        minutoFinal 

      } = updateDto;
      //const pastaS3 = imgsUrls[0].pastaS3;



      const newFinanc = new this.gestTempoModel({


              hostname:decodedToken.hostname, 
              login:decodedToken.login,
              user_dominio:decodedToken.user_dominio,
              categoria:categoria,
              subCategoria:subCategoria,
              data:data,
              dia:dia,
              mes, 
              ano, 
              timeInicio,
              timeFinal,
              descricao, 
              calcTemp,
              horaInicial,
              minutoInicial,
              horaFinal,
              minutoFinal 



      });

       const savedFinanc = await newFinanc.save();

      if (savedFinanc) {
        return {
          success: true,
          message: 'Categoria salva com sucesso!',
          product: savedFinanc,
        };
      } else {
        return {
          success: false,
          message: 'Falha ao salvar o Categoria.',
        };
      }
    }catch (error) {
          // Lidar com erros de consulta, se necessário
            return {
              "msg":error.message,
              success: true,
            }
            throw new Error(`Erro ao buscar dados por login: ${error.message}`);
        }
    }





   async addSubCategServ(updateDto: any) {

    try {
      // Valide os dados de entrada aqui, se necessário.
      const token = updateDto.token;

       const decodedToken = await this.authService.verifyToken(token);
       //return {"msgToken":decodedToken}

       const login = decodedToken.login;

      const {categoria, subCategoria} = updateDto;
      //const pastaS3 = imgsUrls[0].pastaS3;


         // Verifique se login, categoria e tipo_entrada_saida já existem
      const existingRecord = await this.gestCategModel.findOne({ login, categoria });


      if (existingRecord) {
         // Se login, categoria e tipo_entrada_saida existirem, adicione as novas subcategorias sem duplicatas
         const uniqueSubCategories = [...new Set([...existingRecord.subCategoria, ...subCategoria])];
         existingRecord.subCategoria = uniqueSubCategories;
         
         const updatedRecord = await existingRecord.save();

         return {
           success: true,
           message: 'Subcategorias adicionadas com sucesso!',
           record: updatedRecord,
         };
       } else {
           return {
             success: false,
             message: 'Não Cadastrado, talvez a categoria não existe!'
           };
       }

      

      /*if (savedProduct) {
        return {
          success: true,
          message: 'Categoria salva com sucesso!',
          product: savedProduct,
        };
      } else {
        return {
          success: false,
          message: 'Falha ao salvar o Categoria.',
        };
      }*/
    }catch (error) {
          // Lidar com erros de consulta, se necessário
            return {
              "msg":error.message,
              success: true,
            }
            throw new Error(`Erro ao buscar dados por login: ${error.message}`);
        }
    }



   /* 

  http://localhost:3570/sisfinanceiro/create-new-category

 {
              "token":"eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJsb2dpbiI6Im1hcmNvc2xlaXRlIiwiaG9zdG5hbWUiOiJzZW8tYmguYXJjYXdlYi5jb20uYnIiLCJ1c2VyX2RvbWluaW8iOiJ0cmFmZWdvYXJjYXdlYiIsInMzcGFzdGEiOiJtYXJjb3NsZWl0ZS1hcmNhd2ViLXNlby1icE1TVFZmQ2dIdWQiLCJmdW5jYW8iOiJ1c2VyQWRtaW5NYXN0ZXIiLCJpYXQiOjE2OTk3MzU0MTAsImV4cCI6MTY5OTc0NjIxMH0.FUtlJ1fTxpRydd-7qLhcc_ZzkfL2RjqMyalVfEkwzJQ",
              "hostname":"arcawebagencia.com.br", 
              "login":"marcosleite",
              "user_dominio":"testelogin",
              "categoria":"um",
              "subCategoria":["teste","teste"],
              "tipo_entrada_saida": "entrada",
              "data":"11/11/2023 17:46"

          
        }*/


  async createNewCategoryService(updateDto: any) {
  try {
    // Valide os dados de entrada aqui, se necessário.
    const token = updateDto.token;
    const decodedToken = await this.authService.verifyToken(token);
    const { categoria, subCategoria, tipo_entrada_saida, data, projtipo } = updateDto;

    // Verificar se a categoria já existe
    const existingCategory = await this.gestCategModel.findOne({
      hostname: decodedToken.hostname,
      login: decodedToken.login,
      user_dominio: decodedToken.user_dominio,
      projtipo: projtipo,
      categoria: categoria


    });

    if (existingCategory) {
      return {
        success: false,
        message: 'A Categoria já existe.',
      };
    }

    // A categoria não existe, então podemos criar e salvar
    const newCategory = new this.gestCategModel({
      hostname: decodedToken.hostname,
      login: decodedToken.login,
      user_dominio: decodedToken.user_dominio,
      categoria: categoria,
      subCategoria: subCategoria,
      projtipo: projtipo,
      data: data
    });

    const savedCategory = await newCategory.save();

    if (savedCategory) {
      return {
        success: true,
        message: 'Categoria salva com sucesso!',
        product: savedCategory,
      };
    } else {
      return {
        success: false,
        message: 'Falha ao salvar a Categoria.',
      };
    }
  } catch (error) {
    // Lidar com erros de consulta, se necessário
    return {
      msg: error.message,
      success: false,
    }
  }
}



async findAllCategoriesService(updateDto: any) {
 try {
  // Valide os dados de entrada aqui, se necessário.
  const token = updateDto.token;

  const decodedToken = await this.authService.verifyToken(token);

  if (!decodedToken) {
    return {
      success: false,
      message: 'Token inválido.',
    };
  }



  const allCategories = await this.gestCategModel.find(
    { 
      login: decodedToken.login
    }
  ).select('categoria'); // Selecione apenas o campo 'categoria'

  if (allCategories) {
    return {
      success: true,
      message: 'Todas as categorias buscadas com sucesso!',
      financ: allCategories,
    };
  } else {
    return {
      success: false,
      message: 'Falha ao buscar todas as categorias.',
    };
  }
 } catch (error) {
 return {
   "msg":error.message,
   success: false,
 }
 throw new Error(`Erro ao buscar todas as categorias: ${error.message}`);
 }
}




async findAllSubCategoriesByCategoryService(updateDto: any) {
 try {
  // Valide os dados de entrada aqui, se necessário.
  const token = updateDto.token;

  const decodedToken = await this.authService.verifyToken(token);



  if (!decodedToken) {
    return {
      success: false,
      message: 'Token inválido.',
    };
  }

  const { categoria } = updateDto;


  const allSubCategories = await this.gestCategModel.find(
    { 
      login: decodedToken.login,
      categoria: categoria
    }
  ).select('subCategoria'); // Selecione apenas o campo 'subCategoria'

  if (allSubCategories) {
    return {
      success: true,
      message: 'Todas as subcategorias da categoria buscadas com sucesso!',
      financ: allSubCategories,
    };
  } else {
    return {
      success: false,
      message: 'Falha ao buscar todas as subcategorias da categoria especificada.',
    };
  }
 } catch (error) {
 return {
   "msg":error.message,
   success: false,
 }
 throw new Error(`Erro ao buscar todas as subcategorias da categoria: ${error.message}`);
 }
}



  create(createGestortempoDto: CreateGestortempoDto) {
    return 'This action adds a new gestortempo';
  }

  findAll() {
    return `This action returns all gestortempo`;
  }

  findOne(id: number) {
    return `This action returns a #${id} gestortempo`;
  }

  update(id: number, updateGestortempoDto: UpdateGestortempoDto) {
    return `This action updates a #${id} gestortempo`;
  }

  remove(id: number) {
    return `This action removes a #${id} gestortempo`;
  }
}

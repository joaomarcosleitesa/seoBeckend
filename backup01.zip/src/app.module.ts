//IMPORT AUTORIZAÇÃO DE ACESSOS
import { Module, NestModule, MiddlewareConsumer } from '@nestjs/common';
import * as cors from 'cors'; // Importe o módulo cors

//APP PRINCIPAL
import { AppController } from './app.controller';
import { AppService } from './app.service';

//MODULES CRIADOS
import { UserModule } from './user/user.module';//  !TRATANDO ESSE AGORA
import { S3uploadModule } from './s3upload/s3upload.module';
import { CepsModule } from './ceps/ceps.module';
import { MongooseModule } from '@nestjs/mongoose';
import { UserfindseoModule } from './userfindseo/userfindseo.module';
import { ProductModule } from './product/product.module';
import { SisfinanceiroModule } from './sisfinanceiro/sisfinanceiro.module';
import { GestortempoModule } from './gestortempo/gestortempo.module';
import { SearchModule } from './search/search.module';
import { ClientesModule } from './clientes/clientes.module';
import { ServicosModule } from './servicos/servicos.module';
import { TicketsModule } from './tickets/tickets.module';

//uri: 'mongodb://root:080591Jm@158.220.83.209:27017/shop_bd',

@Module({

  imports: [

    MongooseModule.forRootAsync({
      useFactory: async () => {
        //const connection = await databaseConnection(); // Chame a função aqui
        return {

          uri: 'mongodb://158.220.83.209:27030/shop_bd',
          
          
        };
      },
    }),
  
    UserModule, S3uploadModule, CepsModule, UserfindseoModule, ProductModule, SisfinanceiroModule, GestortempoModule, SearchModule, ClientesModule, ServicosModule, TicketsModule

    ],

    controllers: [AppController],
    providers: [AppService],

    
  })


export class AppModule implements NestModule {
  configure(consumer: MiddlewareConsumer) {
    // Use o middleware CORS configurado para permitir qualquer origem
    consumer.apply(cors()).forRoutes('*');
  }
}


import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { UserfindseoService } from './userfindseo.service';
import { UserfindseoController } from './userfindseo.controller';
import { UserSchema } from '../user/user.model';
import { UserService } from '../user/user.service';

@Module({
  imports: [
    MongooseModule.forFeature([{ name: 'User', schema: UserSchema }])

  ],
  controllers: [UserfindseoController],
  providers: [UserfindseoService],
})
export class UserfindseoModule {}

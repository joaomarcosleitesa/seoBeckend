export class CreateUserfindseoDto {}

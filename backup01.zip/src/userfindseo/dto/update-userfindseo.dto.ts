import { PartialType } from '@nestjs/mapped-types';
import { CreateUserfindseoDto } from './create-userfindseo.dto';

export class UpdateUserfindseoDto extends PartialType(CreateUserfindseoDto) {}

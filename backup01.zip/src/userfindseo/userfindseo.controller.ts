import { Controller, Get, Post, Body, Patch, Param, Delete ,Req, UnauthorizedException} from '@nestjs/common';
import { UserfindseoService} from './userfindseo.service';
import { UserService } from '../user/user.service';
import { CreateUserfindseoDto } from './dto/create-userfindseo.dto';
import { UpdateUserfindseoDto } from './dto/update-userfindseo.dto';

import { User} from '../user/user.model';

@Controller('userfindseo')
export class UserfindseoController {
  constructor(
    private readonly userfindseoService: UserfindseoService,
    ) {}


  @Post('dados-user-seo') // Rota para atualizar campos de SEO
  async findDadosUser(
    @Body() dados: any,
    ) {

    try {



        const date = dados.login; // Obtenha o token de dados
        //return {"dados":date}

        const dadosUsuario = await this.userfindseoService.findDadosUser(date);
        return {dadosUsuario}
      }catch (error) {
        
        console.log(error);
        
        //return { error: `Erro no dados-user-seo. ${error}` };
         throw new Error(`Erro ao buscar dados do login no Controller: ${error.message}`);
    }
  }



 @Post('dados-user-seo-user-hostname') // Rota para atualizar campos de SEO
  async findDadosUserHostname(
    @Body() dados: any,
    ) {

    try {



        const date = dados.login; // Obtenha o token de dados
        //return {"dados":date}

        const dadosUsuario = await this.userfindseoService.findDadosUserHostname(date);
        return {dadosUsuario}
      }catch (error) {
        
        console.log(error);
        
        //return { error: `Erro no dados-user-seo. ${error}` };
         throw new Error(`Erro ao buscar dados do login no Controller: ${error.message}`);
    }
  }




 


  //AND CLASS

}

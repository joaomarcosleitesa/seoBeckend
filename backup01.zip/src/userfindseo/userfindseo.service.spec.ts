import { Test, TestingModule } from '@nestjs/testing';
import { UserfindseoService } from './userfindseo.service';

describe('UserfindseoService', () => {
  let service: UserfindseoService;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      providers: [UserfindseoService],
    }).compile();

    service = module.get<UserfindseoService>(UserfindseoService);
  });

  it('should be defined', () => {
    expect(service).toBeDefined();
  });
});

import { Injectable } from '@nestjs/common';
import { CreateUserfindseoDto } from './dto/create-userfindseo.dto';
import { UpdateUserfindseoDto } from './dto/update-userfindseo.dto';
import { Model } from 'mongoose'; // Certifique-se de importar o Model do Mongoose
import { InjectModel } from '@nestjs/mongoose'; // Importe o InjectModel para injetar o modelo
import { User} from '../user/user.model';


@Injectable()
export class UserfindseoService {
    
constructor(@InjectModel('User') private readonly userModel: Model<User>) {}

  async findDadosUser( dadosValue:any): Promise<{ dados: any; } | null> {
        try {


          // Verifique o token usando o AuthService

          //const date =dadosValue.login

          

          // Busque um usuário com o login fornecido
          const user = await this.userModel.findOne({login:dadosValue}).exec();

          if (!user) {
            return null; // Retorna nulo se o usuário não for encontrado
          }

          const dados = { 
              hostname: user.hostname, 
              user_dominio: user.user_dominio, 
              s3pasta:user.s3pasta,
              cp_email:user.cp_email,
              cp_analytcs:user.cp_analytcs,
              cp_endress: user.cp_endress,
              cp_link_facebook: user.cp_link_facebook,
              cp_link_instagram: user.cp_link_instagram,
              cp_nome_empresa: user.cp_nome_empresa,
              cp_number_whatsapp :  user.cp_number_whatsapp,
              cp_seo: user.cp_seo,
              cp_telefone: user.cp_telefone,
              cp_text_api_zap: user.cp_text_api_zap,
              cp_url_site_principal: user.cp_url_site_principal,
              cp_descript:user.cp_descript,
              palavras_chave_word:user.palavras_chave_word,
              frases_seo:user.frases_seo,
              tags_seo:user.tags_seo,
              anuncio_loc:user.anuncio_loc,
              word_text_frases:user.word_text_frases,
              img_principais:user.img_principais



             }

          // Retorna as propriedades desejadas do usuário
          return {dados};
        } catch (error) {
          // Lidar com erros de consulta, se necessário
          throw new Error(`Erro ao buscar dados por login no SERVICE: ${error.message}`);
        }
  }



    async findDadosUserHostname( dadosValue:any): Promise<{ dados: any; } | null> {
        try {



          // Busque um usuário com o login fornecido
          const user = await this.userModel.findOne({user_dominio:dadosValue}).exec();

          if (!user) {
            return null; // Retorna nulo se o usuário não for encontrado
          }

          const dados = { 
              hostname: user.hostname, 
              user_dominio: user.user_dominio, 
              s3pasta:user.s3pasta,
              cp_email:user.cp_email,
              cp_analytcs:user.cp_analytcs,
              cp_endress: user.cp_endress,
              cp_link_facebook: user.cp_link_facebook,
              cp_link_instagram: user.cp_link_instagram,
              cp_nome_empresa: user.cp_nome_empresa,
              cp_number_whatsapp :  user.cp_number_whatsapp,
              cp_seo: user.cp_seo,
              cp_telefone: user.cp_telefone,
              cp_text_api_zap: user.cp_text_api_zap,
              cp_url_site_principal: user.cp_url_site_principal,
              cp_descript:user.cp_descript,
              palavras_chave_word:user.palavras_chave_word,
              frases_seo:user.frases_seo,
              tags_seo:user.tags_seo,
              anuncio_loc:user.anuncio_loc,
              word_text_frases:user.word_text_frases,
              img_principais:user.img_principais



             }

          // Retorna as propriedades desejadas do usuário
          return {dados};
        } catch (error) {
          // Lidar com erros de consulta, se necessário
          throw new Error(`Erro ao buscar dados por login no SERVICE: ${error.message}`);
        }
  }




  findAll() {
    return `This action returns all userfindseo`;
  }

  findOne(id: number) {
    return `This action returns a #${id} userfindseo`;
  }

  update(id: number, updateUserfindseoDto: UpdateUserfindseoDto) {
    return `This action updates a #${id} userfindseo`;
  }

  remove(id: number) {
    return `This action removes a #${id} userfindseo`;
  }
}

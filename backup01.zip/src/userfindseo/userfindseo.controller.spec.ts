import { Test, TestingModule } from '@nestjs/testing';
import { UserfindseoController } from './userfindseo.controller';
import { UserfindseoService } from './userfindseo.service';

describe('UserfindseoController', () => {
  let controller: UserfindseoController;

  beforeEach(async () => {
    const module: TestingModule = await Test.createTestingModule({
      controllers: [UserfindseoController],
      providers: [UserfindseoService],
    }).compile();

    controller = module.get<UserfindseoController>(UserfindseoController);
  });

  it('should be defined', () => {
    expect(controller).toBeDefined();
  });
});
